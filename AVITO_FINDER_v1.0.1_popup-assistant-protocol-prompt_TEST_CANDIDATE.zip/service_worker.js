/* Avito Finder v1.0.0 — assistant-directed generic visible-UI executor and collector. */
"use strict";
importScripts("core.js");
const Core = AvitoFinderCore;
const STATE_KEY = Core.STORAGE.state;
const LOG_KEY = Core.STORAGE.logs;
const INSPECTION_KEY = Core.STORAGE.lastInspection;
const CAPTURE_PROTOCOL = "avito_finder_bridge_exact_capture_v1";
const CAPTURE_VERSION = "0.6.8";
const AVITO_READY_TIMEOUT_MS = 30000;
const UI_CLICK_RECONCILE_TIMEOUT_MS = 16000;
const UI_CLICK_RECONCILE_DELAY_MS = 900;
const EXPLICIT_QUEUE_MAX_ITEMS = 30;
const SEQUENTIAL_REVIEW_DEFAULT_BATCH = 30;
const SEQUENTIAL_REVIEW_DEFAULT_CARD_GAP_MS = 0;
const SEQUENTIAL_REVIEW_CARD_GAP_MAX_MS = 2147483647;
const SEQUENTIAL_CARD_READY_TIMEOUT_MS = 18000;
const SEQUENTIAL_CARD_CONTENT_TIMEOUT_MS = 6500;
// Default production pauses are deliberately visible: the user can observe an
// Avito tab activation, bounded snapshot moment and return transition.
const AVITO_VISIBLE_ACTIVATION_DELAY_MS = Number.isFinite(Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS)) ? Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS) : 2500;
const AVITO_VISIBLE_POST_CAPTURE_DELAY_MS = Number.isFinite(Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS)) ? Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS) : 2000;
const AVITO_VISIBLE_PRE_ACTION_DELAY_MS = Number.isFinite(Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS)) ? Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS) : 1500;
const AVITO_VISIBLE_POST_ACTION_DELAY_MS = Number.isFinite(Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS)) ? Number(globalThis.__AF_TEST_VISIBLE_DELAY_MS) : 2500;
const avitoReadyTimers = new Map();
const uiClickReconcileTimers = new Map();
const ensureLocks = new Map();
const DEBUGGER_PROTOCOL_VERSION = "1.3";
const DEBUGGER_MAX_TYPED_GRAPHEMES = 160;
const DEBUGGER_KEY_INTERVAL_MS = 38;
const DEBUGGER_ALLOWED_METHODS = new Set(["Input.dispatchMouseEvent", "Input.dispatchKeyEvent"]);

function cb(invoke) { return new Promise((resolve, reject) => invoke((value) => { const error = chrome.runtime.lastError; if (error) reject(new Error(error.message)); else resolve(value); })); }
const storageGet = (keys) => cb((done) => chrome.storage.local.get(keys, done));
const storageSet = (values) => cb((done) => chrome.storage.local.set(values, done));
const storageRemove = (keys) => cb((done) => chrome.storage.local.remove(keys, done));
const tabsQuery = (query) => cb((done) => chrome.tabs.query(query, done));
const tabsGet = (tabId) => cb((done) => chrome.tabs.get(tabId, done));
const tabsUpdate = (tabId, props) => cb((done) => chrome.tabs.update(tabId, props, done));
const tabsCreate = (props) => cb((done) => chrome.tabs.create(props, done));
const tabsSend = (tabId, message) => cb((done) => chrome.tabs.sendMessage(tabId, message, done));
const tabsRemove = (tabId) => cb((done) => chrome.tabs.remove(tabId, done));
const execute = (details) => cb((done) => chrome.scripting.executeScript(details, done));
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));

function shortTab(tab) { return { id: tab?.id ?? null, windowId: tab?.windowId ?? null, active: Boolean(tab?.active), url: tab?.url || null, title: tab?.title || null, status: tab?.status || null }; }
function noReceiver(error) { return /Receiving end does not exist|Could not establish connection|message port closed|Extension context invalidated/i.test(String(error?.message || error || "")); }
function asyncResponseChannelClosed(error) { return /A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received|message channel closed/i.test(String(error?.message || error || "")); }
function safeDispatchText(value) { return String(value || "").replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 220); }
function contextFromState(state) { return { tab_id: state?.chatgpt_tab_id, window_id: state?.chatgpt_window_id, origin: state?.chat_origin, chat_path: state?.chat_path, conversation_id: state?.conversation_id }; }
function contextForTab(tab, identity) { return { tab_id: tab?.id ?? null, window_id: tab?.windowId ?? null, origin: identity?.origin || null, chat_path: identity?.chat_path || null, conversation_id: identity?.conversation_id || null }; }

async function getState() { const raw = await storageGet(STATE_KEY); return Core.makeState(raw[STATE_KEY] || {}); }
async function saveState(next) { const state = Core.makeState({ ...next, updated_at: new Date().toISOString() }); await storageSet({ [STATE_KEY]: state }); return state; }
async function log(type, fields = {}) { const raw = await storageGet(LOG_KEY); const entries = Core.appendLog(raw[LOG_KEY], type, fields); await storageSet({ [LOG_KEY]: entries }); return entries.at(-1); }
async function getTab(tabId) { try { return await tabsGet(tabId); } catch (_) { return null; } }
async function activate(tab, role) {
  const updated = await tabsUpdate(tab.id, { active: true });
  if (!updated?.active) { await log("BLOCKED_TAB_ACTIVATION", { role, tab: shortTab(updated || tab) }); throw new Error(`BLOCKED_TAB_ACTIVATION:${role}`); }
  await log("TAB_ACTIVATED", { role, tab: shortTab(updated) });
  return updated;
}

async function activeChatTab() {
  const tabs = await tabsQuery({ active: true, lastFocusedWindow: true });
  const tab = tabs[0];
  if (!tab?.id || !Core.isChatGPTUrl(tab.url || "")) throw new Error("Открой нужный ChatGPT-чат в активной вкладке.");
  return tab;
}
async function withEnsureLock(tabId, fn) {
  const prior = ensureLocks.get(tabId) || Promise.resolve(); let release;
  const gate = new Promise((resolve) => { release = resolve; });
  const tail = prior.catch(() => {}).then(() => gate); ensureLocks.set(tabId, tail);
  await prior.catch(() => {});
  try { return await fn(); } finally { release(); if (ensureLocks.get(tabId) === tail) ensureLocks.delete(tabId); }
}
function validCapturePing(ping) {
  return Boolean(ping?.ok && ping.content_script_protocol === CAPTURE_PROTOCOL && String(ping.content_script_version || "") === CAPTURE_VERSION && Core.isConversationIdentity(ping.identity));
}
async function pingCapture(tabId) { return tabsSend(tabId, { type: "AF_CAPTURE_PING" }); }
async function injectChatAdapter(tabId) {
  const target = await getTab(tabId);
  if (!target || !Core.isChatGPTUrl(target.url)) throw new Error("CONTENT_TARGET_URL_REJECTED:chatgpt");
  await execute({ target: { tabId }, files: ["core.js", "chatgpt_content.js"], injectImmediately: true });
  await log("CONTENT_SCRIPT_INJECTED", { role: "chatgpt", tab: shortTab(target), files: ["core.js", "chatgpt_content.js"] });
}
async function ensureChatAdapter(tabId) {
  return withEnsureLock(tabId, async () => {
    try { const ping = await pingCapture(tabId); if (validCapturePing(ping)) return ping; } catch (error) {
      if (!noReceiver(error)) throw error;
      await log("CONTENT_RECEIVER_MISSING", { role: "chatgpt", tab_id: tabId, message_type: "AF_CAPTURE_PING" });
    }
    await injectChatAdapter(tabId);
    const fresh = await pingCapture(tabId);
    if (!validCapturePing(fresh)) throw new Error("CONTENT_ADAPTER_HANDSHAKE_FAILED");
    await log("CONTENT_ADAPTER_READY", { role: "chatgpt", tab_id: tabId, content_script_version: fresh.content_script_version, content_script_protocol: fresh.content_script_protocol, conversation_id: fresh.identity.conversation_id });
    return fresh;
  });
}
async function sendChat(tabId, message) { await ensureChatAdapter(tabId); return tabsSend(tabId, message); }
async function captureActiveChatContext() {
  const tab = await activeChatTab(); const ping = await ensureChatAdapter(tab.id);
  const urlIdentity = Core.conversationIdentityFromUrl(tab.url);
  if (!Core.isConversationIdentity(urlIdentity) || !Core.sameConversationIdentity(urlIdentity, ping.identity)) throw new Error("ACTIVE_CHAT_CONVERSATION_IDENTITY_MISMATCH");
  const context = contextForTab(tab, ping.identity);
  await log("ACTIVE_CHAT_CONTEXT_CAPTURED", { tab_id: context.tab_id, window_id: context.window_id, conversation_id: context.conversation_id, chat_path: context.chat_path });
  return { tab, context };
}
async function blockConversationContext(state, reason, details = {}) {
  const next = await saveState({ ...state, status: "BLOCKED_CONVERSATION_CONTEXT_CHANGED", phase: "CHATGPT_CONTEXT_GUARD", blocked_reason: reason });
  await log("BLOCKED_CONVERSATION_CONTEXT_CHANGED", { search_id: next.search_id, reason, expected_tab_id: state.chatgpt_tab_id, expected_window_id: state.chatgpt_window_id, expected_conversation_id: state.conversation_id, ...details });
  return next;
}
async function assertPinnedChatContext(state, operation, options = {}) {
  const expected = contextFromState(state); const tab = await getTab(expected.tab_id);
  if (!tab || !Core.isChatGPTUrl(tab.url) || tab.windowId !== expected.window_id) {
    const next = await blockConversationContext(state, "PINNED_CHAT_TAB_MISSING_OR_CHANGED", { operation, actual_tab: shortTab(tab) }); const error = new Error(next.blocked_reason); error.state = next; throw error;
  }
  const selected = options.activateTab ? await activate(tab, operation) : tab;
  const ping = await ensureChatAdapter(selected.id); const actual = contextForTab(selected, ping.identity);
  if (!Core.samePinnedChatContext(expected, actual)) {
    const next = await blockConversationContext(state, "PINNED_CHAT_CONVERSATION_MISMATCH", { operation, actual_tab: shortTab(selected), actual_conversation_id: actual.conversation_id, actual_chat_path: actual.chat_path }); const error = new Error(next.blocked_reason); error.state = next; throw error;
  }
  await log("PINNED_CHAT_CONTEXT_CONFIRMED", { search_id: state.search_id, operation, tab_id: selected.id, conversation_id: actual.conversation_id });
  return { tab: selected, context: actual };
}

function isAvitoPageReady(tab, windowId) { return Boolean(tab && tab.windowId === windowId && Core.isAvitoUrl(tab.url || "") && tab.status === "complete"); }
function debuggerAttach(target) { return cb((done) => chrome.debugger.attach(target, DEBUGGER_PROTOCOL_VERSION, done)); }
function debuggerDetach(target) { return cb((done) => chrome.debugger.detach(target, done)); }
function debuggerSend(target, method, params) {
  if (!DEBUGGER_ALLOWED_METHODS.has(method)) throw new Error(`DEBUGGER_METHOD_NOT_ALLOWED:${method}`);
  return cb((done) => chrome.debugger.sendCommand(target, method, params, done));
}
function debuggerErrorCode(error) {
  return String(error?.message || error || "DEBUGGER_UNKNOWN_ERROR").replace(/[^A-Z0-9_:.-]/giu, "_").slice(0, 180) || "DEBUGGER_UNKNOWN_ERROR";
}
function finiteNumber(value) { return Number.isFinite(Number(value)); }
function validDebuggerBounds(bounds) {
  return Boolean(bounds && finiteNumber(bounds.left) && finiteNumber(bounds.top) && finiteNumber(bounds.width) && finiteNumber(bounds.height)
    && Number(bounds.width) >= 4 && Number(bounds.height) >= 4 && Number(bounds.width) <= 10000 && Number(bounds.height) <= 10000);
}
function validDebuggerText(value) { return typeof value === "string" && Array.from(value).length <= DEBUGGER_MAX_TYPED_GRAPHEMES; }
async function verifyDebuggerTypeCaller(message, sender) {
  const state = await getState();
  const tab = sender?.tab;
  const request = message?.request || {};
  if (!state.search_id || state.command_mode !== "AVITO_UI" || state.status !== "AVITO_TAB_ACTIVE") throw new Error("DEBUGGER_STATE_NOT_ACTIVE_UI_PLAN");
  if (!tab?.id || tab.id !== state.avito_tab_id || tab.windowId !== state.current_window_id) throw new Error("DEBUGGER_SENDER_TAB_MISMATCH");
  const current = await getTab(tab.id);
  if (!current || !current.active || !isAvitoPageReady(current, state.current_window_id)) throw new Error("DEBUGGER_AVITO_TAB_NOT_ACTIVE_OR_READY");
  if (!Core.isAvitoUrl(request.page_url || "") || new URL(request.page_url).origin !== new URL(current.url).origin) throw new Error("DEBUGGER_PAGE_URL_MISMATCH");
  if (!/^afdt-[a-z0-9-]{12,}$/iu.test(String(request.token || ""))) throw new Error("DEBUGGER_TOKEN_INVALID");
  if (!validDebuggerBounds(request.bounds)) throw new Error("DEBUGGER_BOUNDS_INVALID");
  if (!validDebuggerText(request.value)) throw new Error("DEBUGGER_TEXT_INVALID");
  const target = request.target || {};
  if (!["input", "textarea", "div", "span"].includes(String(target.tag || "").toLowerCase())) throw new Error("DEBUGGER_TARGET_TAG_INVALID");
  return { state, tab: current, request };
}
function validDebuggerClickText(value) { return typeof value === "string" && Array.from(value).length <= 220; }
// Compatibility alias: option text remains subject to the same bounded public-text rule.
const validDebuggerOptionText = validDebuggerClickText;
async function verifyDebuggerClickCaller(message, sender) {
  const state = await getState();
  const tab = sender?.tab;
  const request = message?.request || {};
  if (!state.search_id || state.command_mode !== "AVITO_UI" || state.status !== "AVITO_TAB_ACTIVE") throw new Error("DEBUGGER_STATE_NOT_ACTIVE_UI_PLAN");
  if (!tab?.id || tab.id !== state.avito_tab_id || tab.windowId !== state.current_window_id) throw new Error("DEBUGGER_SENDER_TAB_MISMATCH");
  const current = await getTab(tab.id);
  if (!current || !current.active || !isAvitoPageReady(current, state.current_window_id)) throw new Error("DEBUGGER_AVITO_TAB_NOT_ACTIVE_OR_READY");
  if (!Core.isAvitoUrl(request.page_url || "") || new URL(request.page_url).origin !== new URL(current.url).origin) throw new Error("DEBUGGER_PAGE_URL_MISMATCH");
  if (!['CLICK', 'SELECT_OPTION'].includes(String(request.intent || '').toUpperCase())) throw new Error("DEBUGGER_CLICK_INTENT_REJECTED");
  if (!/^afdc-[a-z0-9-]{12,}$/iu.test(String(request.token || ""))) throw new Error("DEBUGGER_TOKEN_INVALID");
  if (!validDebuggerBounds(request.bounds)) throw new Error("DEBUGGER_BOUNDS_INVALID");
  if (!validDebuggerClickText(request.target_text) || !validDebuggerClickText(request.option_text)) throw new Error("DEBUGGER_CLICK_TEXT_INVALID");
  if (String(request.intent || '').toUpperCase() === 'SELECT_OPTION' && !String(request.option_text || '')) throw new Error("DEBUGGER_OPTION_TEXT_REQUIRED");
  const target = request.target || {};
  if (!['button', 'a', 'div', 'span', 'li', 'label'].includes(String(target.tag || '').toLowerCase())) throw new Error("DEBUGGER_TARGET_TAG_INVALID");
  return { state, tab: current, request };
}
async function inputMouseFocus(target, bounds, onStage = null) {
  const x = Number(bounds.left) + Number(bounds.width) / 2;
  const y = Number(bounds.top) + Number(bounds.height) / 2;
  // Explicit pointer lifecycle fields make this a trusted mouse click for pages
  // that reject incomplete press/release packets. No Runtime or Page commands are used.
  await debuggerSend(target, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, button: "none", buttons: 0, pointerType: "mouse" });
  if (typeof onStage === "function") onStage("mouse_pressed");
  await debuggerSend(target, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", buttons: 1, clickCount: 1, pointerType: "mouse" });
  if (typeof onStage === "function") onStage("mouse_released");
  await debuggerSend(target, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", buttons: 0, clickCount: 1, pointerType: "mouse" });
}
async function inputKey(target, type, params) { await debuggerSend(target, "Input.dispatchKeyEvent", { type, ...params }); }
async function inputClearExistingValue(target) {
  await inputKey(target, "keyDown", { key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65 });
  await inputKey(target, "keyUp", { key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65 });
  await inputKey(target, "keyDown", { key: "Backspace", code: "Backspace", windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
  await inputKey(target, "keyUp", { key: "Backspace", code: "Backspace", windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
}
async function clickVisibleTargetWithDebugger(message, sender) {
  let verified;
  try { verified = await verifyDebuggerClickCaller(message, sender); }
  catch (error) { return { ok: false, error: `CDP_VISIBLE_CLICK_REQUEST_BLOCKED:${debuggerErrorCode(error)}` }; }
  const { state, tab, request } = verified;
  const target = { tabId: tab.id };
  const intent = String(request.intent || 'CLICK').toUpperCase();
  let attached = false;
  let detachError = null;
  let stage = "attach";
  try {
    await debuggerAttach(target);
    attached = true;
    await log("CDP_VISIBLE_CLICK_ATTACHED", { search_id: state.search_id, tab_id: tab.id, protocol: DEBUGGER_PROTOCOL_VERSION, allowed_methods: Array.from(DEBUGGER_ALLOWED_METHODS), intent, target_text_length: Array.from(String(request.target_text || "")).length });
    stage = "target_confirmation";
    const confirm = await tabsSend(tab.id, { type: "AF_CONFIRM_DEBUGGER_CLICK_TARGET_VISIBLE", token: request.token });
    const confirmation = confirm?.data || {};
    if (!confirm?.ok || !confirmation.ok) throw new Error(`CDP_VISIBLE_CLICK_TARGET_CONFIRMATION_UNAVAILABLE:${String(confirmation.reason || "NO_RESPONSE")}`);
    if (!confirmation.intact) throw new Error("CDP_VISIBLE_CLICK_TARGET_DETACHED");
    if (!confirmation.pointer_reachable) throw new Error("CDP_VISIBLE_CLICK_TARGET_NOT_POINTER_REACHABLE");
    await inputMouseFocus(target, request.bounds, (nextStage) => { stage = nextStage; });
    stage = "completed";
    await log("CDP_VISIBLE_CLICK_COMPLETED", { search_id: state.search_id, tab_id: tab.id, intent, target_marker: String(request.target?.marker || "").slice(0, 160), target_role: String(request.target?.role || "").slice(0, 80), target_text_length: Array.from(String(request.target_text || "")).length });
    return { ok: true, data: { ok: true, strategy: intent === 'SELECT_OPTION' ? "chrome_debugger_input_mouse_click_visible_option" : "chrome_debugger_input_mouse_click_visible_target", cdp_methods: Array.from(DEBUGGER_ALLOWED_METHODS) } };
  } catch (error) {
    const reason = `${stage}:${debuggerErrorCode(error)}`;
    await log("CDP_VISIBLE_CLICK_FAILED", { search_id: state.search_id, tab_id: tab.id, stage, reason, intent, target_text_length: Array.from(String(request.target_text || "")).length });
    return { ok: false, error: `CDP_VISIBLE_CLICK_FAILED:${reason}` };
  } finally {
    if (attached) {
      try { await debuggerDetach(target); await log("CDP_VISIBLE_CLICK_DETACHED", { search_id: state.search_id, tab_id: tab.id, intent }); }
      catch (error) { detachError = debuggerErrorCode(error); await log("CDP_VISIBLE_CLICK_DETACH_FAILED", { search_id: state.search_id, tab_id: tab.id, reason: detachError, intent }); }
    }
    if (detachError) return { ok: false, error: `CDP_VISIBLE_CLICK_DETACH_FAILED:${detachError}` };
  }
}
async function clickVisibleOptionWithDebugger(message, sender) { return clickVisibleTargetWithDebugger(message, sender); }
async function typeVisibleAvitoTargetWithDebugger(message, sender) {
  let verified;
  try { verified = await verifyDebuggerTypeCaller(message, sender); }
  catch (error) { return { ok: false, error: `CDP_INPUT_REQUEST_BLOCKED:${debuggerErrorCode(error)}` }; }
  const { state, tab, request } = verified;
  const target = { tabId: tab.id };
  let attached = false;
  let detachError = null;
  const value = String(request.value || "");
  try {
    await debuggerAttach(target);
    attached = true;
    await log("CDP_INPUT_ATTACHED", { search_id: state.search_id, tab_id: tab.id, protocol: DEBUGGER_PROTOCOL_VERSION, allowed_methods: Array.from(DEBUGGER_ALLOWED_METHODS), text_length: Array.from(value).length });
    await inputMouseFocus(target, request.bounds);
    const focus = await tabsSend(tab.id, { type: "AF_CONFIRM_DEBUGGER_TYPE_TARGET_FOCUSED", token: request.token });
    if (!focus?.ok || !focus?.data?.ok || !focus.data.intact || !focus.data.focused) throw new Error("CDP_INPUT_FOCUS_CONFIRMATION_FAILED");
    if (Number(request.previous_value_length || 0) > 0) await inputClearExistingValue(target);
    // Browser-visible key lifecycle only: keyDown → char → keyUp for every
    // grapheme. No DOM mutation, Runtime, network or site API is used.
    for (const grapheme of Array.from(value)) {
      await inputKey(target, "keyDown", { key: grapheme });
      await inputKey(target, "char", { key: grapheme, text: grapheme, unmodifiedText: grapheme });
      await inputKey(target, "keyUp", { key: grapheme });
      await wait(DEBUGGER_KEY_INTERVAL_MS);
    }
    const confirm = await tabsSend(tab.id, { type: "AF_CONFIRM_DEBUGGER_TYPE_VALUE", token: request.token, expected_value: value });
    if (!confirm?.ok || !confirm?.data?.ok || !confirm.data.intact || !confirm.data.focused || !confirm.data.expected_value_matches) throw new Error("CDP_INPUT_VALUE_CONFIRMATION_FAILED");
    await log("CDP_INPUT_TYPE_COMPLETED", { search_id: state.search_id, tab_id: tab.id, text_length: Array.from(value).length, target_marker: String(request.target?.marker || "").slice(0, 160), target_placeholder: String(request.target?.placeholder || "").slice(0, 160) });
    return { ok: true, data: { ok: true, strategy: "chrome_debugger_input_mouse_focus_ctrl_a_backspace_keydown_char_keyup", cdp_methods: Array.from(DEBUGGER_ALLOWED_METHODS), text_length: Array.from(value).length } };
  } catch (error) {
    const reason = debuggerErrorCode(error);
    await log("CDP_INPUT_TYPE_FAILED", { search_id: state.search_id, tab_id: tab.id, reason, text_length: Array.from(value).length });
    return { ok: false, error: `CDP_INPUT_TYPE_FAILED:${reason}` };
  } finally {
    if (attached) {
      try { await debuggerDetach(target); await log("CDP_INPUT_DETACHED", { search_id: state.search_id, tab_id: tab.id }); }
      catch (error) { detachError = debuggerErrorCode(error); await log("CDP_INPUT_DETACH_FAILED", { search_id: state.search_id, tab_id: tab.id, reason: detachError }); }
    }
    if (detachError) return { ok: false, error: `CDP_INPUT_DETACH_FAILED:${detachError}` };
  }
}
function clearAvitoReadyDeadline(searchId) { const timer = avitoReadyTimers.get(searchId); if (timer) clearTimeout(timer); avitoReadyTimers.delete(searchId); }
function deadlineExpired(state) { const deadline = Date.parse(String(state?.avito_ready_deadline_at || "")); return Number.isFinite(deadline) && Date.now() >= deadline; }
async function blockAvitoPageReady(state, reason, details = {}) {
  const latest = await getState();
  if (latest.search_id !== state.search_id || ["CANCELLED_BY_USER", "REPORT_SENT_CONFIRMED", "WAITING_FOR_NEXT_ASSISTANT_FORM"].includes(latest.status)) return latest;
  clearAvitoReadyDeadline(state.search_id);
  const next = await saveState({ ...latest, status: "BLOCKED_AVITO_PAGE_READY", phase: "AVITO_NAVIGATION", blocked_reason: reason });
  await log("AVITO_PAGE_READY_BLOCKED", { search_id: next.search_id, reason, avito_tab_id: next.avito_tab_id, ...details });
  return next;
}
function scheduleAvitoReadyDeadline(state) {
  clearAvitoReadyDeadline(state.search_id); const deadline = Date.parse(state.avito_ready_deadline_at); if (!Number.isFinite(deadline)) return;
  const timer = setTimeout(() => { (async () => { const current = await getState(); if (current.search_id === state.search_id && current.status === "WAITING_FOR_AVITO_PAGE_READY") await blockAvitoPageReady(current, `AVITO_PAGE_READY_TIMEOUT:${current.avito_tab_id}`, { deadline_at: current.avito_ready_deadline_at }); })().catch(() => {}); }, Math.max(0, deadline - Date.now()));
  avitoReadyTimers.set(state.search_id, timer);
}
async function selectVisibleAvitoTab(windowId) {
  const candidates = (await tabsQuery({ windowId })).filter((tab) => Core.isAvitoUrl(tab.url || ""));
  const active = candidates.filter((tab) => tab.active);
  if (active.length === 1) return { tab: active[0], source: "active_avito_tab" };
  if (candidates.length === 1) return { tab: candidates[0], source: "single_avito_tab" };
  if (!candidates.length) throw new Error("AVITO_VISIBLE_TAB_REQUIRED_OPEN_ONE_PUBLIC_AVITO_TAB");
  throw new Error("AVITO_VISIBLE_TAB_AMBIGUOUS_SELECT_ONE_TAB");
}
async function persistedRunOwnedAvitoTab(state) {
  if (!Number.isInteger(state?.avito_tab_id)) return null;
  const tab = await getTab(state.avito_tab_id);
  if (!tab || tab.windowId !== state.current_window_id || !Core.isAvitoUrl(tab.url || "")) return null;
  return tab;
}
async function createInitialPublicAvitoTab(state, purpose) {
  // Allowed only at the first Avito action of one explicit user-started run.
  // It creates a single normal public root and never restores a stale URL or tab binding.
  if (!state?.user_started || state?.avito_target_bound_once) {
    throw new Error("AVITO_VISIBLE_TAB_REQUIRED_OPEN_ONE_PUBLIC_AVITO_TAB");
  }
  const tab = await tabsCreate({ url: "https://www.avito.ru/", active: true, windowId: state.current_window_id });
  if (!tab?.id || tab.windowId !== state.current_window_id) {
    throw new Error("AVITO_PUBLIC_ROOT_CREATE_FAILED");
  }
  await log("AVITO_INITIAL_PUBLIC_ROOT_CREATED", {
    search_id: state.search_id,
    purpose,
    tab: shortTab(tab),
    persistent_binding: false,
    bootstrap_only: true
  });
  return { tab, created: true, navigated: false, reused: false, source: "initial_active_public_root" };
}
function directPublicAvitoUrl(value) {
  try {
    const url = new URL(String(value || ""));
    if (!Core.isAvitoUrl(url.href) || url.protocol !== "https:" || !/^(?:www\.)?avito\.ru$/iu.test(url.hostname) || url.username || url.password) return null;
    url.hash = "";
    return url.href;
  } catch (_) { return null; }
}
function sameDocumentUrl(left, right) {
  try { const a = new URL(String(left || "")); const b = new URL(String(right || "")); a.hash = ""; b.hash = ""; return a.href === b.href; } catch (_) { return false; }
}
async function applyRequestedVisibleAvitoUrl(state, tab, requestedUrl, purpose, source) {
  const url = directPublicAvitoUrl(requestedUrl);
  if (!url || sameDocumentUrl(tab?.url, url)) return { tab, navigated: false, source };
  const updated = await tabsUpdate(tab.id, { url, active: true });
  if (!updated?.id || updated.windowId !== state.current_window_id) throw new Error("AVITO_DIRECT_URL_NAVIGATION_FAILED");
  await log("AVITO_DIRECT_URL_NAVIGATED", { search_id: state.search_id, purpose, source, requested_url: url, tab: shortTab(updated) });
  return { tab: updated, navigated: true, source: `${source}_direct_url` };
}
async function ensureAvitoTarget(state, requestedUrl, purpose, _policy = {}) {
  // A writing-block page URL is a normal visible navigation instruction. It
  // carries city, category, query and filters, so those controls are not typed
  // again after the target route has been supplied.
  const bound = await persistedRunOwnedAvitoTab(state);
  if (bound) {
    await log("AVITO_TAB_REUSED_WITHIN_RUN", { search_id: state.search_id, purpose, tab: shortTab(bound), persistent_binding: false });
    const routed = await applyRequestedVisibleAvitoUrl(state, bound, requestedUrl, purpose, "current_run");
    return { tab: routed.tab, created: false, navigated: routed.navigated, reused: true, source: routed.source };
  }
  try {
    const selected = await selectVisibleAvitoTab(state.current_window_id);
    await log("AVITO_VISIBLE_TARGET_SELECTED", { search_id: state.search_id, purpose, tab: shortTab(selected.tab), source: selected.source, persistent_binding: false });
    const routed = await applyRequestedVisibleAvitoUrl(state, selected.tab, requestedUrl, purpose, selected.source);
    return { tab: routed.tab, created: false, navigated: routed.navigated, reused: false, source: routed.source };
  } catch (error) {
    if (String(error?.message || error) === "AVITO_VISIBLE_TAB_REQUIRED_OPEN_ONE_PUBLIC_AVITO_TAB" && state?.user_started === true && state?.avito_target_bound_once !== true) {
      const created = await createInitialPublicAvitoTab(state, purpose);
      const routed = await applyRequestedVisibleAvitoUrl(state, created.tab, requestedUrl, purpose, created.source);
      return { tab: routed.tab, created: true, navigated: routed.navigated, reused: false, source: routed.source };
    }
    throw error;
  }
}
async function visibleAvitoDelay(state, stage, ms) {
  const durationMs = Math.max(0, Number(ms) || 0);
  await log("AVITO_VISIBLE_DELAY_STARTED", { search_id: state.search_id, stage, duration_ms: durationMs, avito_tab_id: state.avito_tab_id });
  await wait(durationMs);
  const latest = await getState();
  if (latest.search_id !== state.search_id || latest.status === "CANCELLED_BY_USER") throw new Error("AVITO_VISIBLE_DELAY_CANCELLED");
  await log("AVITO_VISIBLE_DELAY_COMPLETED", { search_id: state.search_id, stage, duration_ms: durationMs, avito_tab_id: state.avito_tab_id });
}
function uiTimingProfile(plan) {
  return String(plan?.timing_profile || "CONTROL_VISIBLE").toUpperCase() === "COLLECTION_FAST" ? "COLLECTION_FAST" : "CONTROL_VISIBLE";
}
function collectionStep(step) {
  const type = String(step?.type || "").toUpperCase();
  return type === "COLLECT_LISTINGS" || type === "COLLECT_LISTING_DETAILS" || type === "COLLECT_EXPLICIT_LISTING_QUEUE" || type === "RESUME_EXPLICIT_LISTING_QUEUE";
}
function firstNonWaitStep(steps) {
  for (const step of Array.isArray(steps) ? steps : []) if (String(step?.type || "").toUpperCase() !== "WAIT") return step || null;
  return null;
}
function nextNonWaitStep(steps, startIndex) {
  const list = Array.isArray(steps) ? steps : [];
  for (let index = Math.max(0, Number(startIndex) || 0); index < list.length; index += 1) {
    if (String(list[index]?.type || "").toUpperCase() !== "WAIT") return list[index] || null;
  }
  return null;
}
function planStartsCollection(plan, steps = null) {
  if (uiTimingProfile(plan) !== "COLLECTION_FAST") return false;
  const list = Array.isArray(steps) ? steps : (Array.isArray(plan?.steps) ? plan.steps : []);
  const firstIndex = list.findIndex((step) => String(step?.type || "").toUpperCase() !== "WAIT");
  if (firstIndex < 0) return false;
  const first = list[firstIndex] || null;
  if (collectionStep(first)) return true;
  // A card click followed immediately by public detail capture is already the
  // collection phase. A Find click followed by COLLECT_LISTINGS is deliberately
  // not included, because the user asked to keep that control visible.
  const second = nextNonWaitStep(list, firstIndex + 1);
  return String(first?.type || "").toUpperCase() === "CLICK" && String(second?.type || "").toUpperCase() === "COLLECT_LISTING_DETAILS";
}
function uiPlanStartDelayMs(plan) {
  // Keep the visible pause before a user-observable city/filter/search control.
  // Skip it only when this plan begins with read-only collection or with opening
  // one public card immediately followed by its read-only detail capture.
  return planStartsCollection(plan) ? 0 : AVITO_VISIBLE_PRE_ACTION_DELAY_MS;
}
function uiPlanCompletionDelayMs(plan, result) {
  // A completed collection returns without an artificial pause; the report itself
  // is still returned through the normal pinned-chat path.
  if (uiTimingProfile(plan) === "COLLECTION_FAST" && (Array.isArray(result?.listings) && result.listings.length || result?.listing_details)) return 0;
  return AVITO_VISIBLE_POST_ACTION_DELAY_MS;
}
function uiClickReconcileCollectionDelayMs(plan, remainingSteps) {
  // After a visible navigation arrives at a listing or results surface, collect
  // immediately in COLLECTION_FAST. Tab/page readiness is still verified first.
  return planStartsCollection(plan, remainingSteps) ? 0 : AVITO_VISIBLE_POST_ACTION_DELAY_MS;
}
async function requireReadyAvitoTarget(tabId, windowId) {
  const target = await getTab(tabId); if (!isAvitoPageReady(target, windowId)) throw new Error(`AVITO_PAGE_NOT_READY:${tabId}`); return target;
}
async function sendAvito(tabId, windowId, message) {
  const ready = await requireReadyAvitoTarget(tabId, windowId);
  try { return await tabsSend(tabId, message); } catch (error) {
    if (!noReceiver(error)) throw error;
    await execute({ target: { tabId }, files: ["core.js", "avito_content.js"], injectImmediately: true });
    await log("CONTENT_SCRIPT_INJECTED", { role: "avito", tab: shortTab(ready), files: ["core.js", "avito_content.js"] });
    return tabsSend(tabId, message);
  }
}
async function recordUiClickDispatched(message, sender) {
  const state = await getState();
  const dispatch = message?.dispatch || {};
  const tab = sender?.tab;
  const plan = state.ui_action_plan || {};
  const stepIndex = Number(dispatch.step_index || 0);
  const expectedStep = Array.isArray(plan.steps) ? plan.steps[stepIndex - 1] : null;
  if (!state.search_id || state.command_mode !== "AVITO_UI" || state.status !== "AVITO_TAB_ACTIVE") throw new Error("UI_CLICK_DISPATCH_STATE_NOT_ACTIVE");
  if (!tab?.id || tab.id !== state.avito_tab_id || tab.windowId !== state.current_window_id) throw new Error("UI_CLICK_DISPATCH_SENDER_TAB_MISMATCH");
  const current = await getTab(tab.id);
  if (!isAvitoPageReady(current, state.current_window_id)) throw new Error("UI_CLICK_DISPATCH_AVITO_NOT_READY");
  if (String(dispatch.step_type || "") !== "CLICK" || expectedStep?.type !== "CLICK") throw new Error("UI_CLICK_DISPATCH_STEP_MISMATCH");
  if (!plan.plan_fingerprint || String(dispatch.plan_fingerprint || "") !== String(plan.plan_fingerprint)) throw new Error("UI_CLICK_DISPATCH_PLAN_MISMATCH");
  if (!Core.isAvitoUrl(dispatch.page_url || "") || new URL(dispatch.page_url).origin !== new URL(current.url).origin) throw new Error("UI_CLICK_DISPATCH_PAGE_MISMATCH");
  const expectedNavigationPath = String(dispatch.expected_navigation_path || "");
  if (expectedNavigationPath && !expectedNavigationPath.startsWith("/")) throw new Error("UI_CLICK_DISPATCH_EXPECTED_PATH_INVALID");
  const targetDescription = safeDispatchText(dispatch.target_description);
  if (!targetDescription) throw new Error("UI_CLICK_DISPATCH_TARGET_REQUIRED");
  const dispatchId = `${state.search_id}:click:${stepIndex}:${Date.now().toString(36)}`;
  const pending = { dispatch_id: dispatchId, step_index: stepIndex, target_description: targetDescription, tab_id: tab.id, page_url: String(dispatch.page_url).slice(0, 500), expected_navigation_path: expectedNavigationPath.slice(0, 500), child_tab_ids: [], dispatched_at: new Date().toISOString() };
  const next = await saveState({ ...state, pending_ui_click: pending, blocked_reason: null });
  await log("AVITO_UI_CLICK_DISPATCH_RECORDED", { search_id: next.search_id, tab_id: tab.id, dispatch_id: dispatchId, step_index: stepIndex, target_description: targetDescription });
  return { ok: true, data: { dispatch_id: dispatchId } };
}
async function inspectAvito(tabId, windowId) { const response = await sendAvito(tabId, windowId, { type: "AF_INSPECT_AVITO_DOM" }); if (!response?.ok) throw new Error(`AVITO_DOM_UNAVAILABLE:${response?.error || "unknown"}`); return response.snapshot; }
async function captureRouteContext(tabId, windowId) {
  const response = await sendAvito(tabId, windowId, { type: "AF_GET_ROUTE_CONTEXT" });
  if (!response?.ok || !response.context) throw new Error(`AVITO_ROUTE_CONTEXT_UNAVAILABLE:${response?.error || "unknown"}`);
  return response.context;
}
async function rememberRouteContext(state, context, kind) {
  const journal = Core.appendRouteContext(state.route_journal, context, kind);
  return saveState({ ...state, last_route_context: context, route_journal: journal, last_context_report_fingerprint: null });
}
async function preflightRouteContext(state, tab) {
  const current = await captureRouteContext(tab.id, state.current_window_id);
  const previous = state.last_route_context || null;
  if (previous && Core.routeContextChanged(previous, current)) {
    const journal = Core.appendRouteContext(state.route_journal, current, "manual_context_changed");
    const report = Core.formatRouteContextReport(state.search_id, previous, current, journal, "VISIBLE_AVITO_CONTEXT_CHANGED");
    const prepared = await saveState({ ...state, last_route_context: current, route_journal: journal, status: "ROUTE_CONTEXT_CHANGED_REPORT_READY", phase: "ROUTE_CONTEXT_RECONCILIATION", report, report_kind: "route_context_changed", blocked_reason: "VISIBLE_AVITO_CONTEXT_CHANGED" });
    await log("VISIBLE_AVITO_CONTEXT_CHANGED", { search_id: prepared.search_id, previous: Core.routeContextFingerprint(previous), current: Core.routeContextFingerprint(current) });
    await deliverReportToPinnedChat(prepared, report, "route_context_changed");
    return { changed: true, state: await getState(), context: current };
  }
  const remembered = await rememberRouteContext(state, current, previous ? "preflight_confirmed" : "initial_preflight");
  return { changed: false, state: remembered, context: current };
}
async function diagnoseAvito(tabId, windowId, request) { const response = await sendAvito(tabId, windowId, { type: "AF_DIAGNOSE_AVITO_DOM", request }); if (!response?.ok) throw new Error(`AVITO_DIAGNOSTIC_UNAVAILABLE:${response?.error || "unknown"}`); return response.snapshot; }
async function performDiagnosticAction(tabId, windowId, request) { const response = await sendAvito(tabId, windowId, { type: "AF_PERFORM_DIAGNOSTIC_ACTION", request }); if (!response?.ok) throw new Error(`AVITO_DIAGNOSTIC_ACTION_UNAVAILABLE:${response?.error || "unknown"}`); if (!response.result?.ok) throw new Error(`AVITO_DIAGNOSTIC_ACTION_BLOCKED:${response.result?.blocked_reason || "unknown"}`); return response.result; }
// Generic plan execution is isolated to the Avito content script. The worker
// never receives selectors or JavaScript from the chat; it carries only the
// locally parsed visible-control descriptors.
async function executeAvitoUiActionPlan(tabId, windowId, plan) {
  const response = await sendAvito(tabId, windowId, { type: "AF_EXECUTE_AVITO_UI_PLAN", plan });
  if (!response?.ok) throw new Error(`AVITO_UI_PLAN_UNAVAILABLE:${response?.error || "unknown"}`);
  return response.result || { ok: false, blocked_reason: "AVITO_UI_PLAN_EMPTY_RESULT", steps: [] };
}
function canonicalPublicListingUrl(value) {
  try { const u = new URL(value); return Core.isAvitoUrl(u.href) ? `${u.origin}${u.pathname}` : ""; } catch (_) { return ""; }
}
function samePublicResultsPath(a, b) {
  try { const left = new URL(a); const right = new URL(b); return left.origin === right.origin && left.pathname === right.pathname; } catch (_) { return false; }
}
function sequentialCardUrlState(tab, windowId, expectedHref) {
  if (!tab) return { state: "missing", url: "" };
  if (tab.windowId !== windowId) return { state: "wrong_window", url: "" };
  const committedUrl = String(tab.url || "");
  const pendingUrl = String(tab.pendingUrl || "");
  if (Core.isAvitoUrl(committedUrl)) {
    if (tab.status !== "complete") return { state: "loading_avito", url: committedUrl };
    if (canonicalPublicListingUrl(committedUrl) !== canonicalPublicListingUrl(expectedHref)) return { state: "wrong_listing", url: committedUrl };
    return { state: "ready", url: committedUrl };
  }
  if (Core.isAvitoUrl(pendingUrl)) return { state: "pending_avito", url: pendingUrl };
  if (!committedUrl || /^(?:about:blank|chrome:\/\/newtab\/?)(?:#.*)?$/iu.test(committedUrl)) return { state: "transient_blank", url: committedUrl };
  return { state: "invalid_url", url: committedUrl };
}
async function waitForSequentialCardReady(tabId, windowId, expectedHref, timeoutMs = SEQUENTIAL_CARD_READY_TIMEOUT_MS) {
  const timeout = Math.max(1000, Math.min(Number(timeoutMs) || SEQUENTIAL_CARD_READY_TIMEOUT_MS, SEQUENTIAL_CARD_READY_TIMEOUT_MS));
  return new Promise((resolve, reject) => {
    let settled = false; let last = null; let timer = null;
    const finish = (error, tab) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      if (error) reject(error); else resolve(tab);
    };
    const assess = (tab) => {
      const state = sequentialCardUrlState(tab, windowId, expectedHref); last = state;
      if (state.state === "missing") { finish(new Error(`SEQUENTIAL_CARD_TAB_MISSING:${tabId}`)); return; }
      if (state.state === "wrong_window") { finish(new Error(`SEQUENTIAL_CARD_WINDOW_INVALID:${tabId}`)); return; }
      if (state.state === "wrong_listing") { finish(new Error(`SEQUENTIAL_CARD_URL_MISMATCH:${tabId}`)); return; }
      if (state.state === "ready") { finish(null, tab); return; }
      if (state.state === "invalid_url" && tab?.status === "complete") finish(new Error(`SEQUENTIAL_CARD_NON_AVITO_FINAL_URL:${tabId}`));
    };
    const onUpdated = (updatedId, changeInfo, tab) => {
      if (updatedId !== tabId) return;
      if (changeInfo.url || changeInfo.status === "loading" || changeInfo.status === "complete") assess(tab);
    };
    const onRemoved = (removedId) => { if (removedId === tabId) finish(new Error(`SEQUENTIAL_CARD_TAB_MISSING:${tabId}`)); };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
    timer = setTimeout(() => finish(new Error(`SEQUENTIAL_CARD_READY_TIMEOUT:${tabId}:${last?.state || "unknown"}`)), timeout);
    getTab(tabId).then(assess).catch(() => finish(new Error(`SEQUENTIAL_CARD_TAB_MISSING:${tabId}`)));
  });
}
async function readSequentialPublicListing(tabId, windowId) {
  const response = await sendAvito(tabId, windowId, { type: "AF_SEQUENTIAL_READ_PUBLIC_LISTING", request: { timeout_ms: SEQUENTIAL_CARD_CONTENT_TIMEOUT_MS } });
  if (!response?.ok || !response.result) throw new Error(`SEQUENTIAL_LISTING_READ_UNAVAILABLE:${response?.error || "unknown"}`);
  return response.result.details || { blocked_reason: "SEQUENTIAL_LISTING_DETAILS_EMPTY" };
}
function sequentialDetailKey(summary) { return canonicalPublicListingUrl(summary?.href || ""); }
function mergeSequentialDetails(previous, next) {
  const old = previous && typeof previous === "object" ? previous : {};
  const fresh = next && typeof next === "object" ? next : {};
  return {
    ...old,
    ...fresh,
    price: fresh.price || old.price || "",
    title: fresh.title || old.title || "",
    seller: fresh.seller || old.seller || "",
    seller_rating: fresh.seller_rating || old.seller_rating || "",
    location: fresh.location || old.location || "",
    description: fresh.description || old.description || "",
    sections: Array.isArray(fresh.sections) && fresh.sections.length ? fresh.sections : (Array.isArray(old.sections) ? old.sections : []),
    seller_badges: Array.isArray(fresh.seller_badges) && fresh.seller_badges.length ? fresh.seller_badges : (Array.isArray(old.seller_badges) ? old.seller_badges : []),
    delivery: Array.isArray(fresh.delivery) && fresh.delivery.length ? fresh.delivery : (Array.isArray(old.delivery) ? old.delivery : [])
  };
}
function upsertSequentialDetail(checkpoint, summary, detail) {
  const rows = Array.isArray(checkpoint.details) ? checkpoint.details : [];
  const key = sequentialDetailKey(summary);
  const index = key ? rows.findIndex((row) => sequentialDetailKey(row?.summary || {}) === key) : -1;
  const row = { summary, details: mergeSequentialDetails(index >= 0 ? rows[index]?.details : null, detail) };
  if (index >= 0) rows[index] = row; else rows.push(row);
  checkpoint.details = rows;
  return row;
}
function rawCollectedRecord(summary, details) {
  const detail = details && typeof details === "object" ? details : {};
  return {
    href: canonicalPublicListingUrl(summary?.href || detail?.href || ""),
    title: detail.title || summary?.title || "",
    price: detail.price || summary?.price || "",
    location: detail.location || summary?.location || "",
    seller: detail.seller || summary?.seller || "",
    seller_rating: detail.seller_rating || summary?.seller_rating || "",
    seller_badges: Array.isArray(detail.seller_badges) ? detail.seller_badges : (Array.isArray(summary?.seller_badges) ? summary.seller_badges : []),
    delivery: Array.isArray(detail.delivery) ? detail.delivery.join("; ") : (summary?.delivery || ""),
    sections: Array.isArray(detail.sections) ? detail.sections : [],
    description: detail.description || "",
    blocked_reason: detail.blocked_reason || null
  };
}
function compactSequentialCheckpoint(checkpoint) {
  const cp = checkpoint && typeof checkpoint === "object" ? checkpoint : {};
  const candidates = Array.isArray(cp.candidates) ? cp.candidates : [];
  const details = Array.isArray(cp.details) ? cp.details : [];
  const detailsByHref = new Map(details.map((row) => [sequentialDetailKey(row?.summary || {}), row]));
  const failed = Array.isArray(cp.failed) ? cp.failed : [];
  const collected = candidates.map((summary) => {
    const row = detailsByHref.get(sequentialDetailKey(summary));
    return rawCollectedRecord(summary, row?.details || null);
  });
  return {
    collector_kind: "assistant_explicit_public_url_queue",
    status: cp.status || "paused",
    candidate_count: candidates.length,
    details_collected: details.length,
    remaining: Math.max(0, candidates.length - Number(cp.cursor || 0)),
    batch_size: cp.batch_size || SEQUENTIAL_REVIEW_DEFAULT_BATCH,
    card_gap_ms: cp.card_gap_ms ?? SEQUENTIAL_REVIEW_DEFAULT_CARD_GAP_MS,
    cards_closed: cp.cards_closed || 0,
    queue_source: "assistant_explicit_url_order",
    collected: collected.slice(0, EXPLICIT_QUEUE_MAX_ITEMS),
    failed: failed.slice(0, 20),
    captcha: cp.captcha || null,
    blocked_reason: cp.blocked_reason || null
  };
}
function normalizeSequentialCardGapMs(value, fallback = SEQUENTIAL_REVIEW_DEFAULT_CARD_GAP_MS) {
  const parsed = Number(value);
  if (Number.isSafeInteger(parsed) && parsed >= 0 && parsed <= SEQUENTIAL_REVIEW_CARD_GAP_MAX_MS) return parsed;
  return fallback;
}
function requestedSequentialCardGapMs(plan) {
  const raw = plan?.sequential_card_gap_ms;
  return raw === null || raw === undefined ? null : normalizeSequentialCardGapMs(raw, null);
}
function checkpointCardGapMs(plan, checkpoint) {
  const requested = requestedSequentialCardGapMs(plan);
  return requested === null ? normalizeSequentialCardGapMs(checkpoint?.card_gap_ms) : requested;
}
async function persistSequentialCheckpoint(state, checkpoint, status = null, phase = null) {
  const next = await saveState({ ...state, sequential_review: checkpoint, ...(status ? { status } : {}), ...(phase ? { phase } : {}) });
  return next;
}
async function closeSequentialOwnedCard(tabId, parentTabId, windowId) {
  const tab = await getTab(tabId);
  if (!tab || tab.windowId !== windowId || Number(tab.openerTabId) !== Number(parentTabId)) return false;
  try { await tabsRemove(tabId); return true; } catch (_) { return false; }
}
async function assertSequentialParent(state, parentTab, checkpoint = null) {
  const cp = checkpoint && typeof checkpoint === "object" ? checkpoint : (state?.sequential_review || {});
  if (!samePublicResultsPath(cp.parent_url || parentTab.url, parentTab.url)) throw new Error("SEQUENTIAL_PARENT_RESULTS_PATH_MISMATCH");
  if (cp.parent_window_id !== null && cp.parent_window_id !== undefined && cp.parent_window_id !== parentTab.windowId) throw new Error("SEQUENTIAL_PARENT_WINDOW_MISMATCH");
  if (Number.isInteger(cp.parent_tab_id) && cp.parent_tab_id === parentTab.id) return cp;
  // A reload or a fresh explicit run may bind the same visible public results
  // URL to a new tab. Rebind only after exact public path and window checks.
  const rebound = { ...cp, parent_tab_id: parentTab.id, parent_window_id: parentTab.windowId, parent_url: parentTab.url || cp.parent_url || "" };
  await persistSequentialCheckpoint(state, rebound);
  await log("SEQUENTIAL_PARENT_REBOUND_SAME_RESULTS", { search_id: state.search_id, parent_tab_id: parentTab.id, parent_url: rebound.parent_url });
  return rebound;
}
async function runSequentialCardBatch(state, parentTab, checkpoint) {
  const batchTarget = Math.max(1, Math.min(Number(checkpoint.batch_size || SEQUENTIAL_REVIEW_DEFAULT_BATCH), SEQUENTIAL_REVIEW_DEFAULT_BATCH));
  let attempted = 0;
  const currentRun = async () => { const latest = await getState(); return latest.search_id === state.search_id && latest.status !== "CANCELLED_BY_USER"; };
  // A retained CAPTCHA tab is always re-read first. The extension never clicks, solves or refreshes a CAPTCHA.
  if (checkpoint.captcha?.child_tab_id) {
    const child = await getTab(checkpoint.captcha.child_tab_id);
    if (!child) {
      checkpoint.failed.push({ title: checkpoint.captcha.title || "", href: checkpoint.captcha.href || "", reason: "SEQUENTIAL_CAPTCHA_TAB_CLOSED_BY_USER" });
      checkpoint.cursor = Math.max(Number(checkpoint.cursor || 0), Number(checkpoint.captcha.cursor || 0) + 1);
      checkpoint.captcha = null;
    } else {
      const ready = await waitForSequentialCardReady(child.id, parentTab.windowId, checkpoint.captcha.href, SEQUENTIAL_CARD_READY_TIMEOUT_MS);
      await activate(ready, "explicit_queue_captcha_manual_recheck");
      const detail = await readSequentialPublicListing(ready.id, parentTab.windowId);
      if (detail?.blocked_reason === "BLOCKED_LOGIN_OR_CAPTCHA") {
        checkpoint.status = "paused_for_manual_captcha";
        checkpoint.blocked_reason = "CAPTCHA_MANUAL_REQUIRED";
        checkpoint.captcha = { ...checkpoint.captcha, child_tab_id: ready.id };
        await persistSequentialCheckpoint(state, checkpoint);
        await log("SEQUENTIAL_CAPTCHA_STILL_PRESENT", { search_id: state.search_id, child_tab_id: ready.id, cursor: checkpoint.cursor });
        return { checkpoint, attempted, blocked_reason: "CAPTCHA_MANUAL_REQUIRED" };
      }
      const summary = checkpoint.candidates[Number(checkpoint.captcha.cursor || checkpoint.cursor)] || checkpoint.captcha.summary || {};
      if (detail?.blocked_reason) checkpoint.failed.push({ title: summary.title || "", href: summary.href || "", reason: detail.blocked_reason });
      else upsertSequentialDetail(checkpoint, summary, detail);
      if (await closeSequentialOwnedCard(ready.id, parentTab.id, parentTab.windowId)) checkpoint.cards_closed += 1;
      checkpoint.cursor = Math.max(Number(checkpoint.cursor || 0), Number(checkpoint.captcha.cursor || 0) + 1);
      checkpoint.captcha = null; checkpoint.blocked_reason = null; checkpoint.status = "running"; attempted += 1;
      await persistSequentialCheckpoint(state, checkpoint);
    }
  }
  while (attempted < batchTarget && Number(checkpoint.cursor || 0) < checkpoint.candidates.length) {
    if (!await currentRun()) throw new Error("SEQUENTIAL_REVIEW_CANCELLED");
    const cursor = Number(checkpoint.cursor || 0); const summary = checkpoint.candidates[cursor]; let child = null;
    try {
      await log("SEQUENTIAL_CARD_OPEN_REQUESTED", { search_id: state.search_id, cursor, title: summary.title || "", href: summary.href || "", active: true });
      child = await tabsCreate({ url: summary.href, active: true, windowId: parentTab.windowId, openerTabId: parentTab.id });
      const ready = await waitForSequentialCardReady(child.id, parentTab.windowId, summary.href, SEQUENTIAL_CARD_READY_TIMEOUT_MS);
      await log("SEQUENTIAL_CARD_READY", { search_id: state.search_id, cursor, tab_id: ready.id, href: ready.url || null });
      const detail = await readSequentialPublicListing(ready.id, parentTab.windowId);
      if (detail?.blocked_reason === "BLOCKED_LOGIN_OR_CAPTCHA") {
        checkpoint.status = "paused_for_manual_captcha"; checkpoint.blocked_reason = "CAPTCHA_MANUAL_REQUIRED";
        checkpoint.captcha = { child_tab_id: ready.id, cursor, title: summary.title || "", href: summary.href || "", summary };
        await persistSequentialCheckpoint(state, checkpoint);
        await log("SEQUENTIAL_CAPTCHA_MANUAL_PAUSE", { search_id: state.search_id, child_tab_id: ready.id, cursor, title: summary.title || "" });
        return { checkpoint, attempted, blocked_reason: "CAPTCHA_MANUAL_REQUIRED" };
      }
      if (detail?.blocked_reason) checkpoint.failed.push({ title: summary.title || "", href: summary.href || "", reason: detail.blocked_reason });
      else upsertSequentialDetail(checkpoint, summary, detail);
    } catch (error) {
      checkpoint.failed.push({ title: summary?.title || "", href: summary?.href || "", reason: String(error?.message || error).slice(0, 180) });
    } finally {
      if (child?.id && !checkpoint.captcha?.child_tab_id) { if (await closeSequentialOwnedCard(child.id, parentTab.id, parentTab.windowId)) checkpoint.cards_closed += 1; }
    }
    checkpoint.cursor = cursor + 1; checkpoint.status = "running"; checkpoint.blocked_reason = null; attempted += 1;
    await persistSequentialCheckpoint(state, checkpoint);
    const cardGapMs = normalizeSequentialCardGapMs(checkpoint.card_gap_ms);
    if (attempted < batchTarget && checkpoint.cursor < checkpoint.candidates.length && cardGapMs > 0) {
      await log("SEQUENTIAL_CARD_GAP_WAIT", { search_id: state.search_id, cursor: checkpoint.cursor, card_gap_ms: cardGapMs });
      await wait(cardGapMs);
    }
  }
  checkpoint.status = checkpoint.cursor >= checkpoint.candidates.length ? "completed" : "paused_after_test_batch";
  checkpoint.blocked_reason = null;
  await persistSequentialCheckpoint(state, checkpoint);
  return { checkpoint, attempted, blocked_reason: null };
}
async function runExplicitListingQueue(state, parentTab, plan) {
  const action = (plan.steps || []).find((step) => ["COLLECT_EXPLICIT_LISTING_QUEUE", "RESUME_EXPLICIT_LISTING_QUEUE"].includes(String(step?.type || ""))) || {};
  const actionType = String(action.type || "");
  const isStart = actionType === "COLLECT_EXPLICIT_LISTING_QUEUE";
  const isResume = actionType === "RESUME_EXPLICIT_LISTING_QUEUE";
  let checkpoint = state.sequential_review && typeof state.sequential_review === "object" ? { ...state.sequential_review } : null;
  const batchSize = Math.max(1, Math.min(Number(action.batch || checkpoint?.batch_size || SEQUENTIAL_REVIEW_DEFAULT_BATCH), SEQUENTIAL_REVIEW_DEFAULT_BATCH));
  const configuredCardGapMs = checkpointCardGapMs(plan, checkpoint);

  if (isStart) {
    const requestedUrls = Array.isArray(action.selected_urls) ? action.selected_urls.map((value) => canonicalPublicListingUrl(value)).filter(Boolean) : [];
    if (!requestedUrls.length) throw new Error("UI_PLAN_EXPLICIT_PUBLIC_QUEUE_REQUIRED");
    const candidates = requestedUrls.slice(0, EXPLICIT_QUEUE_MAX_ITEMS).map((href) => ({ href, title: "" }));
    checkpoint = {
      version: 1,
      kind: "assistant_explicit_public_url_queue",
      parent_tab_id: parentTab.id,
      parent_window_id: parentTab.windowId,
      parent_url: parentTab.url || "",
      candidates,
      cursor: 0,
      batch_size: batchSize,
      card_gap_ms: configuredCardGapMs,
      cards_closed: 0,
      details: [],
      failed: [],
      captcha: null,
      queue_source: "assistant_explicit_url_order",
      status: "running",
      blocked_reason: null
    };
    await persistSequentialCheckpoint(state, checkpoint, "AVITO_TAB_ACTIVE", "EXECUTING_EXPLICIT_PUBLIC_QUEUE");
    await log("EXPLICIT_PUBLIC_QUEUE_ACCEPTED", { search_id: state.search_id, candidate_count: candidates.length, batch_size: batchSize, card_gap_ms: checkpoint.card_gap_ms, parent_tab_id: parentTab.id });
  } else if (isResume) {
    if (!checkpoint || checkpoint.kind !== "assistant_explicit_public_url_queue" || !Array.isArray(checkpoint.candidates) || !checkpoint.candidates.length || checkpoint.status === "completed") throw new Error("EXPLICIT_PUBLIC_QUEUE_NO_RESUMABLE_CHECKPOINT");
    checkpoint = await assertSequentialParent(state, parentTab, checkpoint);
    checkpoint = { ...checkpoint, batch_size: batchSize, card_gap_ms: configuredCardGapMs, status: "running", blocked_reason: null };
    await persistSequentialCheckpoint(state, checkpoint, "AVITO_TAB_ACTIVE", "RESUMING_EXPLICIT_PUBLIC_QUEUE");
  } else {
    throw new Error("EXPLICIT_PUBLIC_QUEUE_ACTION_UNKNOWN");
  }

  const batch = await runSequentialCardBatch(state, parentTab, checkpoint);
  const review = compactSequentialCheckpoint(batch.checkpoint);
  const status = batch.blocked_reason ? "paused_for_manual_captcha" : review.status;
  return {
    ok: !batch.blocked_reason,
    url: parentTab.url || null,
    plan_fingerprint: plan.plan_fingerprint || "",
    steps: [{ index: 1, type: actionType, status: batch.blocked_reason ? "paused" : "completed", count: review.details_collected, text: `cursor=${batch.checkpoint.cursor}/${batch.checkpoint.candidates.length}; attempted=${batch.attempted}; status=${status}` }],
    listings: [],
    sequential_review: review,
    listing_details: null,
    blocked_reason: batch.blocked_reason || null
  };
}

function continuationSequentialCheckpoint(checkpoint) {
  if (!checkpoint || typeof checkpoint !== "object") return null;
  const status = String(checkpoint.status || "");
  return ["running", "paused_after_test_batch", "paused_for_manual_captcha"].includes(status) ? checkpoint : null;
}
async function deliverReportToPinnedChat(state, report, reportKind) {
  const latest = await getState();
  if (latest.search_id !== state.search_id || latest.status === "CANCELLED_BY_USER") return latest;
  const deliveryId = latest.report_delivery_id || `${latest.search_id}:${reportKind}`;
  const staged = await saveState({ ...latest, status: "REPORT_DELIVERY_IN_PROGRESS", phase: "CHATGPT_REPORT_DELIVERY", report, report_kind: reportKind, report_delivery_id: deliveryId, blocked_reason: null });
  let pinned;
  try { pinned = await assertPinnedChatContext(staged, `chatgpt_return_after_${reportKind}`, { activateTab: true }); } catch (_) { return await getState(); }
  await log("REPORT_DELIVERY_REQUESTED", { search_id: staged.search_id, report_kind: reportKind, tab_id: pinned.tab.id, report_fingerprint: Core.fingerprint(report) });
  let response;
  try {
    response = await sendChat(pinned.tab.id, { type: "AF_CAPTURE_SEND_REPORT", search_id: staged.search_id, delivery_id: deliveryId, report_text: report, expected_identity: pinned.context });
  } catch (error) { response = { ok: false, error: String(error?.message || error), code: "REPORT_TRANSPORT_FAILED" }; }
  if (!response?.ok || !Core.sameConversationIdentity(pinned.context, response.identity)) {
    const reason = response?.error || "REPORT_DELIVERY_CONTEXT_UNCONFIRMED";
    const pause = /PRIMARY_COMPOSER_OCCUPIED|composer.*другой|неотправленный текст/i.test(reason);
    const current = await getState();
    const next = await saveState({ ...current, status: pause ? "PAUSED_USER_COMPOSER_OCCUPIED" : "REPORT_DELIVERY_BLOCKED", phase: "CHATGPT_REPORT_DELIVERY", blocked_reason: reason, report, report_kind: reportKind, report_delivery_id: deliveryId });
    await log(pause ? "REPORT_DELIVERY_PAUSED_USER_COMPOSER_OCCUPIED" : "REPORT_DELIVERY_BLOCKED", { search_id: next.search_id, report_kind: reportKind, reason });
    return next;
  }
  const nextAnchorTurnId = response.anchor_turn_id || staged.anchor_turn_id || null;
  if (!nextAnchorTurnId) {
    const current = await getState();
    const blocked = await saveState({ ...current, status: "CONTINUATION_ANCHOR_MISSING", phase: "CHATGPT_CONTINUATION", blocked_reason: "REPORT_SENT_WITHOUT_USER_TURN_ANCHOR", report, report_kind: reportKind });
    await log("CONTINUATION_ANCHOR_MISSING", { search_id: blocked.search_id, report_kind: reportKind, chatgpt_tab_id: pinned.tab.id });
    return blocked;
  }
  // A delivered result is not terminal. Its exact user turn becomes the next
  // anchor, matching the Bridge dialogue cycle: report → next assistant form.
  // Full collected payloads are transient and are deleted once delivery is confirmed.
  await storageRemove([INSPECTION_KEY]);
  const waiting = await saveState({
    ...staged,
    status: "WAITING_FOR_NEXT_ASSISTANT_FORM",
    phase: "CHATGPT_CONTINUATION",
    anchor_turn_id: nextAnchorTurnId,
    report: null,
    report_kind: null,
    report_delivery_id: null,
    sequential_review: continuationSequentialCheckpoint(staged.sequential_review),
    blocked_reason: null
  });
  await log(reportKind === "validation_error" ? "VALIDATION_ERROR_REPORTED_TO_CHAT" : "REPORT_SENT_CONFIRMED", {
    search_id: waiting.search_id,
    report_kind: reportKind,
    user_turn_id: nextAnchorTurnId,
    chatgpt_tab_id: pinned.tab.id
  });
  await log("NEXT_FORM_POLL_REQUESTED", { search_id: waiting.search_id, report_kind: reportKind, anchor_turn_id: nextAnchorTurnId, chatgpt_tab_id: pinned.tab.id });
  let continuation;
  try {
    continuation = await sendChat(pinned.tab.id, {
      type: "AF_CAPTURE_BEGIN_PROMPT_POLL",
      search_id: waiting.search_id,
      conversation_id: waiting.conversation_id,
      anchor_turn_id: nextAnchorTurnId,
      expected_identity: pinned.context
    });
  } catch (error) {
    continuation = { ok: false, error: String(error?.message || error) };
  }
  if (!continuation?.ok) {
    const current = await getState();
    const blocked = await saveState({ ...current, status: "WAITING_FOR_NEXT_ASSISTANT_FORM", phase: "CHATGPT_CONTINUATION", blocked_reason: continuation?.error || "NEXT_FORM_POLL_START_FAILED" });
    await log("NEXT_FORM_POLL_START_FAILED", { search_id: blocked.search_id, anchor_turn_id: nextAnchorTurnId, reason: blocked.blocked_reason });
    return blocked;
  }
  const final = await saveState({ ...(await getState()), status: "WAITING_FOR_NEXT_ASSISTANT_FORM", phase: "CHATGPT_CONTINUATION", anchor_turn_id: nextAnchorTurnId, blocked_reason: null });
  await log("NEXT_FORM_POLL_STARTED", { search_id: final.search_id, report_kind: reportKind, anchor_turn_id: nextAnchorTurnId, chatgpt_tab_id: pinned.tab.id });
  return final;
}

function clearUiClickReconcileDeadline(searchId) {
  const timer = uiClickReconcileTimers.get(searchId);
  if (timer) clearTimeout(timer);
  uiClickReconcileTimers.delete(searchId);
}
function scheduleUiClickReconcile(state, delayMs = UI_CLICK_RECONCILE_DELAY_MS) {
  clearUiClickReconcileDeadline(state.search_id);
  const timer = setTimeout(() => { reconcilePendingUiClickHandoff().catch(async (error) => {
    const current = await getState();
    if (current.search_id === state.search_id && current.status === "WAITING_FOR_UI_CLICK_RECONCILIATION") await finishUiClickReconciliationFailure(current, `UI_CLICK_RECONCILIATION_FAILED:${String(error?.message || error)}`);
  }); }, Math.max(0, Number(delayMs) || 0));
  uiClickReconcileTimers.set(state.search_id, timer);
}
function pendingUiClickMatches(state, tabId) {
  const pending = state?.pending_ui_click || null;
  return Boolean(pending && pending.tab_id === tabId && Number.isInteger(Number(pending.step_index)) && pending.dispatch_id);
}
function expectedNavigationPathMatches(candidateUrl, expectedPath) {
  if (!candidateUrl || !expectedPath) return false;
  try {
    const candidate = new URL(candidateUrl);
    const expected = new URL(expectedPath, "https://www.avito.ru/");
    // Avito may rewrite opaque context query values. The public pathname includes
    // the actual listing identity, so require same origin plus exact pathname.
    return candidate.origin === "https://www.avito.ru" && expected.origin === "https://www.avito.ru" && candidate.pathname === expected.pathname;
  } catch (_) { return false; }
}
function pendingChildTabIds(state) {
  const ids = Array.isArray(state?.pending_ui_click?.child_tab_ids) ? state.pending_ui_click.child_tab_ids : [];
  return ids.filter((id) => Number.isInteger(id));
}
function isPendingUiClickChildTab(state, tab) {
  const pending = state?.pending_ui_click || null;
  if (!pending || !tab?.id || tab.windowId !== state.current_window_id) return false;
  if (!pendingChildTabIds(state).includes(tab.id)) return false;
  return Number(tab.openerTabId) === Number(pending.tab_id);
}
// A form submit (for example Avito's visible “Найти” button) has no href.
// It may reload the source tab before the content-script message can respond.
// Accept it only when the exact source tab has visibly changed URL; child tabs
// remain ineligible unless a visible anchor supplied an expected pathname.
function pendingUiClickNavigationMatches(state, tab) {
  const pending = state?.pending_ui_click || {};
  const sourceTab = pendingUiClickMatches(state, tab?.id);
  const childTab = isPendingUiClickChildTab(state, tab);
  if (!sourceTab && !childTab) return false;
  const expectedPath = String(pending.expected_navigation_path || "");
  if (expectedPath) return expectedNavigationPathMatches(tab?.url || "", expectedPath);
  return sourceTab && String(tab?.url || "") !== String(pending.page_url || "");
}
async function rememberPendingUiClickChildTab(tab, source) {
  const state = await getState();
  const pending = state?.pending_ui_click || null;
  const allowedState = state.status === "AVITO_TAB_ACTIVE" || state.status === "WAITING_FOR_UI_CLICK_RECONCILIATION";
  if (!allowedState || !pending || !tab?.id || tab.windowId !== state.current_window_id) return false;
  if (Number(tab.openerTabId) !== Number(pending.tab_id)) return false;
  const known = pendingChildTabIds(state);
  if (known.includes(tab.id)) return true;
  const childTabIds = [...known, tab.id].slice(-8);
  await saveState({ ...state, pending_ui_click: { ...pending, child_tab_ids: childTabIds, child_tab_observed_at: new Date().toISOString() } });
  await log("AVITO_UI_CHILD_TAB_CAPTURED", { search_id: state.search_id, source, source_tab_id: pending.tab_id, child_tab_id: tab.id, child_opener_tab_id: tab.openerTabId ?? null, child_url: tab.url || tab.pendingUrl || null });
  return true;
}
async function choosePendingUiClickNavigationTab(state) {
  const pending = state?.pending_ui_click || {};
  const sourceTab = await getTab(pending.tab_id);
  if (isAvitoPageReady(sourceTab, state.current_window_id) && pendingUiClickNavigationMatches(state, sourceTab)) {
    return { tab: sourceTab, source: "same_tab_navigation" };
  }
  for (const childTabId of pendingChildTabIds(state)) {
    const child = await getTab(childTabId);
    if (!isPendingUiClickChildTab(state, child) || !isAvitoPageReady(child, state.current_window_id)) continue;
    if (!pendingUiClickNavigationMatches(state, child)) continue;
    return { tab: child, source: "visible_child_tab" };
  }
  return null;
}
async function finishUiClickReconciliationFailure(state, reason) {
  clearUiClickReconcileDeadline(state.search_id);
  const terminal = await saveState({ ...state, status: "UI_CLICK_RECONCILIATION_REPORT_READY", phase: "AVITO_UI_CLICK_HANDOFF", blocked_reason: reason, pending_ui_click: { ...(state.pending_ui_click || {}), reconciliation: "unconfirmed" } });
  const plan = terminal.ui_action_plan || {};
  const pending = terminal.pending_ui_click || {};
  const result = { ok: false, url: pending.page_url || null, plan_fingerprint: plan.plan_fingerprint || "", steps: [{ index: pending.step_index || null, type: "CLICK", status: "dispatched_unconfirmed", target_description: pending.target_description || null, blocked_reason: reason, text: pending.dispatch_id ? `dispatch_id=${pending.dispatch_id}` : "" }], listings: [], blocked_reason: reason };
  const report = Core.formatUiActionPlanReport({ search_id: terminal.search_id, mode: "AVITO_UI", captured_at: new Date().toISOString(), avito: result });
  const ready = await saveState({ ...terminal, status: "REPORT_READY_FOR_DELIVERY", phase: "AVITO_UI_CLICK_HANDOFF_REPORT_READY", report, report_kind: "ui_action_plan" });
  await log("AVITO_UI_CLICK_RECONCILIATION_UNCONFIRMED", { search_id: ready.search_id, dispatch_id: pending.dispatch_id || null, reason });
  await deliverReportToPinnedChat(ready, report, "ui_action_plan");
}
async function completeUiClickReconciliation(state, readyTab, source) {
  if (state.status !== "WAITING_FOR_UI_CLICK_RECONCILIATION") return;
  const pending = state.pending_ui_click || {};
  const isSourceTab = pendingUiClickMatches(state, readyTab.id);
  const isChildTab = isPendingUiClickChildTab(state, readyTab);
  if (!isSourceTab && !isChildTab) return;
  if (!isAvitoPageReady(readyTab, state.current_window_id)) return;
  if (!pendingUiClickNavigationMatches(state, readyTab)) return;
  clearUiClickReconcileDeadline(state.search_id);
  const active = readyTab.active ? readyTab : await activate(readyTab, "avito_ui_post_click_reconciliation");
  const verified = await requireReadyAvitoTarget(active.id, state.current_window_id);
  let working = await saveState({ ...state, status: "AVITO_TAB_ACTIVE", phase: "AVITO_UI_POST_CLICK_RECONCILIATION", avito_tab_id: verified.id, avito_target_binding_source: isChildTab ? "visible_child_tab" : (state.avito_target_binding_source || "current_run"), blocked_reason: null, pending_ui_click: { ...pending, reconciliation: "resuming", reconciled_tab_id: verified.id, reconciliation_source: source } });
  const plan = working.ui_action_plan || { steps: [] };
  const clickIndex = Number(pending.step_index || 0);
  const remainingSteps = Array.isArray(plan.steps) ? plan.steps.slice(Math.max(0, clickIndex)) : [];
  await visibleAvitoDelay(working, "after_dispatched_click_before_reconciliation_capture", uiClickReconcileCollectionDelayMs(plan, remainingSteps));
  let resumed = null;
  let blockedReason = null;
  if (remainingSteps.some((step) => String(step?.type || "").toUpperCase() === "CLICK")) {
    blockedReason = "UI_CLICK_CONTINUATION_SECOND_CLICK_NOT_SUPPORTED";
    resumed = { ok: false, url: verified.url || null, plan_fingerprint: plan.plan_fingerprint || "", steps: [], listings: [], listing_details: null, blocked_reason: blockedReason };
  } else if (remainingSteps.length) {
    resumed = await executeAvitoUiActionPlan(verified.id, working.current_window_id, { ...plan, steps: remainingSteps, step_index_offset: clickIndex });
    blockedReason = resumed.blocked_reason || null;
  } else {
    const snapshot = await diagnoseAvito(verified.id, working.current_window_id, { scope: "PAGE_MAIN_VISIBLE" });
    resumed = { ok: !snapshot.blocked_reason, url: snapshot.url || verified.url || null, plan_fingerprint: plan.plan_fingerprint || "", steps: [], listings: [], listing_details: null, snapshot, blocked_reason: snapshot.blocked_reason || null };
    blockedReason = resumed.blocked_reason;
  }
  const clickStep = { index: clickIndex || null, type: "CLICK", status: "dispatched_reconciled", target_description: pending.target_description || null, text: pending.dispatch_id ? `dispatch_id=${pending.dispatch_id}` : "", navigation_url: verified.url || null };
  const result = {
    ok: !blockedReason && Boolean(resumed?.ok !== false),
    url: resumed?.url || verified.url || pending.page_url || null,
    plan_fingerprint: plan.plan_fingerprint || "",
    steps: [clickStep, ...(Array.isArray(resumed?.steps) ? resumed.steps : [])],
    listings: Array.isArray(resumed?.listings) ? resumed.listings : [],
    listing_details: resumed?.listing_details || null,
    snapshot: resumed?.snapshot || null,
    blocked_reason: blockedReason
  };
  working = await rememberRouteContext(working, await captureRouteContext(verified.id, working.current_window_id), "ui_click_handoff_completed");
  const actionPlan = { search_id: working.search_id, mode: "AVITO_UI", captured_at: new Date().toISOString(), avito: result };
  const report = Core.formatUiActionPlanReport(actionPlan);
  await storageSet({ [INSPECTION_KEY]: actionPlan });
  const ready = await saveState({ ...working, status: "REPORT_READY_FOR_DELIVERY", phase: "AVITO_UI_CLICK_HANDOFF_REPORT_READY", report, report_kind: "ui_action_plan", blocked_reason: result.blocked_reason, pending_ui_click: { ...pending, reconciliation: "completed" } });
  await log("AVITO_UI_CLICK_RECONCILIATION_CAPTURED", { search_id: ready.search_id, tab_id: verified.id, dispatch_id: pending.dispatch_id || null, source, resumed_step_count: Array.isArray(resumed?.steps) ? resumed.steps.length : 0, blocked_reason: result.blocked_reason || null });
  await deliverReportToPinnedChat(ready, report, "ui_action_plan");
}
async function startUiClickReconciliation(state, tabId, error) {
  const latest = await getState();
  if (latest.search_id !== state.search_id || !pendingUiClickMatches(latest, tabId)) return false;
  const deadline = new Date(Date.now() + UI_CLICK_RECONCILE_TIMEOUT_MS).toISOString();
  const waiting = await saveState({ ...latest, status: "WAITING_FOR_UI_CLICK_RECONCILIATION", phase: "AVITO_UI_CLICK_HANDOFF", blocked_reason: null, ui_click_reconcile_deadline_at: deadline, pending_ui_click: { ...latest.pending_ui_click, reconciliation: "waiting" } });
  await log("AVITO_UI_CHANNEL_CLOSED_AFTER_CLICK_DISPATCH", { search_id: waiting.search_id, tab_id: tabId, dispatch_id: waiting.pending_ui_click?.dispatch_id || null, step_index: waiting.pending_ui_click?.step_index || null, reason: String(error?.message || error).slice(0, 220), deadline_at: deadline });
  // Reconcile immediately: the navigation may already be complete when the
  // old content-script response channel closes. If it is not ready yet, the
  // bounded reconciler schedules its next readiness check itself.
  scheduleUiClickReconcile(waiting, 0);
  return true;
}
async function reconcilePendingUiClickHandoff() {
  const state = await getState();
  if (state.status !== "WAITING_FOR_UI_CLICK_RECONCILIATION" || !state.avito_tab_id || !pendingUiClickMatches(state, state.avito_tab_id)) return;
  const deadline = Date.parse(state.ui_click_reconcile_deadline_at || "");
  const sourceTab = await getTab(state.avito_tab_id);
  if (!sourceTab) { await finishUiClickReconciliationFailure(state, `UI_CLICK_RECONCILIATION_TAB_MISSING:${state.avito_tab_id}`); return; }
  if (sourceTab.windowId !== state.current_window_id) { await finishUiClickReconciliationFailure(state, `UI_CLICK_RECONCILIATION_TAB_WINDOW_MISMATCH:${state.avito_tab_id}`); return; }
  const target = await choosePendingUiClickNavigationTab(state);
  if (target?.tab) { await completeUiClickReconciliation(state, target.tab, target.source); return; }
  if (Number.isFinite(deadline) && Date.now() >= deadline) { await finishUiClickReconciliationFailure(state, `UI_CLICK_NAVIGATION_UNCONFIRMED:${state.avito_tab_id}`); return; }
  scheduleUiClickReconcile(state);
}
async function completeAvitoTask(queuedState, readyTab, source) {
  const state = await getState();
  if (state.search_id !== queuedState.search_id || state.status !== "WAITING_FOR_AVITO_PAGE_READY" || state.avito_tab_id !== readyTab.id) return;
  if (deadlineExpired(state)) { await blockAvitoPageReady(state, `AVITO_PAGE_READY_TIMEOUT:${readyTab.id}`, { source }); return; }
  if (!isAvitoPageReady(readyTab, state.current_window_id)) return;
  const role = state.command_mode === "DIAGNOSE_DOM" ? "avito_diagnose_dom" : (state.command_mode === "AVITO_UI" ? "avito_ui_action_plan" : "avito_inspect_filters");
  const activeAvito = await activate(readyTab, role); const verified = await requireReadyAvitoTarget(activeAvito.id, state.current_window_id);
  const latest = await getState(); if (latest.search_id !== state.search_id || latest.status !== "WAITING_FOR_AVITO_PAGE_READY") return;
  clearAvitoReadyDeadline(state.search_id);
  await log("AVITO_PAGE_READY", { search_id: state.search_id, tab: shortTab(verified), source, mode: state.command_mode });
  let working = await saveState({ ...latest, status: "AVITO_TAB_ACTIVE", phase: state.command_mode === "DIAGNOSE_DOM" ? "DIAGNOSING_DOM" : (state.command_mode === "AVITO_UI" ? "EXECUTING_AVITO_UI_PLAN" : "INSPECTING_FILTERS"), avito_tab_id: verified.id, blocked_reason: null });
  const activationDelay = working.command_mode === "AVITO_UI" && planStartsCollection(working.ui_action_plan) ? 0 : AVITO_VISIBLE_ACTIVATION_DELAY_MS;
  await visibleAvitoDelay(working, "after_avito_activation_before_readonly_capture", activationDelay);
  // The snapshot is intentionally delayed only for visible control flow; it is not used as a source of hidden data.
  const routePreflight = await preflightRouteContext(working, verified);
  if (routePreflight.changed) return;
  working = routePreflight.state;
  if (working.command_mode === "DIAGNOSE_DOM") {
    let actionResult = null;
    const diagnosticAction = String(working.diagnostic_request?.action || "").toUpperCase();
    if (diagnosticAction) {
      await visibleAvitoDelay(working, "before_allowlisted_diagnostic_action", AVITO_VISIBLE_PRE_ACTION_DELAY_MS);
      await log("AVITO_DIAGNOSTIC_ACTION_REQUESTED", { search_id: working.search_id, tab_id: verified.id, action: diagnosticAction, scope: working.diagnostic_request?.scope || null });
      actionResult = await performDiagnosticAction(verified.id, working.current_window_id, working.diagnostic_request);
      await log("AVITO_DIAGNOSTIC_ACTION_COMPLETED", { search_id: working.search_id, tab_id: verified.id, action: diagnosticAction, target_description: actionResult.target_description || null, target_text: actionResult.target_text || null });
      await visibleAvitoDelay(working, "after_allowlisted_diagnostic_action_before_capture", AVITO_VISIBLE_POST_ACTION_DELAY_MS);
    }
    const snapshot = await diagnoseAvito(verified.id, working.current_window_id, working.diagnostic_request);
    snapshot.actions_performed = actionResult?.actions_performed || snapshot.actions_performed || "none_read_only";
    await log("AVITO_DOM_SNAPSHOT_CAPTURED", { search_id: working.search_id, tab_id: verified.id, scope: working.diagnostic_request?.scope || null, action: diagnosticAction || null, root_description: snapshot.root_description || null, blocked_reason: snapshot.blocked_reason || null, scope_candidate_count: Array.isArray(snapshot.scope_candidates) ? snapshot.scope_candidates.length : 0, snapshot_fingerprint: snapshot.snapshot_fingerprint || null, truncated: snapshot.truncated === true });
    working = await rememberRouteContext(working, await captureRouteContext(verified.id, working.current_window_id), "diagnostic_completed");
    const diagnostic = { search_id: working.search_id, mode: "DIAGNOSE_DOM", captured_at: new Date().toISOString(), avito: snapshot, action: actionResult };
    const report = Core.formatDiagnosticReport(diagnostic);
    await storageSet({ [INSPECTION_KEY]: diagnostic });
    await visibleAvitoDelay(working, "after_readonly_capture_before_chatgpt_return", AVITO_VISIBLE_POST_CAPTURE_DELAY_MS);
    const readyForReport = await saveState({ ...working, status: "REPORT_READY_FOR_DELIVERY", phase: "DIAGNOSTIC_REPORT_READY", report, blocked_reason: snapshot.blocked_reason || null });
    await log("DIAGNOSTIC_REPORT_READY", { search_id: readyForReport.search_id, report_fingerprint: Core.fingerprint(report), scope: working.diagnostic_request?.scope || null });
    await deliverReportToPinnedChat(readyForReport, report, "diagnostic");
    return;
  }
  if (working.command_mode === "AVITO_UI") {
    const plan = working.ui_action_plan || { steps: [] };
    await visibleAvitoDelay(working, "before_generic_ui_action_plan", uiPlanStartDelayMs(plan));
    await log("AVITO_UI_PLAN_REQUESTED", { search_id: working.search_id, tab_id: verified.id, plan_fingerprint: plan.plan_fingerprint || null, step_count: Array.isArray(plan.steps) ? plan.steps.length : 0 });
    let result;
    try {
      const hasExplicitQueueCollection = Array.isArray(plan.steps) && plan.steps.some((step) => ["COLLECT_EXPLICIT_LISTING_QUEUE", "RESUME_EXPLICIT_LISTING_QUEUE"].includes(String(step?.type || "")));
      if (hasExplicitQueueCollection) {
        if (plan.steps.length !== 1) throw new Error("EXPLICIT_PUBLIC_QUEUE_PLAN_MUST_CONTAIN_EXACTLY_ONE_COLLECTION_ACTION");
        result = await runExplicitListingQueue(working, verified, plan);
        working = await getState();
        if (working.search_id !== state.search_id || working.status === "CANCELLED_BY_USER") return;
      } else result = await executeAvitoUiActionPlan(verified.id, working.current_window_id, plan);
    } catch (error) {
      if (asyncResponseChannelClosed(error) && await startUiClickReconciliation(working, verified.id, error)) return;
      throw error;
    }
    if (result?.navigation_handoff?.dispatch_id) {
      await log("AVITO_UI_VISIBLE_ANCHOR_NAVIGATION_HANDOFF", { search_id: working.search_id, tab_id: verified.id, dispatch_id: result.navigation_handoff.dispatch_id, step_index: result.navigation_handoff.step_index || null, expected_navigation_path: result.navigation_handoff.expected_navigation_path || null });
      if (await startUiClickReconciliation(working, verified.id, "VISIBLE_ANCHOR_NAVIGATION_HANDOFF")) return;
      throw new Error("UI_CLICK_RECONCILIATION_START_FAILED");
    }
    for (const step of Array.isArray(result.steps) ? result.steps : []) {
      await log("AVITO_UI_PLAN_STEP_RESULT", { search_id: working.search_id, tab_id: verified.id, index: step.index ?? null, type: step.type || null, status: step.status || null, blocked_reason: step.blocked_reason || null, target_description: step.target_description || null });
    }
    await visibleAvitoDelay(working, "after_generic_ui_action_plan_before_chatgpt_return", uiPlanCompletionDelayMs(plan, result));
    if (!Array.isArray(plan.steps) || !plan.steps.some((step) => ["COLLECT_EXPLICIT_LISTING_QUEUE", "RESUME_EXPLICIT_LISTING_QUEUE"].includes(String(step?.type || "")))) {
      working = await rememberRouteContext(working, await captureRouteContext(verified.id, working.current_window_id), "ui_plan_completed");
    }
    const actionPlan = { search_id: working.search_id, mode: "AVITO_UI", captured_at: new Date().toISOString(), avito: result };
    const report = Core.formatUiActionPlanReport(actionPlan);
    await storageSet({ [INSPECTION_KEY]: actionPlan });
    const readyForReport = await saveState({ ...working, status: "REPORT_READY_FOR_DELIVERY", phase: "AVITO_UI_PLAN_REPORT_READY", report, blocked_reason: result.blocked_reason || null });
    await log("AVITO_UI_PLAN_REPORT_READY", { search_id: readyForReport.search_id, report_fingerprint: Core.fingerprint(report), plan_fingerprint: result.plan_fingerprint || null, blocked_reason: result.blocked_reason || null });
    await deliverReportToPinnedChat(readyForReport, report, "ui_action_plan");
    return;
  }
  const snapshot = await inspectAvito(verified.id, working.current_window_id);
  working = await rememberRouteContext(working, await captureRouteContext(verified.id, working.current_window_id), "filters_completed");
  await log("AVITO_FILTER_SURFACE_CAPTURED", { search_id: working.search_id, tab_id: verified.id, blocked_reason: snapshot.blocked_reason || null });
  const inspection = { search_id: working.search_id, mode: working.command_mode, captured_at: new Date().toISOString(), avito: snapshot };
  const report = Core.formatInspectionReport(inspection);
  await storageSet({ [INSPECTION_KEY]: inspection });
  await visibleAvitoDelay(working, "after_readonly_capture_before_chatgpt_return", AVITO_VISIBLE_POST_CAPTURE_DELAY_MS);
  const readyForReport = await saveState({ ...working, status: "REPORT_READY_FOR_DELIVERY", phase: "INSPECTION_REPORT_READY", report, blocked_reason: snapshot.blocked_reason || null });
  await log("READONLY_INSPECTION_REPORT_READY", { search_id: readyForReport.search_id, report_fingerprint: Core.fingerprint(report) });
  await deliverReportToPinnedChat(readyForReport, report, "inspection");
}
function buildAvitoTargetRequest(parsed) {
  const request = parsed.mode === "DIAGNOSE_DOM" ? parsed.diagnostic : null;
  const uiPlan = parsed.mode === "AVITO_UI" ? parsed.ui_plan : null;
  const commandUrlEvidence = request?.page_url || uiPlan?.page_url || null;
  const requestedUrl = directPublicAvitoUrl(commandUrlEvidence);
  return {
    request,
    uiPlan,
    requestedUrl,
    commandUrlEvidence,
    purpose: parsed.mode === "DIAGNOSE_DOM" ? "avito_diagnose_dom" : (parsed.mode === "AVITO_UI" ? "avito_ui_action_plan" : "avito_inspect_filters")
  };
}
async function queueAvitoTask(initialState, parsed) {
  const targetRequest = buildAvitoTargetRequest(parsed);
  const avito = await ensureAvitoTarget(initialState, targetRequest.requestedUrl, targetRequest.purpose);
  if (targetRequest.commandUrlEvidence && !targetRequest.requestedUrl) {
    await log("AVITO_COMMAND_URL_REJECTED", { search_id: initialState.search_id, purpose: targetRequest.purpose, requested_url: targetRequest.commandUrlEvidence, bound_tab_id: avito.tab.id, bound_url: avito.tab.url || null });
  }
  const deadline = new Date(Date.now() + AVITO_READY_TIMEOUT_MS).toISOString();
  const state = await saveState({ ...initialState, status: "WAITING_FOR_AVITO_PAGE_READY", phase: "AVITO_NAVIGATION", avito_tab_id: avito.tab.id, avito_tab_created: avito.created, avito_target_bound_once: true, avito_target_binding_source: avito.source || null, command_mode: parsed.mode, diagnostic_request: targetRequest.request, ui_action_plan: targetRequest.uiPlan, avito_ready_deadline_at: deadline, ui_click_reconcile_deadline_at: null, pending_ui_click: null, blocked_reason: null });
  const current = await getTab(avito.tab.id);
  if (!current) { await blockAvitoPageReady(state, `AVITO_TAB_MISSING:${avito.tab.id}`); return; }
  if (current.windowId !== state.current_window_id) { await blockAvitoPageReady(state, `AVITO_TAB_WINDOW_MISMATCH:${avito.tab.id}`, { actual_tab: shortTab(current) }); return; }
  if (isAvitoPageReady(current, state.current_window_id)) { await completeAvitoTask(state, current, "immediate"); return; }
  await log("AVITO_TARGET_READY_WAIT_STARTED", { search_id: state.search_id, tab: shortTab(current), required_url_prefix: "https://www.avito.ru/", required_status: "complete", deadline_at: deadline, mode: parsed.mode, target_source: avito.source || null, reused: avito.reused === true });
  scheduleAvitoReadyDeadline(state);
}
async function reconcilePendingAvitoReadiness() {
  const state = await getState(); if (state.status !== "WAITING_FOR_AVITO_PAGE_READY" || !state.avito_tab_id) return;
  if (deadlineExpired(state)) { await blockAvitoPageReady(state, `AVITO_PAGE_READY_TIMEOUT:${state.avito_tab_id}`, { source: "reconcile" }); return; }
  const tab = await getTab(state.avito_tab_id);
  if (!tab) { await blockAvitoPageReady(state, `AVITO_TAB_MISSING:${state.avito_tab_id}`, { source: "reconcile" }); return; }
  if (tab.windowId !== state.current_window_id) { await blockAvitoPageReady(state, `AVITO_TAB_WINDOW_MISMATCH:${state.avito_tab_id}`, { source: "reconcile", actual_tab: shortTab(tab) }); return; }
  if (isAvitoPageReady(tab, state.current_window_id)) await completeAvitoTask(state, tab, "reconcile");
}

function diagnosticFields(details = {}) {
  const allowed = ["code", "anchor_turn_id", "assistant_turn_id", "copy_mode", "copy_ready", "assistant_finality_confirmed", "structural_signature", "trace_id", "anchor_mode", "anchor_policy", "anchor_selection", "candidate_turn_id", "candidate_text_fingerprint", "candidate_text_length", "candidate_position", "baseline_user_turn_count", "candidate_count", "rejection_reason", "event_source", "payload_extracted", "payload_bytes", "payload_extraction_error", "composer_scope", "composer_anchor", "embedded_editor_detected", "form_path", "buttons", "run_id", "conversation_id", "chat_path", "phase", "expected_assistant_turn_id", "expected_origin", "poll_generation", "form_key"];
  const result = {}; for (const key of allowed) if (details[key] !== undefined) result[key] = details[key]; return result;
}
async function observeManualContextChange(tabId, reason) {
  const state = await getState();
  if (state.status !== "WAITING_FOR_NEXT_ASSISTANT_FORM" || state.avito_tab_id !== tabId || !state.last_route_context) return;
  const tab = await getTab(tabId);
  if (!tab || tab.windowId !== state.current_window_id || !Core.isAvitoUrl(tab.url || "") || tab.status !== "complete") return;
  const current = await captureRouteContext(tabId, state.current_window_id);
  if (!Core.routeContextChanged(state.last_route_context, current)) return;
  const fingerprint = Core.routeContextFingerprint(current);
  if (state.last_context_report_fingerprint === fingerprint) return;
  const journal = Core.appendRouteContext(state.route_journal, current, "manual_context_changed");
  const report = Core.formatRouteContextReport(state.search_id, state.last_route_context, current, journal, reason || "VISIBLE_AVITO_CONTEXT_CHANGED");
  const prepared = await saveState({ ...state, last_route_context: current, route_journal: journal, last_context_report_fingerprint: fingerprint, status: "ROUTE_CONTEXT_CHANGED_REPORT_READY", phase: "ROUTE_CONTEXT_RECONCILIATION", report, report_kind: "route_context_changed", blocked_reason: reason || "VISIBLE_AVITO_CONTEXT_CHANGED" });
  await log("VISIBLE_AVITO_CONTEXT_CHANGED", { search_id: prepared.search_id, reason: reason || "VISIBLE_AVITO_CONTEXT_CHANGED", previous: Core.routeContextFingerprint(state.last_route_context), current: fingerprint });
  await deliverReportToPinnedChat(prepared, report, "route_context_changed");
}
async function reportAvitoTabClosed(tabId) {
  const state = await getState();
  if (state.status !== "WAITING_FOR_NEXT_ASSISTANT_FORM" || state.avito_tab_id !== tabId) return;
  const previous = state.last_route_context || null;
  const report = Core.formatRouteContextReport(state.search_id, previous, null, state.route_journal, "AVITO_TAB_CLOSED_BY_USER");
  const prepared = await saveState({ ...state, avito_tab_id: null, avito_target_bound_once: false, avito_target_binding_source: null, last_route_context: null, status: "ROUTE_CONTEXT_CHANGED_REPORT_READY", phase: "ROUTE_CONTEXT_RECONCILIATION", report, report_kind: "route_context_changed", blocked_reason: "AVITO_TAB_CLOSED_BY_USER" });
  await log("AVITO_TAB_CLOSED_BY_USER", { search_id: prepared.search_id, tab_id: tabId });
  await deliverReportToPinnedChat(prepared, report, "route_context_changed");
}
async function reconcileBlockedReport(existingState = null) {
  const state = existingState || await getState();
  if (!state?.report || !["REPORT_DELIVERY_BLOCKED", "REPORT_DELIVERY_IN_PROGRESS", "REPORT_READY_IN_COMPOSER", "REPORT_DELIVERY_UNCERTAIN"].includes(state.status)) {
    return { ok: false, error: "NO_UNCERTAIN_REPORT", state };
  }
  let pinned;
  try { pinned = await assertPinnedChatContext(state, "report_delivery_reconciliation"); }
  catch (error) { return { ok: false, error: String(error?.message || error), state: error.state || await getState() }; }
  let response;
  try {
    response = await sendChat(pinned.tab.id, {
      type: "AF_CAPTURE_RECONCILE_REPORT",
      search_id: state.search_id,
      report_text: state.report,
      previous_anchor_turn_id: state.anchor_turn_id || "",
      expected_identity: pinned.context
    });
  } catch (error) { response = { ok: false, error: String(error?.message || error) }; }
  if (!response?.ok || !Core.sameConversationIdentity(pinned.context, response.identity)) {
    const next = await saveState({ ...state, status: "REPORT_DELIVERY_UNCERTAIN", phase: "CHATGPT_REPORT_RECONCILIATION", blocked_reason: response?.error || "REPORT_RECONCILE_CONTEXT_UNCONFIRMED" });
    await log("REPORT_RECONCILIATION_BLOCKED", { search_id: next.search_id, reason: next.blocked_reason });
    return { ok: false, error: next.blocked_reason, state: next };
  }
  if (response.state === "confirmed" && response.anchor_turn_id) {
    await storageRemove([INSPECTION_KEY]);
    const waiting = await saveState({ ...state, status: "WAITING_FOR_NEXT_ASSISTANT_FORM", phase: "CHATGPT_CONTINUATION", anchor_turn_id: response.anchor_turn_id, report: null, report_kind: null, report_delivery_id: null, sequential_review: continuationSequentialCheckpoint(state.sequential_review), blocked_reason: null });
    const poll = await sendChat(pinned.tab.id, { type: "AF_CAPTURE_BEGIN_PROMPT_POLL", search_id: waiting.search_id, conversation_id: waiting.conversation_id, anchor_turn_id: response.anchor_turn_id, expected_identity: pinned.context });
    const final = poll?.ok ? await saveState({ ...(await getState()), status: "WAITING_FOR_NEXT_ASSISTANT_FORM", phase: "CHATGPT_CONTINUATION", anchor_turn_id: response.anchor_turn_id, blocked_reason: null }) : await saveState({ ...(await getState()), status: "WAITING_FOR_NEXT_ASSISTANT_FORM", phase: "CHATGPT_CONTINUATION", blocked_reason: poll?.error || "NEXT_FORM_POLL_START_FAILED" });
    await log("REPORT_RECONCILED_CONFIRMED", { search_id: final.search_id, anchor_turn_id: response.anchor_turn_id });
    return { ok: true, state: final };
  }
  const nextStatus = response.state === "staged" ? "REPORT_READY_IN_COMPOSER" : "REPORT_DELIVERY_UNCERTAIN";
  const next = await saveState({ ...state, status: nextStatus, phase: "CHATGPT_REPORT_RECONCILIATION", blocked_reason: nextStatus === "REPORT_READY_IN_COMPOSER" ? "REPORT_STILL_IN_PRIMARY_COMPOSER" : "REPORT_ABSENT_AFTER_UNCERTAIN_SEND" });
  await log("REPORT_RECONCILED_NOT_CONFIRMED", { search_id: next.search_id, response_state: response.state || "absent" });
  return { ok: true, state: next };
}
async function begin() {
  const prior = await getState();
  if (prior.report && ["REPORT_DELIVERY_BLOCKED", "REPORT_DELIVERY_IN_PROGRESS", "REPORT_READY_IN_COMPOSER", "REPORT_DELIVERY_UNCERTAIN"].includes(prior.status)) return reconcileBlockedReport(prior);
  let active;
  try { active = await captureActiveChatContext(); } catch (error) {
    const state = await saveState(Core.makeState({ status: "ACTIVE_CHATGPT_CONTEXT_REQUIRED", phase: "CHATGPT_START", blocked_reason: String(error?.message || error), user_started: true })); await log("START_BLOCKED", { search_id: state.search_id, reason: state.blocked_reason }); return { ok: false, state, error: state.blocked_reason };
  }
  const searchId = Core.makeSearchId(); let state = await saveState(Core.makeState({ search_id: searchId, status: "STARTING_BRIDGE_EXACT_CAPTURE", phase: "CHATGPT_START", started_at: new Date().toISOString(), current_window_id: active.context.window_id, chatgpt_tab_id: active.context.tab_id, chatgpt_window_id: active.context.window_id, chat_origin: active.context.origin, chat_path: active.context.chat_path, conversation_id: active.context.conversation_id, user_started: true, inspection_only: true, report: null, avito_tab_id: null, avito_target_bound_once: false, avito_target_binding_source: null, last_route_context: null, route_journal: [], last_context_report_fingerprint: null, sequential_review: null }));
  await log("BRIDGE_EXACT_START_REQUESTED", { search_id: searchId, message_text: "Ищи", tab_id: active.context.tab_id, window_id: active.context.window_id, conversation_id: active.context.conversation_id, chat_path: active.context.chat_path });
  let pinned; try { pinned = await assertPinnedChatContext(state, "chatgpt_start_command"); } catch (error) { return { ok: false, state: error.state || await getState(), error: String(error?.message || error) }; }
  let startResult;
  try { startResult = await sendChat(pinned.tab.id, { type: "AF_CAPTURE_START_AND_ANCHOR", search_id: searchId, message_text: "Ищи", wait_for_conversation_identity: true, expected_identity: pinned.context }); } catch (error) {
    const reason = String(error?.message || error); state = await saveState({ ...state, status: "START_CAPTURE_TRANSPORT_FAILED", phase: "CHATGPT_START", blocked_reason: reason }); await log("START_CAPTURE_TRANSPORT_FAILED", { search_id: searchId, reason }); return { ok: false, state, error: reason };
  }
  if (!startResult?.ok || !startResult.anchor_turn_id || !Core.sameConversationIdentity(pinned.context, startResult.identity)) {
    const reason = startResult?.error || "START_EXACT_ANCHOR_OR_CONTEXT_UNCONFIRMED"; state = await saveState({ ...state, status: "START_CAPTURE_FAILED", phase: "CHATGPT_START", blocked_reason: reason }); await log("START_CAPTURE_FAILED", { search_id: searchId, reason, code: startResult?.code || null }); return { ok: false, state, error: reason };
  }
  state = await saveState({ ...state, status: "WAITING_FOR_ASSISTANT_WRITING_BLOCK", phase: "CHATGPT_CAPTURE", anchor_turn_id: startResult.anchor_turn_id, blocked_reason: null }); await log("BRIDGE_EXACT_START_SENT_AND_ANCHORED", { search_id: searchId, anchor_turn_id: startResult.anchor_turn_id, conversation_id: state.conversation_id, content_script_version: startResult.content_script_version || null });
  const poll = await sendChat(pinned.tab.id, { type: "AF_CAPTURE_BEGIN_PROMPT_POLL", search_id: searchId, conversation_id: state.conversation_id, anchor_turn_id: startResult.anchor_turn_id, expected_identity: pinned.context });
  if (!poll?.ok) { const reason = poll?.error || "PROMPT_POLL_START_FAILED"; state = await saveState({ ...state, status: "PROMPT_POLL_START_FAILED", phase: "CHATGPT_CAPTURE", blocked_reason: reason }); await log("PROMPT_POLL_START_FAILED", { search_id: searchId, reason }); return { ok: false, state, error: reason }; }
  await log("BRIDGE_EXACT_PROMPT_POLL_STARTED", { search_id: searchId, anchor_turn_id: startResult.anchor_turn_id, conversation_id: state.conversation_id }); return { ok: true, state };
}
function validationErrorReport(state, parsed, text) {
  const mode = parsed.mode || "не определён";
  const errors = Array.isArray(parsed.errors) && parsed.errors.length ? parsed.errors.join("; ") : "LOCAL_VALIDATOR_UNSPECIFIED";
  return [
    "Avito Finder: локальный валидатор не смог подготовить действие.",
    "",
    `Задача: ${state.search_id || "?"}`,
    `Текст writing block получен полностью: ${Core.fingerprint(text)}`,
    `Определённый режим: ${mode}`,
    `Причины: ${errors}`,
    "",
    "На Avito ничего не открывалось и не изменялось.",
    "Расширение вернуло ошибку в этот же чат. Следующая команда может быть обычным текстом: фиксированный шаблон не требуется."
  ].join("\n");
}
async function returnValidationErrorToPinnedChat(state, parsed, text) {
  const report = validationErrorReport(state, parsed, text);
  const staged = await saveState({ ...state, status: "VALIDATION_ERROR_REPORT_READY", phase: "LOCAL_EXTENSION_VALIDATION", command_mode: parsed.mode || null, diagnostic_request: null, ui_action_plan: null, blocked_reason: (parsed.errors || []).join("; "), report, report_kind: "validation_error" });
  await log("LOCAL_COMMAND_VALIDATION_FAILED", { search_id: staged.search_id, errors: parsed.errors || [], mode: parsed.mode || null, mode_source: parsed.mode_source || null, text_fingerprint: Core.fingerprint(text) });
  await log("VALIDATION_ERROR_REPORT_READY", { search_id: staged.search_id, report_fingerprint: Core.fingerprint(report), report_kind: "validation_error" });
  return deliverReportToPinnedChat(staged, report, "validation_error");
}
function avitoRuntimeFailureReport(state, reason) {
  return [
    "Avito Finder: действие на Avito остановлено безопасно.",
    "",
    `Задача: ${state.search_id || "?"}`,
    `Этап: ${state.phase || "AVITO_TASK"}`,
    `Причина: ${reason || "AVITO_TASK_FAILED"}`,
    "",
    "Повторные клики, ввод и навигация автоматически не выполнялись.",
    "Расширение вернуло этот отчёт в тот же чат и продолжает ожидать следующую форму."
  ].join("\n");
}
async function returnAvitoRuntimeFailureToPinnedChat(state, reason) {
  const report = avitoRuntimeFailureReport(state, reason);
  const staged = await saveState({
    ...state,
    status: "AVITO_FAILURE_REPORT_READY",
    phase: "AVITO_FAILURE",
    blocked_reason: reason,
    report,
    report_kind: "avito_failure"
  });
  await log("AVITO_FAILURE_REPORT_READY", { search_id: staged.search_id, reason, report_fingerprint: Core.fingerprint(report) });
  return deliverReportToPinnedChat(staged, report, "avito_failure");
}

async function handleFullText(message, sender) {
  let state = await getState(); const candidate = message.candidate && typeof message.candidate === "object" ? message.candidate : {};
  if (!state.search_id || candidate.run_id !== state.search_id) return { ok: true, data: { ignored: true, reason: "SEARCH_ID_MISMATCH" } };
  if (sender?.tab?.id !== state.chatgpt_tab_id) return { ok: true, data: { ignored: true, reason: "SENDER_TAB_MISMATCH" } };
  const expected = contextFromState(state); const actual = { tab_id: sender?.tab?.id ?? null, window_id: sender?.tab?.windowId ?? null, origin: candidate.origin, chat_path: candidate.chat_path, conversation_id: candidate.conversation_id };
  if (!Core.samePinnedChatContext(expected, actual)) {
    const next = await blockConversationContext(state, "FULL_TEXT_CONTEXT_MISMATCH", { actual_conversation_id: actual.conversation_id, actual_chat_path: actual.chat_path, actual_tab: shortTab(sender?.tab) });
    return { ok: true, data: { ignored: true, reason: next.blocked_reason } };
  }
  if (candidate.anchor_turn_id !== state.anchor_turn_id) {
    // A late Copy reply from the prior form is normal around report delivery.
    // Ignore it without changing the pinned conversation or cancelling the newer
    // anchor wait. The current content script will keep waiting for the current
    // same-chat assistant form.
    await log("STALE_FORM_CANDIDATE_IGNORED", { search_id: state.search_id, expected_anchor_turn_id: state.anchor_turn_id, actual_anchor_turn_id: candidate.anchor_turn_id || null, assistant_turn_id: candidate.assistant_turn_id || null, sender_tab_id: sender?.tab?.id ?? null });
    return { ok: true, data: { ignored: true, reason: "STALE_ANCHOR_CANDIDATE", debug: { expected_anchor_turn_id: state.anchor_turn_id, actual_anchor_turn_id: candidate.anchor_turn_id || null, anchor_matches: false } } };
  }
  const text = String(candidate.prompt_text || "");
  const normalizedText = Core.normalizeText(text);
  const claimedPayloadBytes = Number(candidate.payload_bytes || 0);
  // Defense in depth: an old or interrupted content script can never turn a
  // zero-byte renderer shell into a same-chat MODE_UNRESOLVED report. This
  // guard runs before deduplication, state mutation, validation and delivery.
  if (candidate.payload_extracted !== true || !normalizedText || claimedPayloadBytes <= 0) {
    await log("EMPTY_WRITING_BLOCK_CANDIDATE_IGNORED", {
      search_id: state.search_id,
      anchor_turn_id: state.anchor_turn_id,
      assistant_turn_id: candidate.assistant_turn_id || null,
      payload_extracted: candidate.payload_extracted === true,
      payload_bytes: claimedPayloadBytes,
      text_fingerprint: Core.fingerprint(text),
      poll_generation: candidate.poll_generation ?? null
    });
    return {
      ok: true,
      data: {
        ignored: true,
        waiting_payload_extraction: true,
        reason: "EMPTY_WRITING_BLOCK_PAYLOAD_IGNORED"
      }
    };
  }
  const formKey = String(candidate.form_key || `${candidate.anchor_turn_id || ""}|${candidate.assistant_turn_id || ""}|${Core.fingerprint(text)}`);
  if (state.last_consumed_form_key && state.last_consumed_form_key === formKey) {
    await log("DUPLICATE_FORM_CANDIDATE_IGNORED", { search_id: state.search_id, anchor_turn_id: state.anchor_turn_id, assistant_turn_id: candidate.assistant_turn_id || null, form_key: formKey, poll_generation: candidate.poll_generation ?? null });
    return { ok: true, data: { ignored: true, reason: "DUPLICATE_FORM_CANDIDATE" } };
  }
  await log("FULL_WRITING_BLOCK_TEXT_RECEIVED", { search_id: state.search_id, anchor_turn_id: state.anchor_turn_id, assistant_turn_id: candidate.assistant_turn_id || null, payload_bytes: Number(candidate.payload_bytes || 0), payload_extracted: candidate.payload_extracted === true, text_fingerprint: Core.fingerprint(text), form_key: formKey, poll_generation: candidate.poll_generation ?? null });
  state = await saveState({ ...state, status: "FORM_TEXT_CAPTURED_UNVALIDATED", phase: "LOCAL_EXTENSION_VALIDATION", assistant_turn_id: candidate.assistant_turn_id || null, last_consumed_form_key: formKey, blocked_reason: null });
  const parsed = Core.parseCommandForm(text); await log("LOCAL_COMMAND_VALIDATION_COMPLETED", { search_id: state.search_id, valid: parsed.valid, errors: parsed.errors, mode: parsed.mode, mode_source: parsed.mode_source, candidate_count: parsed.candidate_count, candidate_count_source: parsed.candidate_count_source, text_fingerprint: Core.fingerprint(text), form_key: formKey });
  if (!parsed.valid) {
    const delivered = await returnValidationErrorToPinnedChat(state, parsed, text);
    return { ok: true, data: { accepted: true, disposition: "continuation_started", continuation_anchor_turn_id: delivered.anchor_turn_id || null, validation_error_reported: delivered.status === "WAITING_FOR_NEXT_ASSISTANT_FORM", reason: "COMMAND_INVALID_AFTER_FULL_COPY" } };
  }
  if (parsed.mode === "SEARCH") {
    const report = "Avito Finder: локальный валидатор получил команду SEARCH, но этап 5 ТЗ ещё не реализован. Avito не изменялся.";
    const staged = await saveState({ ...state, status: "SEARCH_NOT_IMPLEMENTED_REPORT_READY", phase: "COMMAND_CAPTURED", command_mode: "SEARCH", blocked_reason: "SEARCH_NOT_IMPLEMENTED", report, report_kind: "validation_error" });
    const delivered = await deliverReportToPinnedChat(staged, report, "validation_error");
    return { ok: true, data: { accepted: true, disposition: "continuation_started", continuation_anchor_turn_id: delivered.anchor_turn_id || null, validation_error_reported: delivered.status === "WAITING_FOR_NEXT_ASSISTANT_FORM", reason: "SEARCH_NOT_IMPLEMENTED" } };
  }
  state = await saveState({ ...state, status: "COMMAND_CAPTURED", phase: "COMMAND_CAPTURED", command_mode: parsed.mode, diagnostic_request: parsed.diagnostic || null, ui_action_plan: parsed.ui_plan || null, blocked_reason: null });
  queueAvitoTask(state, parsed).catch(async (error) => {
    const reason = String(error?.message || error);
    const latest = await getState();
    if (latest.search_id !== state.search_id || latest.status === "CANCELLED_BY_USER") return;
    const pageReadyFailure = /^AVITO_(?:PAGE_READY_TIMEOUT|PAGE_NOT_READY|TAB_MISSING|TAB_CLOSED|TAB_WINDOW_MISMATCH|TAB_READ_FAILED)/.test(reason);
    const failed = await saveState({ ...latest, status: pageReadyFailure ? "BLOCKED_AVITO_PAGE_READY" : "FAILED_WITH_EVIDENCE", phase: latest.phase || "AVITO_TASK", blocked_reason: reason });
    await log(pageReadyFailure ? "AVITO_PAGE_READY_BLOCKED" : "AVITO_TASK_BLOCKED", { search_id: state.search_id, reason });
    // Bridge-style handoff invariant: after an accepted writing block, every
    // terminal local failure becomes a same-chat user-turn report. A failure may
    // never leave the capture poll stopped behind an assistant writing block.
    await returnAvitoRuntimeFailureToPinnedChat(failed, reason);
  });
  return { ok: true, data: { accepted: true, disposition: "avito_task_queued" } };
}
async function resumeSequentialReviewFromPopup(state) {
  const checkpoint = state?.sequential_review;
  if (!checkpoint || !Array.isArray(checkpoint.candidates) || checkpoint.status === "completed") return { ok: false, error: "NO_RESUMABLE_SEQUENTIAL_REVIEW" };
  const parent = await getTab(checkpoint.parent_tab_id);
  if (!parent || parent.windowId !== checkpoint.parent_window_id || !Core.isAvitoUrl(parent.url || "")) return { ok: false, error: "SEQUENTIAL_PARENT_TAB_MISSING" };
  const plan = { page_url: parent.url, timing_profile: "COLLECTION_FAST", steps: [{ type: "RESUME_EXPLICIT_LISTING_QUEUE", source_line: "popup_resume_explicit_queue" }], plan_fingerprint: Core.fingerprint("popup_resume_explicit_queue") };
  const staged = await saveState({ ...state, status: "COMMAND_CAPTURED", phase: "SEQUENTIAL_REVIEW_RESUME_REQUESTED", command_mode: "AVITO_UI", ui_action_plan: plan, avito_tab_id: parent.id, blocked_reason: null });
  await log("SEQUENTIAL_REVIEW_POPUP_RESUME_REQUESTED", { search_id: staged.search_id, parent_tab_id: parent.id, cursor: checkpoint.cursor || 0, captcha_child_tab_id: checkpoint.captcha?.child_tab_id || null });
  queueAvitoTask(staged, { mode: "AVITO_UI", ui_plan: plan }).catch(async (error) => {
    const current = await getState();
    if (current.search_id !== staged.search_id || current.status === "CANCELLED_BY_USER") return;
    const reason = String(error?.message || error);
    const failed = await saveState({ ...current, status: "FAILED_WITH_EVIDENCE", phase: "SEQUENTIAL_REVIEW_RESUME", blocked_reason: reason });
    await log("SEQUENTIAL_REVIEW_RESUME_BLOCKED", { search_id: failed.search_id, reason });
    await returnAvitoRuntimeFailureToPinnedChat(failed, reason);
  });
  return { ok: true, data: { resumed: true, search_id: staged.search_id } };
}
async function continueReport() {
  const state = await getState();
  if (["REPORT_DELIVERY_BLOCKED", "REPORT_DELIVERY_IN_PROGRESS", "REPORT_READY_IN_COMPOSER", "REPORT_DELIVERY_UNCERTAIN"].includes(state.status) && state.report) return reconcileBlockedReport(state);
  if (state.sequential_review && ["WAITING_FOR_NEXT_ASSISTANT_FORM", "SEQUENTIAL_REVIEW_PAUSED", "PAUSED_USER_COMPOSER_OCCUPIED"].includes(state.status)) return resumeSequentialReviewFromPopup(state);
  if (state.status !== "PAUSED_USER_COMPOSER_OCCUPIED" || !state.report) return { ok: false, error: "NO_PENDING_REPORT" };
  const fallbackKind = state.command_mode === "DIAGNOSE_DOM" ? "diagnostic" : (state.command_mode === "AVITO_UI" ? "ui_action_plan" : "inspection");
  const result = await deliverReportToPinnedChat(state, state.report, state.report_kind || fallbackKind);
  return { ok: true, state: result };
}
async function stop() {
  const old = await getState(); clearAvitoReadyDeadline(old.search_id); clearUiClickReconcileDeadline(old.search_id);
  if (old.chatgpt_tab_id && old.conversation_id) { try { const pinned = await assertPinnedChatContext(old, "chatgpt_stop"); await sendChat(pinned.tab.id, { type: "AF_CAPTURE_STOP", expected_identity: pinned.context }); } catch (error) { await log("CAPTURE_STOP_CONTEXT_BLOCKED", { search_id: old.search_id, reason: String(error?.message || error) }); } }
  const state = await saveState({ ...old, status: "CANCELLED_BY_USER", phase: "STOPPED", blocked_reason: "CANCELLED_BY_USER", user_started: false }); await log("STOPPED_BY_USER", { search_id: state.search_id }); return state;
}
async function view() { await reconcilePendingAvitoReadiness(); await reconcilePendingUiClickHandoff(); const raw = await storageGet([STATE_KEY, LOG_KEY, INSPECTION_KEY]); return { ok: true, state: Core.makeState(raw[STATE_KEY] || {}), logs: raw[LOG_KEY] || [], inspection: raw[INSPECTION_KEY] || null }; }
async function recoverContinuousPromptPoll(message, sender) {
  const state = await getState();
  if (state.status !== "WAITING_FOR_NEXT_ASSISTANT_FORM" || !state.search_id || !state.anchor_turn_id) return { ok: true, data: { resume: false } };
  const expected = contextFromState(state);
  const actual = { tab_id: sender?.tab?.id ?? null, window_id: sender?.tab?.windowId ?? null, origin: message?.identity?.origin || null, chat_path: message?.identity?.chat_path || null, conversation_id: message?.identity?.conversation_id || null };
  if (!Core.samePinnedChatContext(expected, actual)) {
    const next = await blockConversationContext(state, "CONTINUATION_RECOVERY_CONTEXT_MISMATCH", { actual_conversation_id: actual.conversation_id, actual_chat_path: actual.chat_path, actual_tab: shortTab(sender?.tab) });
    return { ok: true, data: { resume: false, blocked: true, reason: next.blocked_reason } };
  }
  await log("NEXT_FORM_POLL_RECOVERY_GRANTED", { search_id: state.search_id, anchor_turn_id: state.anchor_turn_id, chatgpt_tab_id: state.chatgpt_tab_id });
  return { ok: true, data: { resume: true, search_id: state.search_id, conversation_id: state.conversation_id, anchor_turn_id: state.anchor_turn_id, expected_identity: expected } };
}
async function contextBlockedFromContent(message, sender) { const state = await getState(); if (!state.search_id || message.search_id !== state.search_id || sender?.tab?.id !== state.chatgpt_tab_id) return { ok: true, data: { ignored: true } }; const next = await blockConversationContext(state, message.reason || "CONTENT_CONTEXT_CHANGED", { actual_conversation_id: message.actual_identity?.conversation_id || null, actual_chat_path: message.actual_identity?.chat_path || null, actual_tab: shortTab(sender?.tab) }); return { ok: true, data: { blocked: true, state: next } }; }

if (globalThis.__AF_TEST_EXPORTS) {
  globalThis.__AF_TEST_EXPORTS.debuggerInput = { DEBUGGER_ALLOWED_METHODS, validDebuggerBounds, validDebuggerText, validDebuggerOptionText, debuggerSend, inputMouseFocus, inputClearExistingValue, typeVisibleAvitoTargetWithDebugger, clickVisibleTargetWithDebugger, clickVisibleOptionWithDebugger };
  globalThis.__AF_TEST_EXPORTS.uiClickHandoff = { asyncResponseChannelClosed, pendingUiClickMatches, expectedNavigationPathMatches, pendingChildTabIds, isPendingUiClickChildTab, pendingUiClickNavigationMatches };
  globalThis.__AF_TEST_EXPORTS.targetBinding = { ensureAvitoTarget, selectVisibleAvitoTab };
}
chrome.runtime.onInstalled.addListener(async () => { const current = await getState(); await saveState(current); await log("EXTENSION_INSTALLED_OR_UPDATED", { version: chrome.runtime.getManifest().version }); });
chrome.tabs.onCreated.addListener((tab) => { (async () => {
  const accepted = await rememberPendingUiClickChildTab(tab, "tabs.onCreated");
  if (accepted) reconcilePendingUiClickHandoff().catch(() => {});
})().catch(() => {}); });
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => { (async () => {
  if (tab) await rememberPendingUiClickChildTab(tab, "tabs.onUpdated");
  reconcilePendingAvitoReadiness().catch(async (error) => { const state = await getState(); if (state.status === "WAITING_FOR_AVITO_PAGE_READY") await blockAvitoPageReady(state, `AVITO_READY_EVENT_FAILED:${String(error?.message || error)}`); });
  reconcilePendingUiClickHandoff().catch(async (error) => { const state = await getState(); if (state.status === "WAITING_FOR_UI_CLICK_RECONCILIATION") await finishUiClickReconciliationFailure(state, `UI_CLICK_RECONCILIATION_EVENT_FAILED:${String(error?.message || error)}`); });
  if (changeInfo.status === "complete") setTimeout(() => { observeManualContextChange(tabId, "VISIBLE_AVITO_CONTEXT_CHANGED").catch(() => {}); }, 450);
})().catch(() => {}); });
chrome.tabs.onRemoved.addListener((tabId) => { (async () => {
  const state = await getState();
  if (state.status === "WAITING_FOR_AVITO_PAGE_READY" && state.avito_tab_id === tabId) await blockAvitoPageReady(state, `AVITO_TAB_CLOSED:${tabId}`, { source: "tabs.onRemoved" });
  if (state.status === "WAITING_FOR_UI_CLICK_RECONCILIATION" && state.avito_tab_id === tabId) await finishUiClickReconciliationFailure(state, `UI_CLICK_RECONCILIATION_TAB_CLOSED:${tabId}`);
  await reportAvitoTabClosed(tabId);
})().catch(() => {}); });
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => { (async () => { try {
  switch (message?.type) {
    case "AF_START": sendResponse(await begin()); return;
    case "AF_STOP": sendResponse({ ok: true, state: await stop() }); return;
    case "AF_CONTINUE_REPORT": sendResponse(await continueReport()); return;
    case "AF_GET_VIEW": sendResponse(await view()); return;
    case "AF_CAPTURE_PING": sendResponse({ ok: false, error: "PING_IS_CONTENT_ONLY" }); return;
    case "AF_CAPTURE_GET_SEND_PROFILE": sendResponse({ ok: true, data: null }); return;
    case "AF_CAPTURE_DIAGNOSTIC": await log(`CAPTURE_${message.details?.code || "DIAGNOSTIC"}`, diagnosticFields(message.details)); sendResponse({ ok: true, data: { recorded: true } }); return;
    case "AF_CAPTURE_ACTIVITY": await log("CAPTURE_ACTIVITY", diagnosticFields(message)); sendResponse({ ok: true, data: { recorded: true } }); return;
    case "AF_CAPTURE_CONTEXT_BLOCKED": sendResponse(await contextBlockedFromContent(message, sender)); return;
    case "AF_CAPTURE_FULL_TEXT": sendResponse(await handleFullText(message, sender)); return;
    case "AF_DEBUGGER_TYPE_VISIBLE_TARGET": sendResponse(await typeVisibleAvitoTargetWithDebugger(message, sender)); return;
    case "AF_DEBUGGER_CLICK_VISIBLE_TARGET": sendResponse(await clickVisibleTargetWithDebugger(message, sender)); return;
    case "AF_DEBUGGER_CLICK_VISIBLE_OPTION": sendResponse(await clickVisibleOptionWithDebugger(message, sender)); return;
    case "AF_UI_CLICK_DISPATCHED": sendResponse(await recordUiClickDispatched(message, sender)); return;
    case "AF_CAPTURE_RECOVER_CONTINUOUS": sendResponse(await recoverContinuousPromptPoll(message, sender)); return;
    default: sendResponse({ ok: false, error: "UNKNOWN_MESSAGE" }); return;
  }
} catch (error) { sendResponse({ ok: false, error: String(error?.message || error) }); } })(); return true; });
