# Avito Finder — единая каноническая функциональная спецификация

**Статус:** собрана по приложенной истории `Доки(10).zip`, включая каноническую историю `AVITO_FINDER_HISTORY_CANONICAL(5).md`.  
**Актуальный описанный кандидат:** `v0.8.5 proactive anchor-navigation handoff` (test candidate; не считать полностью принятой live-релизной версией без отдельной проверки в пользовательском Chrome).  
**Правило файла:** это один канонический Markdown-документ. Следующие изменения добавляются только новым разделом в конец; ранее описанные функции не удаляются и не переписываются без явной записи о замене, причине, рисках и регрессионной проверке.

> В приложенной истории есть описание Avito Finder, а не Business Bridge. Поэтому этот документ относится только к **Avito Finder**.  
> История содержит функциональный контракт и отдельные имена runtime-функций, но не полный исходный код последнего пакета. Ни один недокументированный визуальный элемент не придуман: если история не подтверждает название или наличие элемента, это указано прямо.

---

## 1. Назначение

Avito Finder — изолированное Chrome-расширение Manifest V3 для работы с уже открытой пользовательской Chrome-сессией. Оно получает команду только из одной закреплённой беседы ChatGPT, выполняет ограниченные действия только через видимый публичный интерфейс Avito и возвращает ограниченный отчёт в ту же беседу.

Расширение:

- не принимает решение о покупке;
- не пишет продавцам;
- не показывает телефон;
- не оформляет покупку, доставку, бронь или оплату;
- не использует скрытые API, cookies, сетевые перехваты или произвольный JavaScript на Avito;
- не использует Business Bridge runtime, очередь, сервер, storage, task ID или журналы.

---

## 2. Неподвижные границы безопасности

### 2.1. Разрешённые источники и действия

Разрешено только:

1. Работать в текущем пользовательском профиле Chrome.
2. Привязываться к одной активной закреплённой беседе ChatGPT.
3. Отправить в нижний composer точное слово `Ищи` после явного запуска.
4. Прочитать только следующий подходящий assistant writing block через его локальную кнопку Copy.
5. Локально разобрать полный текст блока.
6. Работать с одной run-owned вкладкой Avito в том же окне.
7. Читать ограниченные видимые публичные области страницы.
8. Выполнять только явно валидированные действия по видимым, доступным указателю элементам.
9. Использовать Chrome Debugger только для:
   - `Input.dispatchMouseEvent`;
   - `Input.dispatchKeyEvent`.

### 2.2. Строго запрещено

Запрещены:

- `Runtime`, `Network`, `Fetch`, `Page`, `DOM`, `Storage`, `Target` и другие CDP-домены;
- чтение cookie, local/session storage сайта, hidden/preloaded state;
- скрытые API, XHR/fetch, сетевой сбор;
- выполнение JavaScript, переданного ChatGPT;
- обход CAPTCHA, proxy/VPN-манипуляции;
- контакт с продавцом, кнопки «Написать», «Показать телефон», «Купить»;
- покупка, оплата, доставка, бронирование, сохранение объявления, жалобы;
- перезапись пользовательского текста в composer;
- переход по URL, переданному в форме, если это изменяет уже привязанную run-owned вкладку Avito;
- автоматический повтор click после навигации или закрытия message channel;
- массовая очистка вкладок, очередей или состояния другой системы.

---

## 3. Компоненты расширения и их функции

| Компонент | Назначение | Подтверждённые функции |
|---|---|---|
| `popup.html`, `popup.js`, `popup.css` | Видимая панель управления расширением | Старт, Stop, статус, живой журнал, показ паузы, кнопка продолжения отчёта при занятом composer. |
| `service_worker.js` | Координация run, вкладок, хранения и переходов между ChatGPT и Avito | Закрепляет ChatGPT-контекст, принимает полный текст формы, валидирует режим, создаёт/переиспользует Avito target, хранит состояние одного run, доставляет отчёт, ведёт continuation, хранит факт click до dispatch, выполняет reconciliation после навигации. |
| `chatgpt_content.js` | Работа только в закреплённой ChatGPT-беседе | Отправляет `Ищи`, ждёт точный user anchor, находит assistant writing block после anchor, ждёт стабильность структуры, нажимает локальную Copy ровно один раз, передаёт полный текст worker, доставляет отчёт в тот же чат. |
| `core.js` | Локальный разбор и нормализация команд | Валидирует режим, границы команд, действия AVITO_UI, текст, scope, fingerprint, формирует безопасный отчёт без полного raw payload. |
| `avito_content.js` | Ограниченная работа с видимым DOM Avito | Снимки разрешённых scope, видимые filter candidates, run-scoped target checks, trusted TYPE/CLICK, меню, выбор опции, card-bound listing collection, passport открытой карточки. |
| `manifest.json` | MV3-описание и permissions | Изолированный manifest Avito Finder; не должен разделять runtime/keys с Business Bridge. |
| `chrome.storage.local` c префиксом `avito_finder.*` | Локальное сохранение статуса, журнала, run binding и click reconciliation | Обновление popup через `chrome.storage.onChanged`; никаких общих ключей с Business Bridge. |

---

## 4. Полный инвентарь popup и всех документированных элементов управления

### 4.1. Popup расширения

| Элемент | Когда доступен | Что делает | Что не делает |
|---|---|---|---|
| **«Начать обследование» / «Начать»** | В popup, до активного run | Запускает один новый Avito Finder run; требует, чтобы активная вкладка последнего активного окна была нужной ChatGPT-беседой; затем stage-ит и отправляет точное `Ищи`. | Не ищет другую вкладку ChatGPT, не заменяет чужой draft, не открывает несколько Avito-вкладок. |
| **«Стоп»** | Во время ожидания/работы run | Останавливает текущий run, prompt watcher и ожидание готовности Avito; дальнейшее выполнение текущего плана прекращается безопасно. | Не удаляет сообщения, не отправляет текст в другой чат, не повторяет click. |
| **Статус** | Всегда при открытом popup | Показывает текущую понятную фазу или код блокировки. | Не маскирует ошибку общей фразой без кода. |
| **«Живой журнал»** | Всегда при открытом popup | Показывает audit/status/journal события; обновляется через `chrome.storage.onChanged` и периодическое обновление во время ожидания. | Не содержит cookies, raw DOM, секреты, полный текст формы или скрытые данные. |
| **Отчёт/блок результата** | После действия или ошибки | Показывает безопасный итог, причину блока и ключевые этапы. | Не заменяет доставку отчёта в закреплённый ChatGPT-чат. |
| **«Продолжить отчёт»** | Только при `PAUSED_USER_COMPOSER_OCCUPIED` | Повторно пытается доставить уже подготовленный отчёт после того, как пользователь освободил нижний composer. | Не стирает и не заменяет пользовательский draft. |
| **Кастомный крестик закрытия popup** | Не подтверждён историей | Отдельный кнопочный элемент «×» не описан. Нельзя утверждать, что он существует. | Нельзя приписывать ему Stop, очистку состояния или закрытие run без исходного кода/живой проверки. |
| **Стандартное закрытие popup браузером** | Встроенное поведение Chrome | Popup может закрыться при потере фокуса браузерным механизмом. | Не является документированной кнопкой Stop и не должен автоматически отменять run без отдельно описанного поведения. |

### 4.2. Визуальные элементы ChatGPT, которые использует расширение

| Элемент | Правило |
|---|---|
| Нижний composer | Используется только для `Ищи` и для возврата отчёта; чужой непустой draft блокирует действие. |
| Send | Нажимается только после staging точного сообщения/отчёта и подтверждения нужного composer. |
| Новый user turn `Ищи` | Это единственный стартовый anchor. Другой новый user turn не принимается как anchor. |
| Assistant writing block | Принимается только после current anchor и после структурной проверки. |
| Локальная Copy в writing block | Нажимается ровно один раз только у выбранного локального блока. |
| Expand рядом с writing block | Может быть частью observed ChatGPT UI; это не самостоятельная команда Avito Finder и не основание читать другой блок. |
| Edit | Не является обязательным условием capture. История фиксирует, что требование одновременного Edit+Copy было ошибкой. |

### 4.3. Визуальные элементы Avito, с которыми расширение может работать

Расширение не привязано к постоянным CSS-селекторам, конкретному городу или конкретному классу элемента. Любое действие проходит только после локальной видимой проверки.

| Элемент/поверхность | Разрешённое действие | Обязательные ограничения |
|---|---|---|
| Публичная главная/результаты Avito | `SNAPSHOT`, `DIAGNOSE_DOM`, `INSPECT_FILTERS` | Только run-owned tab, один закреплённый target. |
| Диалог выбора города | `SNAPSHOT`, `TYPE`, `COLLECT_MENU`, `SELECT_OPTION`, `CLICK` по валидированному visible control | Только один открытый видимый dialog; точный target должен быть видимым и pointer-reachable. |
| Поле города | `TYPE` | Только trusted keyboard lifecycle `keyDown → char → keyUp`; не подставлять value программно. |
| Видимое меню/список городов | `COLLECT_MENU`, `SELECT_OPTION` | Строка должна быть свежей, связанной с текущим typed query, видимой, интерактивной и точной. |
| Чекбокс «Сначала в выбранном городе» | Проверка/validated visible click при плане | Должен быть явно подтверждён enabled до применения города. |
| Кнопка применения/сохранения города | `CLICK` | Только после visible validation; dispatch записывается до mouse input; click не повторяется автоматически. |
| Поисковое поле | `TYPE` | Только после видимого ancestry/evidence и только через trusted input. |
| Видимая кнопка поиска | `CLICK` | Только после target validation; после навигации выполняется только read-only остаток плана. |
| Filter surface / price controls | `INSPECT_FILTERS`, `FILTERS_VISIBLE` | Только чтение public visible metadata; никаких price value apply без отдельного валидированного плана. |
| Карточка выдачи | `COLLECT_LISTINGS` | Только title anchor `a[data-marker='item-title']` и ближайшая видимая card-bound область. |
| Ссылка заголовка объявления | `CLICK` | Один реальный debugger mouse lifecycle; после смены URL старый документ прекращает план. |
| Открытая карточка объявления | `COLLECT_LISTING_DETAILS` | Только при доказанной listing-public surface; `h1` выдачи не считается паспортом объявления. |
| «Написать», «Показать телефон», «Купить», отзывы, профиль продавца | Никогда | Не выбираются как targets и не вызываются. |

---

## 5. Командные режимы и действия

### 5.1. Режимы

| Режим | Назначение | Статус/граница |
|---|---|---|
| `INSPECT_FILTERS` | Read-only наблюдение видимой filter surface и доступных public filter candidates. | Не изменяет фильтры и не запускает поиск. |
| `DIAGNOSE_DOM` | Ограниченный read-only снимок явно названной public области. | Не угадывает scope; неразрешимая область даёт `BLOCKED_SCOPE_UNRESOLVED`. |
| `AVITO_UI` | Ограниченный план действий в видимом Avito UI. | Только перечисленные ниже базовые действия; без селекторов/JS от ChatGPT. |
| `COLLECT_LISTING_DETAILS` | «Публичный паспорт» уже открытого объявления. | Только visible public facts; без контакта, отзывов и профиля. |
| `SEARCH` | Исторически отмечался как отдельный режим. | Прямой произвольный `SEARCH` не должен обходить AVITO_UI и видимые safety gates; история фиксирует этапы, где он был deliberately blocked/not implemented. |

### 5.2. Разрешённые базовые действия `AVITO_UI`

| Действие | Назначение | Проверка до действия | Запрещённое поведение |
|---|---|---|---|
| `CLICK` | Один click по visible validated control/link. | Exact target, visibility, pointer reachability, run-owned tab, action plan fingerprint. | Synthetic `element.click()` как доверенный путь, повтор click после unload, click по seller/purchase controls. |
| `TYPE` | Ввод текста в visible field. | Одно active input context, target visible, safe text plan. | Direct `value=` или произвольное выполнение кода. |
| `WAIT` | Ограниченное ожидание стабильности/навигации. | Bounded duration/event. | Бесконечное ожидание без отчёта. |
| `WAIT_FOR` | Ожидание разрешённого наблюдаемого условия. | Condition описан локальным контрактом. | Ожидание hidden state/API. |
| `SNAPSHOT` | Ограниченный снимок разрешённой visible scope. | Scope должен быть явным/разрешённым. | Full-page HTML, hidden DOM, storage/cookies. |
| `COLLECT_MENU` | Сбор максимум 12 свежих visible menu rows, связанных с последним TYPE. | Temporal + query-correlated + visible + pointer reachable. | Выбор header/nav/default rows, selector от ChatGPT. |
| `SELECT_OPTION` | Выбор одной exact visible option из свежего меню. | Exact normalized text, новая локальная revalidation. | Угадывание, выбор background duplicate, повтор click. |
| `COLLECT_LISTINGS` | Сбор видимых предложений из card-bound результата. | Только title-anchored cards. | Фото/профиль/чат/телефон как независимые карточки. |
| `COLLECT_LISTING_DETAILS` | Сбор public facts открытого объявления. | Listing surface должна быть доказана. | Заголовок страницы выдачи как паспорт объявления. |

---

## 6. Разрешённые read-only scope

| Scope | Содержимое |
|---|---|
| `PAGE_MAIN_VISIBLE` | Ограниченная видимая публичная область основной страницы. |
| `SEARCH_SURFACE_VISIBLE` | Видимая поисковая поверхность и связанные public controls. |
| `DIALOG_VISIBLE` | Один актуальный видимый dialog и ограниченная public control metadata. |
| `LISTING_CARD_VISIBLE` | Ограниченная visible surface одной карточки, только когда она доказана. |
| `REVIEWS_VISIBLE` | Исторически названный диагностический scope; не означает автоматическое открытие отзывов. |
| `FILTERS_VISIBLE` | Видимые non-listing filter candidates: marker/role/type/placeholder/aria-label/title/visible text/discovery source. |

Неразрешимая scope не приводит к угадыванию: возвращается `BLOCKED_SCOPE_UNRESOLVED` или другой точный безопасный код.

---

## 7. Основной жизненный цикл одного run

### 7.1. Старт

```text
Пользователь нажимает «Начать»
→ extension проверяет active ChatGPT tab в last focused window
→ фиксирует tabId + windowId + origin + chat_path + conversationId
→ stage/Send точного «Ищи»
→ ждёт exact new user turn «Ищи»
→ этот turn становится anchor
```

Если composer уже содержит непустой иной draft, запуск блокируется кодом `START_PRIMARY_COMPOSER_OCCUPIED`; текст пользователя не меняется.

### 7.2. Захват следующей команды

```text
anchor
→ следующий assistant writing block
→ локальная Copy readiness
→ минимум 2 секунды неизменной структуры
→ ровно один local Copy
→ полный текст выбранного блока
→ worker-side validation
```

Ключевые правила:

- более ранние блоки не должны приниматься вместо блока после anchor;
- чужой/сменившийся tab, window, URL или conversation блокируют run кодом `BLOCKED_CONVERSATION_CONTEXT_CHANGED`;
- старый callback не может остановить новый watcher: применяется generation fence;
- пустой writing block игнорируется с безопасным событием, а не превращается в план;
- текст валидируется только после полного local Copy.

### 7.3. Переход на Avito

```text
валидная команда
→ reuse одной visible Avito tab в том же окне
  ИЛИ ровно одна initial active public-root Avito tab, если tab ещё нет
→ persist run-owned binding
→ wait same tab + allowed Avito origin + status complete
→ выполнить только разрешённую read-only/UI фазу
```

После первого binding:

- каждый следующий режим использует только этот tab;
- URL из assistant form логируется как `AVITO_COMMAND_URL_IGNORED` и не навигирует tab;
- исчезновение bound tab даёт `RUN_BOUND_AVITO_TARGET_UNAVAILABLE`;
- replacement tab не выбирается и не создаётся.

### 7.4. Отчёт и непрерывный цикл

```text
bounded action / safe error
→ report только в закреплённую ChatGPT-беседу
→ подтверждённый result/error user turn
→ следующий anchor
→ ожидание следующего assistant writing block
```

`Ищи` отправляется только при старте. Между нормальными циклами новый `Ищи` не нужен. Цикл останавливается только по явному Stop/стоп/хватит/завершить или когда ChatGPT сознательно не выдаёт следующий writing block.

---

## 8. Переходы, reconciliation и защита от повторов

### 8.1. Click с возможной навигацией

Перед каждым trusted `CLICK`:

1. content script создаёт ограниченный `AF_UI_CLICK_DISPATCHED`;
2. worker подтверждает active run, tab, plan fingerprint, step index и target descriptor;
3. worker сохраняет `pending_ui_click`;
4. только после этого разрешается mouse input.

При смене URL:

- старый content document останавливает остаток плана с `VISIBLE_ANCHOR_NAVIGATION`;
- worker переводит run в `WAITING_FOR_UI_CLICK_RECONCILIATION`;
- ждёт тот же run-owned tab и новый allowed complete Avito URL;
- исполняет только read-only шаги после click с исходными index;
- второй click никогда не выполняется.

При отсутствии смены URL до deadline: `UI_CLICK_NAVIGATION_UNCONFIRMED`.

### 8.2. Typing и menu

`TYPE` использует `keyDown → char → keyUp` для каждого grapheme. До input запускается короткий local mutation capture.

`COLLECT_MENU` принимает только строки, которые:

- появились/изменились во время текущего capture;
- находятся рядом с активным field;
- visible и pointer-reachable;
- обладают interaction/selection semantics;
- query-correlated: нормализованная public label содержит нормализованный введённый text.

Максимум: 12 строк.  
Если field показывает устойчивую ошибку: `UI_MENU_INPUT_REJECTED`.  
Если видны только нерелевантные строки: `UI_MENU_QUERY_UNMATCHED`.  
Если меню не наблюдается: `UI_MENU_NOT_OBSERVED`.

### 8.3. Выбор опции

`SELECT_OPTION` допускается только для единственной exact normalized label из свежего menu model. Target снова revalidate непосредственно перед click. Background copy, header link, seller control, скрытая или covered node не принимаются.

Исторические adapter-пути для dialog/portal/native-select являются частью эволюции. Текущий функциональный инвариант важнее конкретной DOM-формы: выбор возможен только по наблюдаемому, точному, активному и визуально доступному public варианту, без хардкода города/региона/класса.

---

## 9. Сбор данных

### 9.1. `INSPECT_FILTERS` / `FILTERS_VISIBLE`

Возвращаются только bounded visible non-listing candidates:

- `data-marker`, если публично виден;
- role;
- type;
- placeholder;
- `aria-label`;
- title;
- visible text;
- discovery source.

Listing-card controls исключаются. Если price/filter control не доказан в видимой области, он объявляется недоступным, а не угадывается.

### 9.2. `COLLECT_LISTINGS`

Источником записи может быть только видимый `a[data-marker='item-title']`.

Для каждой записи:

- выбирается ближайший видимый ancestor с ровно одним title anchor;
- title, price, seller и location читаются только из этой же card;
- каждая запись отмечается `{card-bound}`;
- отсутствующая локальная цена остаётся пустой;
- фото, seller-profile, message и phone links не становятся отдельными записями.

### 9.3. `COLLECT_LISTING_DETAILS`

Разрешённые public facts:

- заголовок;
- цена;
- местоположение;
- продавец;
- публично видимый rating/badges;
- доставка;
- число видимых thumbnail;
- «О ноутбуке»;
- «Характеристики»;
- ограниченный видимый текст описания;
- перечень отсутствующих сведений.

Паспорт возвращается только после доказанной listing surface: marker/связанный `item-view` signal либо связка видимых цены и описания. Заголовок выдачи не годится. Видимые телефонные номера маскируются как `[контакт скрыт]`.

---

## 10. Статусы и безопасные коды

| Код/событие | Значение |
|---|---|
| `START_PRIMARY_COMPOSER_OCCUPIED` | В composer есть чужой непустой draft; запуск не меняет его. |
| `BLOCKED_CONVERSATION_CONTEXT_CHANGED` | Пин к tab/window/path/conversation нарушен. |
| `WAITING_FOR_NEXT_ASSISTANT_FORM` | После подтверждённого отчёта extension ждёт следующую форму. |
| `STALE_FORM_CANDIDATE_IGNORED` | Старый callback/кандидат не может вмешаться в новый generation. |
| `COMMAND_INVALID_AFTER_FULL_COPY` | Полный текст взят, но локально не прошёл валидатор. |
| `MODE_UNRESOLVED` | Режим не определён после полного текста. |
| `PAUSED_USER_COMPOSER_OCCUPIED` | Отчёт готов, но composer занят пользователем; доступно «Продолжить отчёт». |
| `AVITO_NAVIGATION_WAIT_STARTED` | Ожидание готовности выбранной Avito-вкладки. |
| `BLOCKED_AVITO_PAGE_READY` | Вкладка не стала допустимой/готовой в пределах ожидания. |
| `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE` | Явно requested existing page не имеет valid run-owned target. |
| `RUN_BOUND_AVITO_TARGET_UNAVAILABLE` | Ранее привязанный target исчез/перемещён/стал недействителен. |
| `AVITO_COMMAND_URL_IGNORED` | URL из команды не применён к bound target. |
| `UI_TARGET_AMBIGUOUS` | Несколько/неясный target; click/type не выполняется. |
| `UI_TARGET_FOCUS_FAILED` | Не удалось подтвердить focus permitted input. |
| `UI_MENU_NOT_OBSERVED` | Видимое меню не наблюдается честно. |
| `UI_MENU_INPUT_REJECTED` | Видимое field error устойчиво подтверждено. |
| `UI_MENU_QUERY_UNMATCHED` | Виден список, но он не относится к текущему query. |
| `UI_OPTION_NOT_VISIBLE` | Exact permitted option не доказана в доступной visible surface. |
| `UI_DEBUGGER_TYPE_FAILED` | Ограниченный trusted key lifecycle не завершился. |
| `UI_DEBUGGER_OPTION_CLICK_FAILED` | Trusted option click не прошёл; report содержит safe stage. |
| `AVITO_UI_CLICK_DISPATCH_RECORDED` | Worker сохранил факт click до dispatch. |
| `WAITING_FOR_UI_CLICK_RECONCILIATION` | Идёт безопасное ожидание результата уже отправленного click. |
| `UI_CLICK_NAVIGATION_UNCONFIRMED` | Нельзя подтвердить навигацию; click не повторяется. |
| `LISTING_PUBLIC_SURFACE_UNAVAILABLE` | Открытая страница не доказана как listing card; паспорт пустой. |
| `BLOCKED_SCOPE_UNRESOLVED` | Требуемая diagnostic scope не найдена однозначно. |

---

## 11. Функции, которые нельзя сломать следующими изменениями

Любая будущая правка должна содержать отдельную матрицу регрессии для каждого пункта.

1. **Start и exact anchor.**  
   `Начать → Ищи → exact new user turn` не должен попасть в другой чат.

2. **Capture writing block.**  
   Только блок после anchor; только одна local Copy; full text до validation; старые callback не отменяют новый watcher.

3. **Непрерывный same-chat цикл.**  
   Report/error → подтверждённый user turn → следующий assistant block → один bounded action; без нового `Ищи`.

4. **Pause отчёта при занятом composer.**  
   Ни один пользовательский draft не заменяется; «Продолжить отчёт» работает только после освобождения composer.

5. **Run-owned Avito target.**  
   Первичное reuse/create разрешено один раз; после bind нет redirect, replacement или reset города/query по URL формы.

6. **Read-only boundary.**  
   `INSPECT_FILTERS`, `DIAGNOSE_DOM`, listing collection и passport не должны click/type/navigation без отдельного валидированного плана.

7. **Trusted visible UI.**  
   `CLICK`, `TYPE`, `SELECT_OPTION` работают только на visible, pointer-reachable, exact permitted targets.

8. **Click reconciliation.**  
   Saved dispatch до input; никакого второго click после unload/navigation; только read-only remainder после подтверждённого URL change.

9. **Menu correctness.**  
   Не выбирать static header/default/stale row; только current query-correlated visible option.

10. **Card-bound listing facts.**  
    Не смешивать цену/продавца/локацию соседних карточек; не принимать photo/profile/message links за listing.

11. **Passport open listing.**  
    Не считать results page паспортом объявления и не открывать контакты/отзывы/профиль.

12. **Изоляция.**  
    Никаких Business Bridge storage, task IDs, очереди, server API или shared runtime.

13. **Безопасность.**  
    Не добавлять network/cookies/hidden API/CDP Runtime/скрытый DOM/seller/payment/captcha функции.

---

## 12. Обязательная матрица перед любой будущей правкой

Перед изменением необходимо зафиксировать для каждой строки:

| Проверяемый контракт | Тест обязателен |
|---|---|
| Start только в active pinned ChatGPT dialog | Multi-tab / changed-dialog regression |
| Composer с draft не перезаписывается | Busy-composer pause test |
| Copy только выбранного блока и один раз | Exact local Copy test |
| Новый report продолжает цикл без нового `Ищи` | Two-consecutive-cycle test |
| Старый watcher не ломает новый | Generation-fence test |
| Bound Avito target не редиректится URL из формы | Target lifecycle test |
| Missing bound target не заменяется новым | Bound-target loss test |
| Temporary executor/browser document unload не повторяет click | Dispatch/reconciliation test |
| Typing и menu видимы и query-correlated | Visible input/menu test |
| Pause/Stop безопасно прекращают active wait | Stop/pause test |
| Не изменяются seller/purchase/payment boundaries | Forbidden-action scan |
| Нет Business Bridge shared code/state | Isolation scan |
| Нет запрещённых CDP/network/storage APIs | Permission/CDP allowlist scan |
| Package совпадает с протестированным source | Source-to-ZIP SHA-256 check |
| Local tests не заменяют live acceptance | Отдельный user-Chrome acceptance record |

---

## 13. Текущая функциональная стадия

По последней записи истории:

- подтверждён живой путь выбора города, включения «Сначала в выбранном городе» и поиска `ноутбуки` в `Златоуст`;
- v0.8.1 добавил наблюдаемую `FILTERS_VISIBLE` surface;
- v0.8.2 сделал card-bound listing collection;
- v0.8.3 добавил public listing passport;
- v0.8.4 заменил synthetic listing click на trusted debugger mouse input и ввёл строгую listing-surface fence;
- v0.8.5 добавил proactive handoff: после click по ссылке старый document не выполняет остаток плана, worker ждёт смену URL и продолжает только read-only остаток.

**Статус остаётся test candidate:** локальные тесты и fixtures не заменяют живую приёмку в пользовательском Chrome.

---

# Приложение A. Краткая append-only история изменений

| Версия/этап | Что изменялось | Зачем |
|---|---|---|
| v0.1.0 | Отдельный MV3, popup Start/Stop/status/journal, read-only DOM inspection | Создать изолированную безопасную основу. |
| v0.1.1 | Recovery отсутствующего content-script получателя | Не падать на допустимой потере receiver. |
| v0.2.0 | Захват команды и read-only filter surface | Перейти от чистого инспектора к bounded command capture. |
| v0.2.1 | Writing block + local Copy | Читать реальную форму вместо неверного контракта. |
| v0.2.2 | Turn anchor, wait формы, честный no-command report | Не брать старый/случайный assistant text. |
| v0.2.3 | Anchor-first Copy-only capture и live journal | Убрать ложный Edit gate и сделать состояние наблюдаемым. |
| v0.2.4–v0.4.3 | Перенос ordering/anchor logic, strict active-dialog binding, page-ready gate | Сделать Start→Ищи→Copy→Avito безопасным и привязанным к одному чату. |
| v0.5.0–v0.5.5 | `DIAGNOSE_DOM`, same-chat report, свободный mode parser, continuous dialogue, target reuse, search ancestry | Добавить bounded diagnostic dialogue без потери pinned context. |
| v0.6.0–v0.6.7 | Generic visible-UI action engine, handoff, continuation fence, snapshot, TYPE, debugger input, dropdown guards, capture watchdog | Перейти к ограниченному generic visible UI без selectors/JS от ChatGPT. |
| v0.6.8–v0.6.9 | Portal/native option investigation, candidate evidence | Уточнить выбор visible option и честно возвращать evidence при блоке. |
| v0.7.0–v0.7.6 | Adaptive/temporal/query-correlated menu, visible click evidence, persisted click handoff | Не выбирать stale/static элементы и не повторять click при unload. |
| v0.7.7–v0.8.0 | Bound target guard и единый run-owned lifecycle | Не сбрасывать результатную страницу URL из формы. |
| v0.8.1 | `FILTERS_VISIBLE` | Показывать реальные visible filter controls, а не counters. |
| v0.8.2 | Card-bound listing collection | Не смешивать ссылку, цену и продавца разных элементов. |
| v0.8.3 | Public listing passport | Читать публичные факты открытого объявления без seller interaction. |
| v0.8.4 | Debugger click navigation + listing-surface fence | Подтвердить navigation и не выдавать results page за listing. |
| v0.8.5 | Proactive anchor-navigation handoff | Не продолжать старый план на выдаче после click по объявлению. |

---

# Приложение B. Правило обновления этого файла

Каждая следующая запись добавляется в конец и обязана содержать:

```text
Версия и дата:
Причина:
Что изменено:
Какие popup/ChatGPT/Avito функции затронуты:
Какие функции намеренно не менялись:
Риски регрессии:
Матрица сохранения функций:
Автотесты:
Live-приёмка:
Ограничения:
Решение о готовности:
```

Ни одна правка не может считаться готовой, пока не доказано, что она не ломает все контракты из разделов 11 и 12.
