# Avito Finder — каноническая документация расширения

> **APPEND-ONLY.** Этот файл является единственным каноническим описанием Avito Finder. Ранее добавленный текст не переписывается и не удаляется. Каждое изменение добавляется только в конец нового раздела с версией, датой, причиной, фактическими изменениями, проверками, известными ограничениями и условиями приёмки.

## 1. Назначение

Avito Finder — отдельное Chrome-расширение для поиска товаров на Avito через уже открытую пользовательскую сессию Chrome. Пользователь формулирует потребность в выделенном чате ChatGPT. ChatGPT уточняет недостающие условия, формирует обычную структурированную команду, расширение активирует вкладку ChatGPT, получает команду, активирует вкладку Avito, выполняет только разрешённые действия через видимый интерфейс сайта, собирает ограниченный набор карточек и возвращает наблюдаемые результаты в тот же чат. ChatGPT затем ранжирует 5–10 подходящих вариантов по соответствию запросу, цене и рискам.

Расширение не принимает решение о покупке, не пишет продавцам, не оформляет сделки и не выполняет скрытый сетевой сбор данных.

## 2. Изоляция

Avito Finder не связан с Business Bridge / Inspector:

- отдельный manifest, Service Worker, popup, content scripts, архивы и документация;
- отдельный префикс хранилища `avito_finder.*`;
- отдельные технические идентификаторы `af-*`;
- запрещены общие storage keys, общая очередь, общий runtime-код и общие журналы;
- работа или поломка одного расширения не должна менять другое.

## 3. Границы разрешённого поведения

Разрешено только:

- работать в текущем Chrome-профиле пользователя;
- активировать конкретную вкладку ChatGPT перед чтением команды и перед возвратом отчёта;
- активировать конкретную вкладку Avito перед работой на Avito;
- через обычные видимые элементы Avito читать доступные фильтры, заполнять согласованные параметры и собирать ограниченные видимые результаты;
- создавать одну вкладку Avito только после явного пользовательского запуска, если подходящей вкладки нет;
- собирать видимые ссылку, заголовок, цену, локацию, характеристики, состояние и доступные публичные метки;
- ставить задачу на паузу, если поле ChatGPT занято пользовательским текстом.

Запрещено:

- отправлять сообщения продавцам;
- покупать, бронировать, сохранять объявления, менять настройки профиля, оплачивать или подавать жалобы;
- читать, экспортировать или передавать cookies, пароли, токены, `.env` и иные секреты;
- использовать скрытые API Avito, обход captcha/anti-bot/rate-limit, прокси или массовый фоновой сбор;
- нажимать отправку в ChatGPT, если composer занят пользовательским текстом;
- считать клик Send, очистку composer или внутренний флаг доказательством доставки. Успех доставки подтверждается только появлением нового исходящего user-turn с ожидаемым текстом.

## 4. Обязательное переключение вкладок

Каждый фактический переход должен быть видимым:

```text
ChatGPT-команда
→ активировать вкладку Avito
→ выполнить работу на Avito
→ активировать вкладку ChatGPT
→ вернуть отчёт
```

Скрытая фоновая работа на Avito запрещена. Если Chrome не позволяет активировать нужную вкладку, задача завершается понятным статусом `BLOCKED_TAB_ACTIVATION` без обходного пути.

## 5. Текущий этап

Текущая реализация — этап 1: read-only обследование DOM ChatGPT и Avito. Поиск, ввод фильтров, запуск поиска, сбор объявлений и доставка результатов в ChatGPT ещё не реализованы и не должны быть представлены как готовые.

---

# История изменений

## 2026-06-24 — v0.1.0: read-only DOM inspector

### Что добавлено

- отдельное расширение Manifest V3 `Avito Finder`;
- отдельные `service_worker.js`, `popup.*`, `core.js`, `chatgpt_content.js`, `avito_content.js`;
- отдельные ключи `avito_finder.*`;
- popup с кнопками «Начать обследование» и «Стоп», статусом и журналом;
- поиск и активация вкладок ChatGPT и Avito;
- read-only DOM-снимки без ввода, поиска, фильтров, отправки сообщений продавцам или доступа к cookies;
- создание одной вкладки Avito только после явного нажатия пользователя, если Avito-вкладка отсутствует.

### Проверки

- локальные тесты и повторный прогон против распакованного exact ZIP;
- `node --check` runtime JavaScript;
- проверка manifest, ZIP и хэшей;
- статические ограничения: нет cookies, внешних API, Business Bridge references, произвольного исполнения кода, поиска или сообщений продавцам.

### Известная ошибка реализации

На уже открытых вкладках после установки/обновления content script мог отсутствовать. Service Worker находил и активировал правильную вкладку, но `chrome.tabs.sendMessage(...)` завершался ошибкой:

```text
Could not establish connection. Receiving end does not exist.
```

### Почему прежняя проверка не предотвратила дефект

Эмуляционные тесты проверяли саму логику сообщений, но не сценарий установки расширения при уже открытых вкладках, где content script не был автоматически внедрён.

### Статус живой проверки

Не пройдена: пользовательский журнал показал реальный дефект получения сообщения.

---

## 2026-06-24 — v0.1.1: recovery отсутствующего content-script получателя

### Причина изменения

Пользовательская живая проверка `v0.1.0` показала последовательность:

```text
TAB_ACTIVATED role="chatgpt"
READONLY_INSPECTION_BLOCKED reason="Could not establish connection. Receiving end does not exist."
```

Это доказало, что вкладка выбиралась правильно, но content script в ней отсутствовал.

### Что изменено

- Worker при точной ошибке отсутствующего получателя сначала сверяет разрешённый URL и роль вкладки;
- затем внедряет только заранее упакованные файлы соответствующей роли:
  - ChatGPT: `core.js` и `chatgpt_content.js`;
  - Avito: `core.js` и `avito_content.js`;
- после этого делает только один повторный read-only запрос;
- добавлена защита от параллельных запусков обследования;
- после обхода фокус возвращается на вкладку ChatGPT.

### Что намеренно не менялось

- нет поиска, ввода текста, установки фильтров, кликов по карточкам или отправки отчёта;
- нет Business Bridge-кода или общих хранилищ;
- нет произвольного `executeScript` и нет выполнения пользовательского JavaScript;
- нет доступа к cookies, токенам, секретам или сетевым API Avito.

### Проверки

- 30/30 локальных тестов на исходниках;
- 30/30 тех же тестов против файлов, извлечённых из exact ZIP;
- `node --check` runtime JavaScript;
- `unzip -t`;
- проверка manifest, хэшей и совпадения исходников с exact ZIP;
- статические проверки отсутствия cookies, внешних API, Business Bridge references, произвольного кода, поиска и контактов с продавцами.

### Живое доказательство

**Не получено.** `v0.1.1` является кандидатом, проверенным эмуляционно и по exact ZIP. Следующая обязательная приёмка — установка пользователем, один клик «Начать обследование» и проверка журнала фактической последовательности:

```text
TAB_ACTIVATED role="chatgpt"
CONTENT_RECEIVER_MISSING role="chatgpt"        # только если скрипта не было
CONTENT_SCRIPT_INJECTED role="chatgpt"          # только если скрипта не было
CHATGPT_DOM_CAPTURED
TAB_ACTIVATED role="avito"
CONTENT_RECEIVER_MISSING role="avito"           # только если скрипта не было
CONTENT_SCRIPT_INJECTED role="avito"            # только если скрипта не было
AVITO_DOM_CAPTURED
TAB_ACTIVATED role="chatgpt_return"
READONLY_INSPECTION_COMPLETE
```

### Условия приёмки v0.1.1

1. На уже открытых вкладках ChatGPT и Avito расширение успешно собирает оба read-only DOM-снимка.
2. Вкладки фактически активируются по порядку ChatGPT → Avito → ChatGPT.
3. В журнале нет `Could not establish connection. Receiving end does not exist.` после допустимой recovery-попытки.
4. Расширение не вводит текст, не меняет фильтры и не ищет объявления.
5. Пользователь не наблюдает побочных действий в аккаунте Avito или ChatGPT.

### Последнее изменение

`v0.1.1`: добавлена контролируемая recovery-инъекция упакованных content scripts для ранее открытых вкладок. Живая приёмка ещё обязательна.

---

## 2026-06-24 — v0.1.1: живая приёмка read-only обследования пройдена

### Фактическое живое доказательство

Пользователь выполнил один запуск на реальных вкладках одного окна Chrome. Popup вернул:

```text
Задача: af-20260624064334-4xw6
Вкладка ChatGPT: https://chatgpt.com/c/6a3b74d9-aff4-83eb-9eda-1ff668a9c96d
Вкладка Avito: https://www.avito.ru/
Статус Avito: DOM доступен для обследования
ChatGPT DOM: assistant/user контейнеры 12; composer-кандидаты 6; Send-кнопки 0
Avito DOM: формы/поля 1; кнопки 48; ссылки-кандидаты 0; признаки логина/captcha не обнаружены
```

Это подтверждает: вкладки ChatGPT и Avito доступны; read-only content scripts отвечают; Avito не показал login/captcha; этап 1 не выполнял поиск, ввод текста, изменение фильтров или отправку сообщения.

### Ограничение доказательства

Этот отчёт не доказывает сбор команд, установку фильтров, запуск поиска, сбор карточек или доставку результата в ChatGPT. Эти действия в v0.1.1 отсутствуют.

---

## 2026-06-24 — v0.2.0: read-only захват команды и обследование поверхности фильтров

### Причина изменения

Живая приёмка v0.1.1 подтвердила доступность обеих вкладок и DOM. Следующий безопасный шаг — захватить последнюю новую обычную assistant-форму команды из выделенного чата и прочитать доступные элементы фильтров Avito. Нельзя переходить к вводу, кликам фильтров или поиску без этого переходного шага.

### Что добавлено

- кнопка popup «Прочитать команду и фильтры»;
- чтение только последней допустимой assistant-команды после последнего user-сообщения;
- обычная форма без JSON и скрытых BBI-маркеров с обязательными разделами из ТЗ;
- защита от повтора уже обработанного `turnId`;
- активируемая последовательность `ChatGPT → Avito → ChatGPT`;
- read-only снимок поверхности фильтров Avito: видимые поля, кнопки, combobox и признаки filter/search form;
- отдельный локальный ключ `avito_finder.last_command`;
- понятный отчёт, который явно фиксирует отсутствие ввода, изменения фильтров, поиска, открытия карточек и отправки сообщений.

### Что намеренно не добавлялось

- ввод текста на Avito;
- выбор категории, города, цены или фильтров;
- кнопка поиска;
- сбор объявлений;
- сообщение продавцам;
- автоматическая отправка результата в ChatGPT;
- доступ к cookies, сетевым API, скрытым API или данным Business Bridge.

### Тесты и доказательства сборки

- Node.js `node --test`: проверяются форма команды, обязательный город для SEARCH, запрет BBI/JSON-маркеров, выбор только новой assistant-команды после user-turn, защита baseline turn, read-only отчёт и изоляция storage;
- статические контракты проверяют минимальные разрешения, целевые host permissions, отсутствие сетевых API/cookies/продавцов, отсутствие dynamic code и отсутствие write/search handlers;
- `node --check` всех JS-файлов;
- exact ZIP проверяется через `unzip -t`, повторный `node --test` против распакованного архива и сравнение хэшей файлов.

### Статус живой проверки

Не пройдена. `v0.2.0` — кандидат для следующего живого шага: после того как ChatGPT сформирует обычную команду `Режим: INSPECT_FILTERS`, пользователь нажимает в popup «Прочитать команду и фильтры» и передаёт сюда отчёт и последние события.

### Условия приёмки v0.2.0

1. Расширение захватывает только новую assistant-форму после последнего user-сообщения и не выбирает старую историю.
2. При повторном запуске без новой команды возвращается `NO_NEW_VALID_COMMAND` и Avito не активируется для сканирования.
3. При допустимой команде вкладки реально активируются в порядке ChatGPT → Avito → ChatGPT.
4. Отчёт показывает поля команды и поверхность фильтров.
5. Не происходит ввод, изменение фильтров, поиск, открытие карточек или отправка сообщения.
6. Вкладки ChatGPT и Avito остаются изолированными от Business Bridge.

### Последнее изменение

`v0.2.0`: добавлен read-only переход «последняя assistant-команда → поверхность фильтров Avito», без каких-либо изменений страницы или передачи результата в чат.

### Дополнительная проверка exact package в Chromium

Точный распакованный пакет был передан Chromium через `--disable-extensions-except` и `--load-extension` в отдельном временном профиле. Chromium запустился без manifest/parser error в журнале. В headless DevTools не появился наблюдаемый extension worker target, поэтому эта проверка подтверждает только отсутствие немедленной ошибки запуска Chromium с путём пакета, но **не** подтверждает работу расширения в реальной вкладке. Живая приёмка v0.2.0 по-прежнему обязательна.


---

## 2026-06-24 — v0.2.1: восстановление захвата команды через writing block и локальный Copy

### Фактическая причина поломки v0.2.0

Живой запуск `v0.2.0` остановился в `WAITING_FOR_COMMAND` и оставил в popup прежний отчёт этапа 1. Вкладка Avito не активировалась для обследования, поскольку командный переход не начался.

Первое неверное условие было в `core.js`:

```text
v0.2.0 требовала 12 специальных полей:
Цель, Режим, Категория, Город, Доставка, Поисковый запрос, Цена,
Обязательные условия, Желательные условия, Исключить,
Количество кандидатов, Действие.
```

Но фактический рабочий путь Business Bridge использует обычный assistant writing block с четырьмя человеческими разделами:

```text
Цель:
Рабочая область:
Изменения:
Проверка:
```

Поэтому форма, отображённая в ChatGPT, считалась недопустимой и была отброшена как `NO_NEW_VALID_COMMAND`. Предыдущие unit-тесты проверяли выдуманную 12-польную схему вместо реального формата Bridge и не имитировали writing block с локальной кнопкой Copy.

### Что изменено

- удалена 12-польная схема из read-only команды Avito Finder;
- теперь принимается только обычная четырёхраздельная форма `Цель / Рабочая область / Изменения / Проверка`;
- захват строится по той же наблюдаемой структуре, что и рабочий Bridge:
  - новый assistant turn после последнего user turn;
  - реальный writing block;
  - локальная кнопка `Копировать`, принадлежащая тому же writing block;
  - локальный click Copy;
  - извлечение текста только из этого writing block;
  - повторная проверка четырёх разделов после click;
- обычный assistant-текст без writing block теперь получает ясный отказ `LATEST_COMMAND_IS_NOT_WRITING_BLOCK`;
- ошибка формата возвращается как `WRITING_BLOCK_COMMAND_INVALID:<причина>`;
- лог успеха изменён на `WRITING_BLOCK_COMMAND_CAPTURED` и содержит `copy_confirmed` и `copy_source`;
- read-only режим остаётся единственным: команда должна одновременно просить обследование фильтров и явно запрещать ввод, изменение фильтров, поиск, открытие карточек и отправку сообщений.

### Что намеренно не изменялось

- поиск, ввод, установка фильтров, открытие карточек, сбор объявлений и доставка результата в чат не добавлялись;
- нет cookies, сетевых API Avito, контакта с продавцами, покупок или обхода ограничений;
- изоляция от Business Bridge сохраняется: код не импортируется и не разделяет storage, runtime, очередь или журнал; перенят только локальный наблюдаемый принцип выбора writing block и click Copy.

### Проверки

- `node --test` для четырёхраздельной формы, отсутствующих разделов, явного read-only запрета, старого 12-польного формата, последнего assistant turn после user turn и baseline turn;
- отдельные статические контракты для `section[data-turn]`, локальной кнопки Copy, отказа обычному assistant-тексту и отсутствия write/search handlers;
- Chromium DOM-fixture с ChatGPT-подобным `section[data-turn]`, assistant writing block, кнопками «Редактировать»/«Копировать» и проверкой фактического click Copy;
- `node --check` всех runtime JS-файлов;
- exact ZIP: `unzip -t`, повторный `node --test` и совпадение хэшей исходников и распакованного пакета.

### Статус живой проверки

Не пройдена. Требуется один живой запуск только с новой четырёхраздельной writing-block формой. Успехом будет считаться исключительно последовательность:

```text
WRITING_BLOCK_COMMAND_CAPTURED copy_confirmed=true
TAB_ACTIVATED role="avito_filter_scan"
AVITO_FILTER_SURFACE_CAPTURED
TAB_ACTIVATED role="chatgpt_return"
COMMAND_FILTER_INSPECTION_COMPLETE
```

### Условия приёмки v0.2.1

1. Popup перестаёт возвращать `NO_NEW_VALID_COMMAND` для новой четырёхраздельной writing-block формы.
2. Локальная кнопка Copy конкретного writing block нажимается ровно один раз.
3. Avito активируется только после успешного захвата формы.
4. После фильтр-снимка фокус возвращается в ChatGPT.
5. Не выполняются ввод, поиск, изменение фильтров, открытие карточек или отправка сообщений.
6. Статус и журнал показывают понятную точную причину при отсутствии writing block либо неверной форме.

### Последнее изменение

`v0.2.1`: v0.2.0 перестала ждать несуществующую 12-польную команду и использует только четырёхраздельный writing block с локальным Copy.


---

## 2026-06-24 — v0.2.1: проверка exact package

### Результат

- `node --test` на исходниках: **22/22 PASS**;
- `node --test` на файлах, извлечённых из exact ZIP: **22/22 PASS**;
- `node --check` пяти runtime JS-файлов exact ZIP: **5/5 PASS**;
- `unzip -t`: **PASS**;
- source и exact ZIP: **16/16 файлов совпадают по SHA-256**.

В набор входит отдельный DOM runtime harness, который исполняет реальный `chatgpt_content.js` против ChatGPT-подобной структуры с `section[data-turn]`, assistant writing block и локальными кнопками `Редактировать`/`Копировать`. Он подтвердил выбор формы, Copy только своего блока, защиту baseline и отказ после позднего user-turn.

### Ограничение

Headless Chromium в контейнере не выполнил fixture из-за внутренних crashpad/GPU ошибок процесса окружения. Это не считается ни успехом, ни дефектом пользовательского Chrome. Поэтому `v0.2.1` остаётся кандидатом до одного живого запуска в пользовательском браузере.

### Последнее изменение

Добавлены exact-package тесты и DOM runtime harness для реального `chatgpt_content.js`; живая приёмка всё ещё обязательна.

---

## 2026-06-24 — v0.2.2: контур turn-anchor Business Bridge, ожидание формы и честный отчёт отсутствия команды

### Фактический живой симптом v0.2.1

Пользователь установил `v0.2.1`, получил в popup:

```text
WAITING_FOR_COMMAND
NO_NEW_VALID_WRITING_BLOCK_COMMAND
```

При этом popup продолжал показывать прежний отчёт read-only обследования `af-20260624071156-nz0n`. Avito не переключался на обследование фильтров.

### Что было сделано неверно

`v0.2.1` заявляла использование механизма Bridge, но фактически делала одноразовый захват команды и возвращала общий отказ без доказательств структуры текущего ChatGPT DOM. Она также сохраняла `processed_command_turn_id` между версиями одного и того же storage-контракта и не очищала прежний отчёт перед новым запуском.

Это не позволяло отличить три разные причины: форма уже стала историей после нового user-turn, нет точного `section[data-turn][data-turn-id]`, либо у нового assistant turn отсутствует writing block / локальная Copy.

### Фактическая причина на уровне реализации

В рабочем Bridge кандидат строится не из общего списка assistant-элементов, а по точной последовательности:

```text
section[data-turn][data-turn-id]
→ последний user turn
→ assistant turn после него
→ writing block
→ local Copy
```

В `v0.2.1` этот контур не был сохранён как единственный источник состояния ожидания. Одноразовый вызов возвращал `NO_NEW_VALID_WRITING_BLOCK_COMMAND`, а popup продолжал выводить старый успешный отчёт, что создавало ложную картину нового запуска.

### Что изменено в v0.2.2

- захват команды использует точный turn-contour `section[data-turn][data-turn-id]`, как у работающего Bridge;
- использован тот же структурный адаптер writing block: legacy explicit root или current local Edit+Copy toolbar; `[aria-live]` остаётся в тексте блока;
- кнопка popup теперь запускает ожидание команды до 90 секунд, а не единственный мгновенный scan;
- команда допускается только после последнего user turn и только один раз для своего `turnId`;
- при смене контракта захвата с `v0.2.1` на `v0.2.2` старый `processed_command_turn_id` не используется;
- при старте очищается прошлый отчёт обследования;
- при timeout/cancel/no candidate новый popup-отчёт содержит только структурные признаки: количество exact turn sections, наличие последнего user turn, assistant после него, writing block, local Copy и ошибки формы. Текст пользователя не выводится;
- `Стоп` отменяет ожидание в content script;
- Avito по-прежнему не активируется до успешного захвата формы.

### Что не добавлено

Не добавлены поиск, ввод, изменение фильтров, карточки, контакты с продавцами, автоматическая отправка в ChatGPT, cookies, сетевые API, скрытые запросы или общие части с Business Bridge.

### Почему прежние проверки не предотвратили дефект

`v0.2.1` тестировала happy path с одной готовой формой в fixture. Тестов не было для:

1. одноразового scan против ожидания формы;
2. устаревшего `processed_command_turn_id` после изменения формата/контракта;
3. очистки прошлого успешного отчёта до нового запуска;
4. пользовательского диагностического отчёта, который различает отсутствие assistant после последнего user и отсутствие writing block.

### Проверки v0.2.2

- Node unit и DOM harness: exact `section[data-turn][data-turn-id]`, четыре раздела, legacy/current toolbar, один local Copy, baseline rejection, поздний user-turn, структурный audit;
- static contract: только read-only handlers, отсутствие поиска/ввода/продавцов/cookies/network, exact Bridge turn contour, разрешённая инъекция только упакованных файлов;
- `node --check` runtime JavaScript;
- `unzip -t`, повторный `node --test` на exact ZIP и SHA-256 сравнение исходников с распакованным ZIP.

### Условия приёмки v0.2.2

1. После нажатия popup показывает новый статус ожидания и не показывает старый отчёт как результат нового запуска.
2. Если новая форма уже видна либо появляется в течение 90 секунд, extension фиксирует `WRITING_BLOCK_COMMAND_CAPTURED` с `copy_confirmed=true`.
3. Только после этого вкладка Avito становится активной, затем после read-only снимка обратно активируется ChatGPT.
4. Если захват не удался, новый отчёт называет точную структурную причину без текста user-сообщений.
5. Не выполняются ввод, фильтры, поиск, карточки, продавцы или отправка сообщений.
6. Живая приёмка ещё не пройдена. `v0.2.2` — кандидат, не финальная сборка.

### Последнее изменение

`v0.2.2`: заменён одноразовый захват на stateful ожидание новой Bridge-совместимой writing-block формы, добавлены контрактная миграция состояния и честный диагностический отчёт.

---

## 2026-06-24 — v0.2.3: anchor-first захват copy-only writing block и живой журнал

### Фактическая причина поломки v0.2.2

Живой скриншот `v0.2.2` показал writing-block форму с локальной иконкой Copy и Expand, но без видимой кнопки Edit. При этом `currentWritingBlockBinding(...)` в `chatgpt_content.js` принимала current toolbar только при одновременном наличии **Edit + Copy** в одном ancestor. Поэтому доступная форма не становилась writing block для захвата.

Вторая поломка наблюдаемости: `popup.js` ожидал завершения долгого `AF_START_COMMAND_FILTER_INSPECTION` вызова и не подписывался на `chrome.storage.onChanged`. Логи лежали ниже «Последний отчёт» и во время ожидания не обновлялись в popup. Пользователь не мог увидеть, на каком структурном условии остановилась цепочка.

Третья архитектурная ошибка: команда выбиралась как assistant после **текущего последнего** user-turn. Любое новое пользовательское сообщение во время ожидания делало прежнюю форму невыбираемой без явной диагностики anchor/ручного прерывания.

### Что изменено

- Перед ожиданием Worker запрашивает и сохраняет точный последний user-turn как `command_anchor_turn_id`.
- Content script ищет только assistant-поворот после этого anchor, а не после меняющегося «последнего user».
- При появлении следующего user-turn до завершения командного захвата результат становится явным `MANUAL_USER_TURN_AFTER_ANCHOR`, а не бесконечным молчаливым ожиданием.
- Сохранён Bridge-путь `Edit + Copy`; добавлен ограниченный путь `Copy-only` только для текущего локального блока, если его собственный очищенный текст уже проходит полную проверку четырёх разделов read-only формы.
- Generic turn-wide `copy-turn-action-button` и «Copy response / Копировать ответ» по-прежнему исключены.
- Локальная Copy нажимается не более одного раза для конкретной кнопки.
- В popup блок «Живой журнал» перенесён выше отчёта.
- Popup подписан на `chrome.storage.onChanged`, поэтому статус, audit и журнал обновляются во время ожидания без ручного refresh.
- Content script отправляет в Worker обезличенный структурный audit только при изменении состояния: anchor, assistant id, наличие writing block, источник, local Copy, валидность формы и код ошибки. Текст user-сообщений не передаётся в лог.

### Что не менялось

- Поиск, ввод, изменение фильтров, открытие карточек, работа с продавцами и отправка сообщений отсутствуют.
- Не добавлены cookies, внешние API, скрытые запросы Avito, прокси, обход captcha или код Business Bridge.
- Вкладка Avito не активируется до успешного захвата команды.

### Проверки перед упаковкой

- unit-тесты формы и state;
- DOM harness для `Edit + Copy`, `Copy-only`, generic Copy rejection, anchor и manual interruption;
- static contract: изоляция, минимальные permissions, отсутствие write/search/network/seller handlers, отсутствие dynamic JavaScript execution;
- `node --check` всех JS runtime-файлов;
- `unzip -t`, tests и хэши exact ZIP.

### Статус живой проверки

**Не пройдена.** Это кандидат для одной узкой живой приёмки read-only команды. Он не является готовым поисковым расширением и не должен быть объявлен работающим до фактического результата: захват новой формы → видимая активация Avito → read-only фильтры → возврат в ChatGPT.

### Условия приёмки v0.2.3

1. После нажатия popup сразу показывает `COMMAND_WATCH_STARTED` и текущий audit в видимом «Живом журнале».
2. Новая форма с локальной Copy без Edit захватывается строго после заякоренного user-turn.
3. Нажимается только локальная Copy конкретного writing block; generic assistant-turn Copy не нажимается.
4. При ручном user-turn после anchor popup показывает `MANUAL_USER_TURN_AFTER_ANCHOR` и Avito не активируется.
5. При успехе наблюдается порядок вкладок ChatGPT → Avito → ChatGPT.
6. Поиск, ввод и изменения на Avito отсутствуют.

### Последнее изменение

`v0.2.3`: устранён ложный обязательный Edit-gate для copy-only writing block, введён точный anchor user-turn и сделан видимым живой структурный журнал.

### Упаковка и доказательства v0.2.3

Точный runtime ZIP содержит только девять runtime-файлов: `manifest.json`, `core.js`, `service_worker.js`, `chatgpt_content.js`, `avito_content.js`, `popup.html`, `popup.js`, `popup.css`, `README.md`.

Перед выдачей выполнены:

- `node --check` для пяти runtime JS-файлов;
- 32/32 Node.js тестов на исходниках;
- 32/32 тех же Node.js тестов на runtime, извлечённом из exact ZIP;
- `unzip -t` exact ZIP;
- SHA-256 сравнение девяти исходных runtime-файлов с извлечёнными из exact ZIP: расхождений нет.

Отдельно была начата контролируемая Chromium/Playwright fixture-проверка с локальными HTTPS страницами, отображёнными на разрешённые hostnames ChatGPT и Avito. В данном sandbox Chromium с загруженным extension не открыл доступный DevTools endpoint, поэтому полный browser E2E не получен. Это не трактуется как доказательство или как поломка пользователя: живая проверка в пользовательском Chrome остаётся обязательной.

---

## v0.2.4 — 2026-06-24 — прямой перенос порядка захвата формы из Business Bridge

### Что изменено

В Avito Finder удалён самостоятельный путь `current_local_copy_only_form`, выбор первого assistant-turn и проверка смысла read-only команды во время поиска блока. Вместо этого в отдельный код Avito Finder перенесён порядок рабочего Business Bridge:

1. `turnSections()` берёт точные `section[data-turn][data-turn-id]` без фильтра видимости.
2. `assistantCandidateAfterAnchor()` собирает **все** assistant-turn после точного anchor user-turn и до первого следующего user-turn.
3. Выбирается строго последний assistant-turn: `assistants[assistants.length - 1]`.
4. В выбранном turn ищется только Bridge-совместимый writing block: legacy explicit root либо current local toolbar с Edit + local Copy.
5. Проверяется readiness Copy и структурная подпись блока.
6. Состояние ждёт две секунды неизменности DOM-структуры.
7. Только после этого выполняется локальное подтверждение Copy и извлекается текст.
8. Проверка, подходит ли текст для текущего read-only этапа, перенесена после структурного захвата — в `validateReadOnlyFilterInspectionCommand()` Service Worker.

### Почему это устраняет наблюдавшуюся поломку

В живом журнале v0.2.3 был выбран ранний assistant `request-...-4` с `legacy_explicit_root`; он не содержал четырёх разделов. Поэтому v0.2.3 возвращал `MISSING_LABELS`. Новый порядок не фиксируется на первом assistant-turn: при последовательности `anchor → a-old → a-latest` выбирается `a-latest`.

### Источник переноса

Рабочий порядок перенесён из предоставленного архива Business Bridge, файл `content_script.js`, функции: `turnSections`, `legacyWritingBlockElement`, `currentWritingBlockBinding`, `resolveWritingBlockBinding`, `sectionWritingBlockText`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `assistantCandidateAfterAnchor` и стабильность `PROMPT_STABILITY_MS = 2000`.

### Проверка

- unit-проверка: ранний invalid legacy block + поздний valid block → выбран только поздний;
- unit-проверка: последний assistant и счётчик assistant-turn;
- unit-проверка: current local toolbar нажимает локальную Copy ровно один раз;
- unit-проверка: следующий user-turn останавливает захват до Copy;
- unit-проверка: обязательное окно стабильности DOM 2 секунды;
- Chromium fixture: подготовлена для реального DOM с `a-old` и `a-latest`; запуск в sandbox завис на старте Chromium и не засчитан как проверка;
- exact ZIP: тесты и хэши повторяются после распаковки.

### Статус живой проверки

Не пройдена на реальной вкладке пользователя на момент выпуска. Node DOM harness прошёл, но Chromium fixture в sandbox не завершилась; версия является кандидатом только для одной live-проверки захвата формы. На этом этапе по-прежнему запрещены ввод текста в Avito, изменение фильтров, поиск, открытие объявлений и отправка сообщений.

---

## v0.2.5 — 2026-06-24 — full Bridge start-exact anchor transport

### What changed

`v0.2.5` replaces the failed passive “use the current last user turn as anchor” path with the complete working order used by Business Bridge, while keeping Avito Finder isolated:

1. The user presses **«Запустить цикл и фильтры»**.
2. The extension activates the ChatGPT tab.
3. Through the confirmed persistent lower ChatGPT composer only, it stages and sends one ordinary human start message: `Avito Finder запущен…`.
4. It records the set of user turns before the click, waits for a **new user turn whose text matches that exact start message**, and uses only this turn as `start_exact` anchor.
5. It waits only for assistant turns after that anchor and before another user turn.
6. It selects the latest assistant turn, uses the copied Bridge local writing-block binding/Copy/stability order, then reads the selected block.
7. Only after structural capture and local Copy does it parse the four human sections.
8. It activates Avito, performs only filter-surface inspection, then activates ChatGPT again.

### Cause addressed

Previous versions `v0.2.0`–`v0.2.4` used an already present last user turn as anchor. That allowed an unrelated assistant response or legacy block after that old turn to be treated as the candidate. The live logs showed `legacy_explicit_root` with `MISSING_LABELS`; this was a consequence of using the wrong anchor, not evidence that the expected form was absent.

### Boundaries retained

- Separate extension project, manifest, storage (`avito_finder.*`), worker, popup, logs, docs and release files; no Business Bridge storage, runtime, queue, task IDs or reports are used.
- The only newly automated mutation is the explicitly user-started ordinary ChatGPT start message. The extension refuses to overwrite any different existing composer draft.
- No Avito text entry, filter changes, search, listing opening, seller contact, account changes, cookies, network APIs, captcha handling, proxies or bypasses.
- No retry click after a send whose composer-clear outcome is not confirmed.

### Validation and evidence

- `node --test tests/*.test.js`: 15/15 passed on source.
- Added emulated end-to-end transport test: ordinary start message → exact new user anchor → later response writing block → two-second stability → command capture.
- Added draft-protection test: a non-empty unrelated composer draft produces `START_PRIMARY_COMPOSER_OCCUPIED` and no send click.
- Static checks cover source isolation, no network/seller paths, exact `start_exact` order, form parsing after Copy, and absence of Bridge protocol markers in the outgoing start message.
- Exact ZIP validation is recorded in the release validation report.

### Live verification status

Not yet verified in the user’s real ChatGPT and Avito tabs. This is a candidate for one controlled live command-cycle test. It must not be described as live-proven until the popup reports a captured command and the actual sequence `ChatGPT → Avito → ChatGPT` is visible.

---

## Append — v0.3.0 — reset to the approved ТЗ command contract

**Date:** 2026-06-24  
**Status:** candidate; not a final release.  
**Append-only rule:** this entry is added after all prior text. Previous entries are not rewritten.

### What changed

v0.3.0 removes the non-ТЗ `START_EXACT_ANCHOR` path that tried to insert a start message into ChatGPT. The extension now follows section 5.1 of the approved ТЗ directly:

1. it reads the current ChatGPT conversation only;
2. it finds the last ordinary user turn;
3. it examines assistant writing blocks after that turn;
4. it ignores invalid/old/partial writing blocks instead of terminating on the first one;
5. it selects the latest complete valid Avito Finder command whose `turnId` has not already been processed;
6. it confirms the selected local Copy control once when present, without using the system clipboard;
7. only `INSPECT_FILTERS` continues to a read-only Avito surface inspection.

The command contract is now exactly the approved 12-label form:

`Цель`, `Режим`, `Категория`, `Город`, `Доставка`, `Поисковый запрос`, `Цена`, `Обязательные условия`, `Желательные условия`, `Исключить`, `Количество кандидатов`, `Действие`.

No automatic ChatGPT start message is created. No user composer text is written. No Bridge runtime code, storage keys, worker, queue, logs, or task protocol is used.

### Implementation failure being corrected

Earlier candidates `v0.2.1`–`v0.2.5` deviated from the approved ТЗ by imposing a four-label form, treating the first invalid writing block as terminal, and then adding a non-ТЗ automatic start-message/anchor cycle. In the observed live log this produced `MISSING_LABELS` for an unrelated assistant block and later an indefinite `SENDING_START_COMMAND` state.

### Root cause

The implementation treated an internal capture idea as the product contract. The actual product contract requires the latest valid assistant form after the latest user turn; it does not require the extension to generate a new user turn. It also defines twelve command labels, not four.

### Why earlier checks missed it

The prior test fixtures were aligned to invented intermediate contracts rather than the approved command template and the observed failure sequence "invalid writing block → later valid form". They therefore could pass while violating the ТЗ.

### Corrective tests in v0.3.0

- Node tests verify the complete twelve-label command, reject the obsolete four-label form, reject BBI/result/JSON markers, reject unsupported mode and a candidate limit above 30, verify minimal permissions, and verify that the automatic-start path is absent.
- A real Chromium DOM regression uses the exact packaged content-script files in a Chromium DOM fixture. It starts with an older command, then the current user turn, then an invalid assistant writing block, and finally appends a valid form. The script proves that only the valid latest form is captured, only its local Copy is clicked, and the Avito read-only inspection does not modify inputs or click buttons.

### Known limits and live-verification status

- **Implemented:** command capture and `INSPECT_FILTERS` read-only surface capture.
- **Not implemented:** `SEARCH` filter application/card collection (ТЗ stage 5); report insertion/send confirmation (ТЗ stage 6); end-to-end live validation in the user’s actual Chrome/ChatGPT/Avito DOM.
- The Chromium regression is not a substitute for the mandatory live Chrome acceptance required by the ТЗ. The build is therefore a **candidate**, not a release-ready extension.

---

## Append — v0.3.0 validation finalization — 2026-06-24

**Status:** candidate only; live Chrome acceptance is still not complete.  
**Append-only rule:** this entry adds evidence only; earlier text remains unchanged.

### Final packaged build and checks

The production archive contains only these runtime files: `manifest.json`, `core.js`, `chatgpt_content.js`, `avito_content.js`, `service_worker.js`, `popup.html`, `popup.css`, `popup.js`, and `README.md`.

The command parser additionally rejects non-numeric candidate limits such as `1 объявление`; the allowed range remains exactly `1..30` under the ТЗ.

The following checks were repeated against the **exact extracted ZIP**:

- `unzip -t`: passed;
- `node --check` for every runtime JavaScript file: passed;
- `node --test`: 5/5 passed;
- real Chromium DOM regression using the exact packaged content-script files: passed;
- SHA-256 comparison of all nine runtime files between source and extracted ZIP: all equal;
- forbidden runtime capability scan: no cookies, `webRequest`, proxy, fetch/XHR, seller-contact, start-message, or Business Bridge runtime identifiers.

### What this evidence does and does not prove

It proves the packed read-only stage can parse the approved twelve-label `INSPECT_FILTERS` form in a controlled Chromium DOM, ignore earlier invalid blocks, select the later valid block, click only that block's local Copy once, and inspect an Avito-like DOM without typing or clicking its controls.

It does **not** prove live behavior on the user's actual ChatGPT or Avito DOM. The sandbox blocks real-site and localhost browser navigation, so the required live user-Chrome acceptance remains outstanding. `SEARCH`, listing collection, and report delivery to the ChatGPT composer remain unimplemented stages and are not represented as working.

---

## Append — v0.4.0 — Bridge exact start / anchor / local Copy isolation

**Date:** 2026-06-24  
**Status:** test candidate only; not live accepted or release-ready.  
**Append-only rule:** this entry is appended after all prior history. Earlier text is unchanged.

### Why this entry exists

The user rejected the prior passive command-capture contract. The required interaction is now explicit:

`Начать → ChatGPT receives exactly «Ищи» → exact new user-turn is the anchor → next assistant writing block → structural stability → local Copy → complete text → only then local Avito Finder validation`.

### v0.4.0 behavior

1. The user clicks **Начать** in the isolated Avito Finder popup.
2. The extension activates ChatGPT in the current window.
3. Its separate ChatGPT adapter stages the literal ordinary message `Ищи` only in the persistent lower composer. A non-empty different user draft produces `START_PRIMARY_COMPOSER_OCCUPIED`; no text is replaced.
4. The adapter waits for the new user turn that text-matches `Ищи`. A different new user turn is not accepted as the anchor.
5. After that exact anchor, the adapter follows the copied Bridge capture ordering: assistant turn → local writing block → Copy readiness → two seconds unchanged DOM structure → local Copy click → body text from the same local root.
6. The ChatGPT adapter does not parse or validate Avito command labels. It transfers the full text and metadata to the isolated Avito Finder service worker.
7. Only the service worker parses the 12 labels from the ТЗ. Invalid text becomes `COMMAND_INVALID_AFTER_FULL_COPY`; Avito remains untouched.
8. A valid `INSPECT_FILTERS` command activates Avito only then and performs the existing read-only DOM inspection. `SEARCH`, card collection and report sending remain unimplemented.

### Exact-source boundary

The capture code is adapted from the exact nested Business Bridge `v1.8.34.5` archive. `BACKUP_AND_TRANSFER_GATE_v0.4.0.md` maps each transferred function and identifies only the required substitutions. The Avito Finder build has separate names, separate storage keys, separate worker, separate logs and no Bridge runtime import or Bridge task/queue/server calls.

### Tests and evidence

- syntax checks passed for all runtime JavaScript;
- Node tests passed: command parser, timing/order presence, full-text-before-validation boundary, isolation/permissions scan;
- Chromium DOM regression passed using the exact packaged runtime files: Start → `Ищи` → foreign user turn rejected → matching user anchor → assistant local writing block → two-second stability → one local Copy → full payload event;
- exact packaged ZIP validation and hashes are recorded in the v0.4.0 validation report and evidence archive.

### Live verification status

Not completed. The Chromium regression is a controlled fixture, not evidence from the user's actual ChatGPT or Avito tabs. The build must be called a **test candidate**, not a working release, until the live chain reaches at least `FULL_WRITING_BLOCK_TEXT_CAPTURED` and then `INSPECTION_COMPLETE` in the user's Chrome.

---

## Append — v0.4.1 — complete Bridge v1.8.34.5 capture-body transplant

**Date:** 2026-06-24  
**Status:** test candidate only; not live accepted and not release-ready.  
**Append-only rule:** This text is appended. Earlier entries are unchanged.

### Trigger and rollback boundary

The user rejected `v0.4.0` after a live test showed `WAITING_FOR_BRIDGE_EXACT_ANCHOR`, no `Ищи` user-turn, and an empty popup journal. The defect was not treated as a selector tweak. The v0.4.0 candidate is not patched for use. The rollback baseline remains the last live-confirmed Avito Finder read-only build v0.1.1; uninstalling the v0.4.x candidate and loading v0.1.1 returns to that baseline.

### Exact source used

The source is the nested exact Business Bridge archive `v1.8.34.5` and its `content_script.js` with SHA-256:

`6ea6a8a0b6961ff4c88b6b8e9c3096fbc82fad8bf4075d1b66aa040e19c12f20`

The v0.4.1 destination `chatgpt_content.js` contains all 118 source function names. The following capture functions are byte-identical to the exact source: `turnSections`, `userTurnIds`, `sectionUserText`, `resolveWritingBlockBinding`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `stageAutomationStartMessage`, `waitForNewUserAnchor`, `assistantCandidateAfterAnchor`, `sendMessageAndCaptureAnchor`, and `startPromptObserver`.

`promptTick` is byte-identical through detection, structural stability, local Copy and complete payload transfer. Its post-copy accepted branch stops the capture and hands the already obtained full text to the separate Avito Finder worker rather than starting Business Bridge task polling.

### Deliberate, bounded differences from Bridge

Only these boundary changes are made:

1. Runtime identity/version, overlay IDs, and composer staging attributes are Avito Finder identifiers (`data-avito-finder-*`).
2. `request()` routes the four capture-local events to an Avito Finder worker: local send-profile lookup, diagnostics, activity, and completed full-text payload. It does not call a Bridge server, queue or storage.
3. The external content message adapter exposes only Avito Finder messages. Its start handler preserves Bridge ordering: stage lower composer → exact 2000 ms render wait → resolve Send → one click → composer-clear confirmation → exact new `Ищи` user-turn anchor.
4. After full local Copy, the Avito Finder worker performs the 12-field command parse locally. No field/header/mode validation occurs in the ChatGPT content adapter before complete text transfer.
5. Business Bridge page reconciliation, queue polling, report delivery, attachments, Inspector interfaces, and shared storage are not started because they are outside Avito Finder.

### Popup correction

The popup no longer replaces log entries with `[]` after Start. It refreshes from `chrome.storage.local` on storage changes and once per second while open. A start operation returns only after the content adapter’s exact anchor handler completes or returns a concrete failure.

### Tests and evidence

- JavaScript syntax validation passed for every runtime file.
- Node tests passed: 6/6.
- Source inventory found 118 Bridge source functions and 118 destination functions; no source function is missing.
- The critical capture functions above have equal SHA-256 function bodies.
- Exact packaged ZIP integrity, extracted-JS syntax and source/extracted runtime SHA-256 equality passed.
- Chromium fixture navigation is blocked by this container policy with `net::ERR_BLOCKED_BY_ADMINISTRATOR`, including a local fixture URL. No claim of a live or Chromium DOM acceptance is made from this result.

### Live verification status and next road-map step

The confirmed project state remains **roadmap stage 3 not closed**. The next unclosed step is one live Chrome proof of:

`Начать → нижний composer receives exactly Ищи → exact new user-turn anchor → assistant writing block → 2 s stable local Copy → full text reaches local Avito Finder worker → only then local validation`.

Only after that proof may stage 4 activate Avito and perform the read-only filter inspection. `SEARCH`, candidate collection, and ChatGPT report delivery remain unimplemented.


---

## Append — v0.4.2 — strict active-dialog binding

**Date:** 2026-06-24  
**Status:** test candidate only; live Chrome acceptance is not complete.  
**Append-only rule:** this entry is added after earlier history without rewriting it.

### Trigger

The live v0.4.1 test sent `Ищи` into a different ChatGPT conversation in the same browser window. The source cause was `findInWindow("chatgpt", window.id)`, which selected the first matching ChatGPT tab instead of the active tab where the operator opened the popup.

### Corrected boundary

At Start, Avito Finder now uses the same entry selection rule as Bridge: `chrome.tabs.query({ active: true, lastFocusedWindow: true })`. It rejects a non-ChatGPT active tab and does not search for any other ChatGPT tab. Before `Ищи`, it captures and persists the exact context: `tabId`, `windowId`, `origin`, `chat_path`, and `conversationId`.

Every later ChatGPT operation verifies the stored context before acting: start dispatch, prompt-poll start, full text admission, stop, and return after Avito inspection. A missing tab, changed URL, changed conversation, different tab, or different window becomes `BLOCKED_CONVERSATION_CONTEXT_CHANGED`; there is no fallback search for another conversation.

The content adapter also verifies the expected identity before staging `Ищи`, after staging it, after the exact user-turn anchor, before prompt polling, while prompt polling, and on Stop. Thus the adapter cannot scan or Copy a writing block from a dialog reached by navigation after Start.

### Tests and evidence

- unit tests check exact URL conversation identity and reject a different tab, window or conversation ID;
- source contract test checks `active:true + lastFocusedWindow:true`, absence of a ChatGPT `findInWindow` fallback, strict expected identity in Start and prompt polling, and blocked-context events;
- exact ZIP checks are recorded in the validation report.

### Live status

Not live accepted. Required proof: launch in a dialog A while a different ChatGPT dialog B remains open in the same window; `Ищи` must appear only in A. Then navigate A to another dialog before the assistant form appears; the popup must show `BLOCKED_CONVERSATION_CONTEXT_CHANGED`, with no local Copy and no Avito activation.
---

## Append — v0.4.3 — Avito page-ready gate after live stage-4 evidence

**Date:** 2026-06-24  
**Status:** test candidate only; live stage-4 proof still required.  
**Append-only rule:** this entry is appended without changing earlier history.

### Live evidence that changed the plan

A v0.4.2 live run proved the ChatGPT side of the current path in the pinned conversation: `Ищи` was sent, the exact user anchor was captured, an assistant writing block became copy-ready, local Copy produced the full text, and the worker validated the full text as `INSPECT_FILTERS`.

The next event created an Avito tab with `url=null`. The worker then attempted the Avito content request immediately, which was correctly rejected as `CONTENT_TARGET_URL_REJECTED:avito`. No Avito filter was changed and no search was started.

### v0.4.3 scope

The v0.4.3 worker adds a page-ready gate only for the stage-4 Avito transition:

1. create or locate an Avito tab in the original window;
2. if the returned tab is early (`url=null`, loading, or otherwise not ready), log `AVITO_NAVIGATION_WAIT_STARTED` and wait for the same `tabId` and `windowId`;
3. accept readiness only when `tab.url` is an allowed Avito origin and `tab.status === "complete"`;
4. activate the ready tab, recheck it once more, then and only then inject/message `avito_content.js`;
5. Stop cancels a pending ready wait; a timeout/closed/moved tab becomes `BLOCKED_AVITO_PAGE_READY` with evidence.

`pendingUrl` is log-only. It is not sufficient to contact the page. The change contains no filter entry, no search, no listing collection, no seller action, and no ChatGPT report delivery.

### Tests and live status

A VM worker test simulates Chrome returning `url=null` and `status=loading` from `tabs.create`, then emitting `tabs.onUpdated` with an Avito URL and `status=complete`. The test asserts that `AF_INSPECT_AVITO_DOM` is sent only after the update. Exact ZIP checks are required before any test candidate is provided.

The current confirmed state is: the ChatGPT full-text capture path has one successful live proof; stage 4 remains unclosed until a real Avito tab reaches `AVITO_PAGE_READY`, the read-only snapshot is returned, and no filter/search mutation is observed.

---

## Append — v0.5.0 — bounded DOM diagnostic dialogue and same-chat report return

**Date:** 2026-06-24  
**Status:** test candidate; diagnostic live acceptance still required.  
**Append-only rule:** this entry is added after earlier history without changing it.

### New approved interaction

A separate `DIAGNOSE_DOM` command mode is added for public Avito pages and explicitly named page areas. The command is received only after the existing exact chat sequence:

`Начать → «Ищи» → exact user-turn → assistant writing block → local Copy → full text → local worker validation`.

Only after the full text is received does the worker parse `Действие` for two ordinary text lines:

```text
Страница: https://www.avito.ru/...
Область: PAGE_MAIN_VISIBLE | SEARCH_SURFACE_VISIBLE | DIALOG_VISIBLE | LISTING_CARD_VISIBLE | REVIEWS_VISIBLE
```

The extension activates the requested public Avito page in the same Chrome window, waits for the same tab to have an allowed Avito URL and `status=complete`, then captures only the requested visible scope. It returns the bounded report to the same pinned ChatGPT conversation with the transferred lower-composer / Send / confirmed-user-turn sequence.

### Data boundary

The diagnostic snapshot contains only the selected visible public DOM area: a bounded tree, visible control metadata, and sanitized limited HTML. It excludes the full ChatGPT page, composer draft, cookies, storage, credentials, network traffic, hidden API responses, input values, and unbounded full-page HTML. The report is limited in size.

The diagnostic capture performs no Avito input, filter changes, search, listing opening, seller contact, account change, payment, proxy, captcha handling, or network request.

### Changed behavior on UI drift

A requested area that cannot be uniquely located produces `BLOCKED_SCOPE_UNRESOLVED` and a short evidence report. It does not guess a selector or click a similar element. The next action must be another diagnostic command chosen after the returned snapshot.

### Report delivery and pause

After capture, the report is addressed only to the pinned ChatGPT `tabId + windowId + origin + chat_path + conversationId`. If the lower composer contains a user draft, the extension does not modify it and records `PAUSED_USER_COMPOSER_OCCUPIED`; the popup offers `Продолжить отчёт`. No fallback to another ChatGPT tab exists.

### Tests and current status

Tests cover diagnostic command parsing, the Avito page-ready gate, bounded snapshot request, report delivery only to the pinned chat, and busy-composer pause. Exact ZIP checks are required. Live Chrome proof of `DIAGNOSE_DOM → report in the same chat` remains mandatory before release status.


---

## Append — v0.5.1 — свободный локальный валидатор и возврат ошибки в закреплённый чат

**Изменение.** После local Copy расширение передаёт полный текст writing block только в локальный скриптовый разбор. Отсутствие старых 12 подписей само по себе больше не является ошибкой: режим, публичный адрес Avito и область диагностики определяются из всего полученного текста. Для `DIAGNOSE_DOM` и `INSPECT_FILTERS` число кандидатов не применяется; `0` не блокирует диагностику. Ограничение 1–30 применяется только к `SEARCH`.

**Ошибка прежней реализации.** `core.js` требовал все 12 полей и проверял `Количество кандидатов >= 1` до ветки режима. Поэтому собственная диагностическая команда с `Количество кандидатов: 0` была отклонена после успешного полного local Copy. Кроме того, ошибка оставалась в popup как пауза и не возвращалась в закреплённый ChatGPT-чат.

**Фактическая причина.** Общая форма и общий числовой ограничитель были ошибочно использованы как универсальный контракт. Это противоречило требованию: расширение сначала забирает весь текст, валидирует его локально и при невозможности выполнить действие возвращает ошибку в тот же чат.

**Исправление.** Добавлен свободный режимный разбор полного текста. Ошибка локального валидатора формирует обычный отчёт, доставляемый через тот же закреплённый ChatGPT-контур; если composer занят, применяется существующая безопасная пауза и `Продолжить отчёт`. В отчёт не добавляется полный текст writing block — только fingerprint, определённый режим и коды причин.

**Проверки.** Нужны: exact ZIP, Node tests, live Chrome: свободная диагностическая команда, `Количество кандидатов: 0`, ошибка `MODE_UNRESOLVED` с доставкой в тот же чат. Live-acceptance на момент сборки не выполнена.


---

## Append — v0.5.2 — continuous same-chat dialogue after every delivered report

**Date:** 2026-06-24  
**Status:** test candidate; live continuous-cycle acceptance is required.  
**Append-only rule:** this section is appended; all prior text remains unchanged.

### Defect evidenced by the live run

The live run `af-20260624111020-64c8` completed a diagnostic report delivery into the pinned chat, but then stopped waiting for the next assistant writing block. The user had to issue another `Ищи`, which contradicts the approved Bridge-style interaction. The same log also showed a requested main-page snapshot becoming `LISTING_CARD_VISIBLE`: the local inference treated the safety phrase “не открывай объявления” as a target-scope hint.

### Corrected dialogue contract

`Начать` sends `Ищи` exactly once. Each subsequent cycle is: confirmed user turn carrying the prior result or error → next assistant writing block → local Copy of its full text → local script validation → one bounded local action → result/error returned to the same pinned chat → confirmed result/error user turn becomes the next anchor. The extension never waits for another `Ищи` between iterations. It does not decide the next diagnostic scope; it waits for the next assistant writing block. The cycle stops only on explicit Stop / остановка / стоп / хватит / завершить, or when ChatGPT intentionally emits no next writing block.

### Scope parsing correction

`DIAGNOSE_DOM` still accepts free text, but a diagnostic scope is no longer inferred from a prohibition. Explicit scope tokens/lines are preferred; otherwise a non-positive command defaults safely to `PAGE_MAIN_VISIBLE`. A request for a card, dialog, review area, or search surface must be explicit or positively worded.

### Recovery and safety

After report delivery the worker persists `WAITING_FOR_NEXT_ASSISTANT_FORM` with the report’s confirmed user-turn ID and immediately restarts the same pinned-dialog prompt watcher. If the ChatGPT content script reloads, it asks the worker only whether that durable wait can resume in the same pinned identity; no text is staged, reinserted, or resent. A mismatched tab/window/path/conversation blocks the run.

### Tests and live status

The candidate adds Node/VM tests for the report-to-next-form transition, validation-error continuation, exact continuation anchor, reload recovery contract, and prohibition-safe scope inference. Exact ZIP integrity, runtime hash equality, syntax checks, and Chromium fixture checks are required. The user’s actual Chrome must still prove at least two consecutive cycles without a second `Ищи` before this is considered live accepted.

---

## Append — v0.5.3 — anchor fence, current-Avito reuse and observable read-only timing

**Date:** 2026-06-24  
**Status:** test candidate only; not live accepted and not release-ready.  
**Append-only rule:** This entry is appended. Earlier history is unchanged.

### Live defect that triggered this change

The v0.5.2 user-Chrome run proved that a report could establish a next-form poll, but then exposed two separate failures:

1. a late local-Copy result from the previous assistant form could arrive after the Worker had already anchored the next poll; the older content-script callback could stop or interfere with the newer wait;
2. the next diagnostic text referred to an already-open Avito page without repeating an absolute URL, but the local parser required a URL and returned `DIAGNOSTIC_PAGE_REQUIRED` before any Avito action.

The live evidence also showed that the first Avito activation and DOM capture occurred too quickly to be observable by the operator.

### Scope of v0.5.3

- The normal Bridge-derived capture path remains: same pinned ChatGPT tab → one assistant writing block → local Copy → full text → Worker-side validation.
- The extension adds a **prompt-poll generation fence**. Every polling generation has an ID. A callback from an older generation may not stop, replace, or cancel a newer anchor wait. Late old candidates are reported as `STALE_FORM_CANDIDATE_IGNORED` and are ignored without blocking the pinned conversation.
- A natural-language `DIAGNOSE_DOM` instruction can explicitly say that it targets the already-open/current Avito page. The Worker then reuses only the run-owned `avito_tab_id`, after confirming that it is an allowed Avito URL in the pinned window. It does not guess another tab or page. When no durable Avito target exists, the action stops safely with `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE`.
- Diagnostic and read-only inspection actions now include visible production pauses: **2.5 seconds after Avito activation before capture**, and **2 seconds after capture before return to ChatGPT**. The live journal records `AVITO_VISIBLE_DELAY_STARTED` and `AVITO_VISIBLE_DELAY_COMPLETED`.
- `INSPECT_FILTERS` continues to use the public Avito root URL. The new no-URL reuse behavior applies only to an explicit diagnostic reference to the already-open/current Avito page.

### Safety boundary

No search typing, filter mutation, listing opening, seller contact, cookie/storage reading from website pages, proxy/captcha handling, hidden API/network calls, or Business Bridge runtime import was added. A stale form does not change tabs or Avito. A missing reuse target does not create or navigate a tab.

### Automated evidence

- JavaScript syntax checks passed for all runtime files.
- `node --test tests/*.test.mjs`: **31/31 passed**.
- New covered cases:
  - natural diagnostic text can reuse only the already-open Avito page;
  - a stale anchor candidate is ignored without blocking the newer same-chat poll;
  - two diagnostic forms after one Start reuse the durable Avito tab and produce two reports;
  - visible-delay start/end events are emitted for each Avito capture;
  - the code contains a generation fence that prevents an old accepted response from stopping a newer poll.
- Exact packaged ZIP and extracted source/tests ZIP must still be validated below before delivery.

### Live acceptance status

Not complete. The user must run the exact packaged build in Chrome and prove: second assistant form after a diagnostic report activates the existing Avito tab, emits the visible delay events, captures the requested scope, returns to the same chat, and starts the next wait without another `Ищи`.

### Package-validation addendum — v0.5.3

The exact runtime ZIP was built from an explicit allowlist of 9 runtime files. `unzip -t` passed for the runtime ZIP and source/tests ZIP. Both source and extracted source/tests ZIP ran `node --test tests/*.test.mjs` with **31 passed, 0 failed**. SHA-256 matched for every runtime file between the source tree and extracted runtime ZIP. A local Playwright/Chromium fixture attempt was run, but navigation to the fixture itself was blocked by `net::ERR_BLOCKED_BY_ADMINISTRATOR`; this is retained as a failed environment-evidence attempt and is not treated as live DOM proof.


---

## Append — v0.5.4 — explicit mode boundary, anchor handoff and bounded search surface

**Date:** 2026-06-24  
**Status:** test candidate; no live Chrome acceptance for this version.  
**Append-only rule:** this entry is appended without rewriting prior history.

### Live defect that triggered the change

The user-Chrome v0.5.2 run exposed two independent defects:

1. A copied diagnostic instruction contained the selector `input[data-marker="search-form/suggest/input"]`. The local parser scanned every token in the copied text, classified the form as `SEARCH` rather than `DIAGNOSE_DOM`, and raised `CITY_REQUIRED_FOR_SEARCH` before any second Avito activation.
2. After a local validation-error report became a new ChatGPT user-turn anchor, the next prompt wait could receive an older form callback. The old callback could interfere with the new wait in the older runtime.

The same live evidence also showed that `SEARCH_SURFACE_VISIBLE` previously selected the input itself rather than a bounded parent container with the surrounding search controls.

### v0.5.4 scope

- The mode is now read only from an explicit local command instruction: an exact `Режим:` field, a bare first instruction line, or a first-line prefix such as `DIAGNOSE_DOM.`. The Worker does not infer `SEARCH` by scanning selector strings, URLs, HTML, or arbitrary words inside the copied payload.
- The parser safely removes sentence-ending punctuation from an explicit public Avito URL. A diagnostic that explicitly says to use the already-open Avito page may reuse only the durable run-owned Avito tab.
- Every copied form has a local form key: current anchor + assistant turn + text fingerprint. Repeated delivery of the same form is ignored locally as `DUPLICATE_FORM_CANDIDATE_IGNORED`.
- A validation or unimplemented-action report returns an explicit `continuation_started` handoff. The previous content wait cannot stop a newer prompt-poll generation; the next confirmed report user-turn is the only next anchor.
- `SEARCH_SURFACE_VISIBLE` starts from the exact public search input and climbs visible parents. A root is accepted only if it includes the input, a category control, and the Find button. It never returns the input itself. If no bounded parent meets those facts, the response is `BLOCKED_SCOPE_UNRESOLVED` with up to eight parent candidates. It does not fall back to `body`.
- The public Avito navigation remains read-only. The existing 2.5-second post-activation and 2-second post-capture visible pauses remain in place.

### Reference boundary

The transferred ChatGPT capture functions `turnSections`, `userTurnIds`, `sectionUserText`, `resolveWritingBlockBinding`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `stageAutomationStartMessage`, `waitForNewUserAnchor`, `assistantCandidateAfterAnchor`, and `sendMessageAndCaptureAnchor` are checked byte-for-byte against the supplied Business Bridge v1.8.34.6 reference. The v0.5.4 changes are isolated to Avito Finder local parsing, Worker handoff state, bounded diagnostic scope selection, and version metadata.

### Tests and evidence

- `node --test tests/*.mjs`: 36 passed, 0 failed on source.
- The suite includes a regression where `DIAGNOSE_DOM` and `SEARCH_SURFACE_VISIBLE` coexist with `search-form/suggest/input`; the mode remains `DIAGNOSE_DOM`.
- The suite covers local duplicate-form suppression, explicit continuation handoff, durable same-run Avito reuse, visible delay logs, current-anchor-only admission, and page-ready gating.
- `node --check` is required for all runtime JavaScript files.
- Exact ZIP integrity and source/extracted runtime SHA-256 equality are required before sharing the candidate.
- Local Chromium remains blocked by this environment's administrator policy for file navigation; no live browser acceptance is claimed from container checks.

### Current confirmed state and next roadmap step

- Stage 3 remains live-proven: `Начать → Ищи → exact user anchor → writing block → local Copy → Worker-side validation`.
- Stage 4 transport remains live-proven: Avito tab activation, read-only snapshot, same-chat return, report delivery, and a next-form poll have occurred.
- The nearest unclosed step is a live v0.5.4 sequence in the pinned user Chrome: a diagnostic form containing the exact search-input selector must remain `DIAGNOSE_DOM`, visibly reuse the run-owned Avito tab, return a bounded search-surface snapshot or a bounded parent-candidate report, then continue to the next writing form without another `Ищи`.


---

## Append — v0.5.5 — bounded search-input ancestry evidence

**Date:** 2026-06-24  
**Status:** test candidate; live Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without modifying prior history.

### Live defect that triggered the change

The user-Chrome v0.5.4 diagnostic reached the exact public search input but returned `BLOCKED_SCOPE_UNRESOLVED` without the promised parent-candidate evidence. The requested search-surface action therefore could not progress safely: the extension knew a bounded root was not proven, but did not return enough structure for ChatGPT to choose the next read-only inspection.

### What changed

- The public `SEARCH_SURFACE_VISIBLE` resolver climbs up to 16 visible ancestors from `input[data-marker="search-form/suggest/input"]` and checks both visible controls and bounded visible container text for the category and Find controls. It never falls back to `body`, the input itself, a listing card, or a recommendation card.
- If no bounded common root is proven, the same-chat report now includes up to 16 **parent candidates** with depth, bounded public class/data-marker description, detected input/category/find/location features and visible public controls.
- `SEARCH_INPUT_ANCESTRY_VISIBLE` is a read-only diagnostic scope for returning that parent chain intentionally.
- `SEARCH_INPUT_PARENT_VISIBLE` with a locally validated `Глубина родителя: 1..16` returns one chosen ancestor as a bounded DOM/HTML snapshot. This permits ChatGPT to inspect the real interface iteratively rather than guessing selectors.
- The diagnostic report now renders `Кандидаты области` rather than hiding the scope-candidate data returned by the Avito content script.

### Safety and interaction

No typing, UI click, filter mutation, search execution, listing opening, seller contact, payment, hidden API/network call, cookie/page-storage read, proxy or captcha handling was added. The existing pinned-dialog and visible-tab transition contract remains unchanged.

### Tests and known limits

The candidate adds parser/report regressions and an intercepted-Avito Chromium DOM fixture that loads the packaged public content script on an `https://www.avito.ru/` origin without contacting Avito. Exact ZIP, source/extracted runtime equality and standard Node tests are required. This does not replace a live test in the user's Chrome; the package remains a test candidate until the actual pinned session proves the unresolved-parent report or a bounded search-surface snapshot and the next dialogue iteration.

---

## Append — v0.6.0 — Generic Visible-UI Action Engine

**Date:** 2026-06-24  
**Status:** test candidate; live user-Chrome acceptance is not yet complete.  
**Append-only rule:** this section is appended without modifying prior history.

### Why the architecture changed

The earlier diagnostic sequence added narrow handlers for individual Avito controls and scopes. That design was rejected because every new visible control or changed layout would require another extension build. The project now introduces one local, bounded generic action engine. It does not receive JavaScript, CSS selectors, hidden API instructions or a remote command channel from ChatGPT.

### Generic plan contract

A writing block may use `AVITO_UI` or an ordinary `Шаги:` / `Действия:` section. Local parsing recognizes only six generic visible actions:

1. `CLICK` — click one uniquely resolved visible public control;
2. `TYPE` — write bounded text into one uniquely resolved visible input/textarea/contenteditable control;
3. `WAIT` — bounded visible delay up to five seconds;
4. `WAIT_FOR` — wait up to five seconds for one uniquely resolved visible control;
5. `SNAPSHOT` — capture a bounded read-only DOM/HTML scope;
6. `COLLECT_LISTINGS` — collect up to 30 visible public listing records without opening listings.

Target resolution is local and generic: exact `data-marker`, exact placeholder, then exact visible text/aria-label/title. No selector from the writing block is executed. Missing, disabled, ambiguous or policy-blocked targets stop the current plan before that target is clicked or written.

### Safety and project boundary

The engine uses only the normal visible Avito UI in the run-owned tab. It visibly activates the tab, pauses before and after interactive steps, returns to the same pinned ChatGPT conversation and continues through the existing report-anchor cycle.

It blocks seller messaging, calls, purchase, payment, checkout, order, basket, booking and delivery-finalization targets. It does not use cookies, page storage, hidden API/network calls, proxy/captcha methods or arbitrary JavaScript. It does not import or share Business Bridge source, runtime, storage keys, logs, queue, service worker or archives.

### Business Bridge capture boundary

The copied ChatGPT capture adapter was not functionally edited. Compared to v0.5.6, its only changes are the `0.6.0` version identifiers. The ten Bridge-derived capture functions remain byte-identical to the supplied v1.8.34.6 reference and to v0.5.6: `turnSections`, `userTurnIds`, `sectionUserText`, `resolveWritingBlockBinding`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `stageAutomationStartMessage`, `waitForNewUserAnchor`, `assistantCandidateAfterAnchor`, and `sendMessageAndCaptureAnchor`.

### Automated evidence

- `node --test tests/*.test.mjs`: 49 passed, 0 failed.
- Worker regression: generic `AVITO_UI` plan used the same pinned ChatGPT report delivery and next-anchor continuation as diagnostics.
- Chromium fixture: visible city control click → visible city input type → visible city choice click → search input type → Find click → public listing collection completed; duplicate visible label was blocked as `UI_TARGET_AMBIGUOUS` without either duplicate being clicked.
- Existing Chromium diagnostics passed for the public location dialog and bounded search ancestry.
- The historical Bridge exact-capture Chromium fixture could not navigate in this container because Chromium policy returned `ERR_BLOCKED_BY_ADMINISTRATOR`; this is not treated as live proof. The byte-identity and Node capture tests remain the evidence for the unchanged ChatGPT logic.

### Current confirmed state and next roadmap step

Stage 3 and Stage 4 remain live-proven from prior user-Chrome runs. The generic engine is package-tested but not yet live-accepted in the user Chrome profile. The nearest unclosed roadmap step is a live three-step plan in the pinned ChatGPT/Avito session: open the current public city control, type a city into the visible dialog, select one unambiguous city result, return the same-chat report, and continue to the next writing form without another `Ищи`.


---

## Append — v0.6.1 — Bridge HTML capture parity and generic-plan worker handoff

**Date:** 2026-06-25  
**Status:** test candidate; live user-Chrome acceptance is still required.  
**Append-only rule:** this section is appended without modifying prior history.

### Triggering live failure

The first user-Chrome v0.6.0 `AVITO_UI` form completed the exact ChatGPT side of the chain: `Ищи` was sent, the exact user anchor was captured, the assistant writing block was waited for, local Copy became ready, the complete copied payload was received, and local parsing accepted `AVITO_UI`. The next Worker transition stopped at `AVITO_TASK_BLOCKED: DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE`; there was no Avito tab activation after the accepted form.

### First divergence and five preceding transitions

- **First wrong object/action:** `ensureAvitoTarget(state, requestedUrl=null, purpose=avito_ui_action_plan)` reused the no-URL diagnostic policy and threw `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE` instead of applying generic-plan target policy.
- **T-5:** `FULL_WRITING_BLOCK_TEXT_RECEIVED` received the complete local Copy payload for the exact current assistant turn.
- **T-4:** `LOCAL_COMMAND_VALIDATION_COMPLETED` accepted `mode=AVITO_UI` from the first instruction line.
- **T-3:** `queueAvitoTask` derived `uiPlan.page_url = null` because the ordinary command correctly said “на закреплённой вкладке Avito” without forcing a URL.
- **T-2:** no durable `avito_tab_id` existed after the extension update.
- **T-1:** the Worker called the reuse-only diagnostic branch with no fallback target.

The error path also only saved `FAILED_WITH_EVIDENCE`; it did not return a same-chat failure report or create the next anchor, so the completed writing block was stranded behind a stopped prompt poll.

### What changed

- `AVITO_UI` now has a generic target policy independent from `DIAGNOSE_DOM` reuse-only behavior:
  1. use the run-owned Avito tab when it remains valid in the pinned window;
  2. otherwise reuse a visible Avito tab in that exact window;
  3. otherwise create only `https://www.avito.ru/` in that exact window.
- A no-URL diagnostic remains reuse-only and still safely returns `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE` rather than guessing a page.
- Every terminal Worker-side Avito target failure now becomes a normal same-chat `avito_failure` report. Its confirmed user turn becomes the next anchor before another prompt poll starts.
- The ten Bridge-derived collection/copy/anchor functions remain byte-identical to the supplied Bridge v1.8.34.6 reference. Avito Finder still has separate files, storage keys, service worker, logs and packaging; no Bridge runtime is imported or shared.

### HTML parity test against the Bridge reference

A Chromium fixture models the observed current ChatGPT DOM shape: current assistant turn, writing block, disabled Copy that becomes enabled, ordinary lower composer and an exact user-turn created by Send. The actual packaged Avito Finder adapter and the actual supplied Bridge v1.8.34.6 content script run independently on that same fixture. The test proves both adapters produce the same captured anchor, assistant turn, full writing-block payload, payload bytes, ready Copy state and exactly one local Copy click.

### Tests and evidence

- `node --test tests/*.test.mjs`: **51 passed, 0 failed**.
- Source and exact-package runs cover generic `AVITO_UI` after an extension update with no durable Avito tab id: public-root creation/reuse, page-ready gate, same-chat report handoff and next anchor.
- Source and exact-package runs cover a terminal tab-creation failure: no repeated click/type/navigation, same-chat failure report and next-anchor continuation.
- Chromium fixtures cover: exact ChatGPT Copy/anchor capture, direct Bridge-vs-Avito HTML parity, bounded search ancestry, public location dialog, generic click/type/click/type/click/listing collection, and ambiguous-target blocking before any click.
- Every packaged runtime JavaScript file passes `node --check`; exact package contents and source/extracted runtime SHA-256 values are compared.

### Current confirmed state and next roadmap step

- The user-Chrome trace proves current ChatGPT capture through full local Copy and Worker-side `AVITO_UI` validation.
- This candidate repairs the first Worker transition that prevented any Avito action after that capture.
- The nearest unclosed roadmap step is a live user-Chrome v0.6.1 run of the real request: Zлатоуст → “ноутбук” → price 10 000–15 000 ₽ → public listing collection → same-chat report and automatic next-form wait without a new `Ищи`.
