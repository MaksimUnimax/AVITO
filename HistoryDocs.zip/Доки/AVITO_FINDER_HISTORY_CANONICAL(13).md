# Avito Finder — каноническая документация расширения

> **APPEND-ONLY.** Этот файл является единственным каноническим описанием Avito Finder. Ранее добавленный текст не переписывается и не удаляется. Каждое изменение добавляется только в конец нового раздела с версией, датой, причиной, фактическими изменениями, проверками, известными ограничениями и условиями приёмки.

## 1. Назначение

Avito Finder — отдельное Chrome-расширение для поиска товаров на Avito через уже открытую пользовательскую сессию Chrome. Пользователь формулирует потребность в выделенном чате ChatGPT. ChatGPT уточняет недостающие условия, формирует обычную структурированную команду, расширение активирует вкладку ChatGPT, получает команду, активирует вкладку Avito, выполняет только разрешённые действия через видимый интерфейс сайта, собирает ограниченный набор карточек и возвращает наблюдаемые результаты в тот же чат. ChatGPT затем ранжирует 5–10 подходящих вариантов по соответствию запросу, цене и рискам.

Расширение не принимает решение о покупке, не пишет продавцам, не оформляет сделки и не выполняет скрытый сетевой сбор данных.

## 2. Изоляция

Avito Finder не связан с Business Bridge / Inspector:

- отдельный manifest, Service Worker, popup, content scripts, архивы и документация;
- отдельный префикс хранилища `avito_finder.*`;
- отдельные технические идентификаторы `af-*`;
- запрещены общие storage keys, общая очередь, общий runtime-код и общие журналы;
- работа или поломка одного расширения не должна менять другое.

## 3. Границы разрешённого поведения

Разрешено только:

- работать в текущем Chrome-профиле пользователя;
- активировать конкретную вкладку ChatGPT перед чтением команды и перед возвратом отчёта;
- активировать конкретную вкладку Avito перед работой на Avito;
- через обычные видимые элементы Avito читать доступные фильтры, заполнять согласованные параметры и собирать ограниченные видимые результаты;
- создавать одну вкладку Avito только после явного пользовательского запуска, если подходящей вкладки нет;
- собирать видимые ссылку, заголовок, цену, локацию, характеристики, состояние и доступные публичные метки;
- ставить задачу на паузу, если поле ChatGPT занято пользовательским текстом.

Запрещено:

- отправлять сообщения продавцам;
- покупать, бронировать, сохранять объявления, менять настройки профиля, оплачивать или подавать жалобы;
- читать, экспортировать или передавать cookies, пароли, токены, `.env` и иные секреты;
- использовать скрытые API Avito, обход captcha/anti-bot/rate-limit, прокси или массовый фоновой сбор;
- нажимать отправку в ChatGPT, если composer занят пользовательским текстом;
- считать клик Send, очистку composer или внутренний флаг доказательством доставки. Успех доставки подтверждается только появлением нового исходящего user-turn с ожидаемым текстом.

## 4. Обязательное переключение вкладок

Каждый фактический переход должен быть видимым:

```text
ChatGPT-команда
→ активировать вкладку Avito
→ выполнить работу на Avito
→ активировать вкладку ChatGPT
→ вернуть отчёт
```

Скрытая фоновая работа на Avito запрещена. Если Chrome не позволяет активировать нужную вкладку, задача завершается понятным статусом `BLOCKED_TAB_ACTIVATION` без обходного пути.

## 5. Текущий этап

Текущая реализация — этап 1: read-only обследование DOM ChatGPT и Avito. Поиск, ввод фильтров, запуск поиска, сбор объявлений и доставка результатов в ChatGPT ещё не реализованы и не должны быть представлены как готовые.

---

# История изменений

## 2026-06-24 — v0.1.0: read-only DOM inspector

### Что добавлено

- отдельное расширение Manifest V3 `Avito Finder`;
- отдельные `service_worker.js`, `popup.*`, `core.js`, `chatgpt_content.js`, `avito_content.js`;
- отдельные ключи `avito_finder.*`;
- popup с кнопками «Начать обследование» и «Стоп», статусом и журналом;
- поиск и активация вкладок ChatGPT и Avito;
- read-only DOM-снимки без ввода, поиска, фильтров, отправки сообщений продавцам или доступа к cookies;
- создание одной вкладки Avito только после явного нажатия пользователя, если Avito-вкладка отсутствует.

### Проверки

- локальные тесты и повторный прогон против распакованного exact ZIP;
- `node --check` runtime JavaScript;
- проверка manifest, ZIP и хэшей;
- статические ограничения: нет cookies, внешних API, Business Bridge references, произвольного исполнения кода, поиска или сообщений продавцам.

### Известная ошибка реализации

На уже открытых вкладках после установки/обновления content script мог отсутствовать. Service Worker находил и активировал правильную вкладку, но `chrome.tabs.sendMessage(...)` завершался ошибкой:

```text
Could not establish connection. Receiving end does not exist.
```

### Почему прежняя проверка не предотвратила дефект

Эмуляционные тесты проверяли саму логику сообщений, но не сценарий установки расширения при уже открытых вкладках, где content script не был автоматически внедрён.

### Статус живой проверки

Не пройдена: пользовательский журнал показал реальный дефект получения сообщения.

---

## 2026-06-24 — v0.1.1: recovery отсутствующего content-script получателя

### Причина изменения

Пользовательская живая проверка `v0.1.0` показала последовательность:

```text
TAB_ACTIVATED role="chatgpt"
READONLY_INSPECTION_BLOCKED reason="Could not establish connection. Receiving end does not exist."
```

Это доказало, что вкладка выбиралась правильно, но content script в ней отсутствовал.

### Что изменено

- Worker при точной ошибке отсутствующего получателя сначала сверяет разрешённый URL и роль вкладки;
- затем внедряет только заранее упакованные файлы соответствующей роли:
  - ChatGPT: `core.js` и `chatgpt_content.js`;
  - Avito: `core.js` и `avito_content.js`;
- после этого делает только один повторный read-only запрос;
- добавлена защита от параллельных запусков обследования;
- после обхода фокус возвращается на вкладку ChatGPT.

### Что намеренно не менялось

- нет поиска, ввода текста, установки фильтров, кликов по карточкам или отправки отчёта;
- нет Business Bridge-кода или общих хранилищ;
- нет произвольного `executeScript` и нет выполнения пользовательского JavaScript;
- нет доступа к cookies, токенам, секретам или сетевым API Avito.

### Проверки

- 30/30 локальных тестов на исходниках;
- 30/30 тех же тестов против файлов, извлечённых из exact ZIP;
- `node --check` runtime JavaScript;
- `unzip -t`;
- проверка manifest, хэшей и совпадения исходников с exact ZIP;
- статические проверки отсутствия cookies, внешних API, Business Bridge references, произвольного кода, поиска и контактов с продавцами.

### Живое доказательство

**Не получено.** `v0.1.1` является кандидатом, проверенным эмуляционно и по exact ZIP. Следующая обязательная приёмка — установка пользователем, один клик «Начать обследование» и проверка журнала фактической последовательности:

```text
TAB_ACTIVATED role="chatgpt"
CONTENT_RECEIVER_MISSING role="chatgpt"        # только если скрипта не было
CONTENT_SCRIPT_INJECTED role="chatgpt"          # только если скрипта не было
CHATGPT_DOM_CAPTURED
TAB_ACTIVATED role="avito"
CONTENT_RECEIVER_MISSING role="avito"           # только если скрипта не было
CONTENT_SCRIPT_INJECTED role="avito"            # только если скрипта не было
AVITO_DOM_CAPTURED
TAB_ACTIVATED role="chatgpt_return"
READONLY_INSPECTION_COMPLETE
```

### Условия приёмки v0.1.1

1. На уже открытых вкладках ChatGPT и Avito расширение успешно собирает оба read-only DOM-снимка.
2. Вкладки фактически активируются по порядку ChatGPT → Avito → ChatGPT.
3. В журнале нет `Could not establish connection. Receiving end does not exist.` после допустимой recovery-попытки.
4. Расширение не вводит текст, не меняет фильтры и не ищет объявления.
5. Пользователь не наблюдает побочных действий в аккаунте Avito или ChatGPT.

### Последнее изменение

`v0.1.1`: добавлена контролируемая recovery-инъекция упакованных content scripts для ранее открытых вкладок. Живая приёмка ещё обязательна.

---

## 2026-06-24 — v0.1.1: живая приёмка read-only обследования пройдена

### Фактическое живое доказательство

Пользователь выполнил один запуск на реальных вкладках одного окна Chrome. Popup вернул:

```text
Задача: af-20260624064334-4xw6
Вкладка ChatGPT: https://chatgpt.com/c/6a3b74d9-aff4-83eb-9eda-1ff668a9c96d
Вкладка Avito: https://www.avito.ru/
Статус Avito: DOM доступен для обследования
ChatGPT DOM: assistant/user контейнеры 12; composer-кандидаты 6; Send-кнопки 0
Avito DOM: формы/поля 1; кнопки 48; ссылки-кандидаты 0; признаки логина/captcha не обнаружены
```

Это подтверждает: вкладки ChatGPT и Avito доступны; read-only content scripts отвечают; Avito не показал login/captcha; этап 1 не выполнял поиск, ввод текста, изменение фильтров или отправку сообщения.

### Ограничение доказательства

Этот отчёт не доказывает сбор команд, установку фильтров, запуск поиска, сбор карточек или доставку результата в ChatGPT. Эти действия в v0.1.1 отсутствуют.

---

## 2026-06-24 — v0.2.0: read-only захват команды и обследование поверхности фильтров

### Причина изменения

Живая приёмка v0.1.1 подтвердила доступность обеих вкладок и DOM. Следующий безопасный шаг — захватить последнюю новую обычную assistant-форму команды из выделенного чата и прочитать доступные элементы фильтров Avito. Нельзя переходить к вводу, кликам фильтров или поиску без этого переходного шага.

### Что добавлено

- кнопка popup «Прочитать команду и фильтры»;
- чтение только последней допустимой assistant-команды после последнего user-сообщения;
- обычная форма без JSON и скрытых BBI-маркеров с обязательными разделами из ТЗ;
- защита от повтора уже обработанного `turnId`;
- активируемая последовательность `ChatGPT → Avito → ChatGPT`;
- read-only снимок поверхности фильтров Avito: видимые поля, кнопки, combobox и признаки filter/search form;
- отдельный локальный ключ `avito_finder.last_command`;
- понятный отчёт, который явно фиксирует отсутствие ввода, изменения фильтров, поиска, открытия карточек и отправки сообщений.

### Что намеренно не добавлялось

- ввод текста на Avito;
- выбор категории, города, цены или фильтров;
- кнопка поиска;
- сбор объявлений;
- сообщение продавцам;
- автоматическая отправка результата в ChatGPT;
- доступ к cookies, сетевым API, скрытым API или данным Business Bridge.

### Тесты и доказательства сборки

- Node.js `node --test`: проверяются форма команды, обязательный город для SEARCH, запрет BBI/JSON-маркеров, выбор только новой assistant-команды после user-turn, защита baseline turn, read-only отчёт и изоляция storage;
- статические контракты проверяют минимальные разрешения, целевые host permissions, отсутствие сетевых API/cookies/продавцов, отсутствие dynamic code и отсутствие write/search handlers;
- `node --check` всех JS-файлов;
- exact ZIP проверяется через `unzip -t`, повторный `node --test` против распакованного архива и сравнение хэшей файлов.

### Статус живой проверки

Не пройдена. `v0.2.0` — кандидат для следующего живого шага: после того как ChatGPT сформирует обычную команду `Режим: INSPECT_FILTERS`, пользователь нажимает в popup «Прочитать команду и фильтры» и передаёт сюда отчёт и последние события.

### Условия приёмки v0.2.0

1. Расширение захватывает только новую assistant-форму после последнего user-сообщения и не выбирает старую историю.
2. При повторном запуске без новой команды возвращается `NO_NEW_VALID_COMMAND` и Avito не активируется для сканирования.
3. При допустимой команде вкладки реально активируются в порядке ChatGPT → Avito → ChatGPT.
4. Отчёт показывает поля команды и поверхность фильтров.
5. Не происходит ввод, изменение фильтров, поиск, открытие карточек или отправка сообщения.
6. Вкладки ChatGPT и Avito остаются изолированными от Business Bridge.

### Последнее изменение

`v0.2.0`: добавлен read-only переход «последняя assistant-команда → поверхность фильтров Avito», без каких-либо изменений страницы или передачи результата в чат.

### Дополнительная проверка exact package в Chromium

Точный распакованный пакет был передан Chromium через `--disable-extensions-except` и `--load-extension` в отдельном временном профиле. Chromium запустился без manifest/parser error в журнале. В headless DevTools не появился наблюдаемый extension worker target, поэтому эта проверка подтверждает только отсутствие немедленной ошибки запуска Chromium с путём пакета, но **не** подтверждает работу расширения в реальной вкладке. Живая приёмка v0.2.0 по-прежнему обязательна.


---

## 2026-06-24 — v0.2.1: восстановление захвата команды через writing block и локальный Copy

### Фактическая причина поломки v0.2.0

Живой запуск `v0.2.0` остановился в `WAITING_FOR_COMMAND` и оставил в popup прежний отчёт этапа 1. Вкладка Avito не активировалась для обследования, поскольку командный переход не начался.

Первое неверное условие было в `core.js`:

```text
v0.2.0 требовала 12 специальных полей:
Цель, Режим, Категория, Город, Доставка, Поисковый запрос, Цена,
Обязательные условия, Желательные условия, Исключить,
Количество кандидатов, Действие.
```

Но фактический рабочий путь Business Bridge использует обычный assistant writing block с четырьмя человеческими разделами:

```text
Цель:
Рабочая область:
Изменения:
Проверка:
```

Поэтому форма, отображённая в ChatGPT, считалась недопустимой и была отброшена как `NO_NEW_VALID_COMMAND`. Предыдущие unit-тесты проверяли выдуманную 12-польную схему вместо реального формата Bridge и не имитировали writing block с локальной кнопкой Copy.

### Что изменено

- удалена 12-польная схема из read-only команды Avito Finder;
- теперь принимается только обычная четырёхраздельная форма `Цель / Рабочая область / Изменения / Проверка`;
- захват строится по той же наблюдаемой структуре, что и рабочий Bridge:
  - новый assistant turn после последнего user turn;
  - реальный writing block;
  - локальная кнопка `Копировать`, принадлежащая тому же writing block;
  - локальный click Copy;
  - извлечение текста только из этого writing block;
  - повторная проверка четырёх разделов после click;
- обычный assistant-текст без writing block теперь получает ясный отказ `LATEST_COMMAND_IS_NOT_WRITING_BLOCK`;
- ошибка формата возвращается как `WRITING_BLOCK_COMMAND_INVALID:<причина>`;
- лог успеха изменён на `WRITING_BLOCK_COMMAND_CAPTURED` и содержит `copy_confirmed` и `copy_source`;
- read-only режим остаётся единственным: команда должна одновременно просить обследование фильтров и явно запрещать ввод, изменение фильтров, поиск, открытие карточек и отправку сообщений.

### Что намеренно не изменялось

- поиск, ввод, установка фильтров, открытие карточек, сбор объявлений и доставка результата в чат не добавлялись;
- нет cookies, сетевых API Avito, контакта с продавцами, покупок или обхода ограничений;
- изоляция от Business Bridge сохраняется: код не импортируется и не разделяет storage, runtime, очередь или журнал; перенят только локальный наблюдаемый принцип выбора writing block и click Copy.

### Проверки

- `node --test` для четырёхраздельной формы, отсутствующих разделов, явного read-only запрета, старого 12-польного формата, последнего assistant turn после user turn и baseline turn;
- отдельные статические контракты для `section[data-turn]`, локальной кнопки Copy, отказа обычному assistant-тексту и отсутствия write/search handlers;
- Chromium DOM-fixture с ChatGPT-подобным `section[data-turn]`, assistant writing block, кнопками «Редактировать»/«Копировать» и проверкой фактического click Copy;
- `node --check` всех runtime JS-файлов;
- exact ZIP: `unzip -t`, повторный `node --test` и совпадение хэшей исходников и распакованного пакета.

### Статус живой проверки

Не пройдена. Требуется один живой запуск только с новой четырёхраздельной writing-block формой. Успехом будет считаться исключительно последовательность:

```text
WRITING_BLOCK_COMMAND_CAPTURED copy_confirmed=true
TAB_ACTIVATED role="avito_filter_scan"
AVITO_FILTER_SURFACE_CAPTURED
TAB_ACTIVATED role="chatgpt_return"
COMMAND_FILTER_INSPECTION_COMPLETE
```

### Условия приёмки v0.2.1

1. Popup перестаёт возвращать `NO_NEW_VALID_COMMAND` для новой четырёхраздельной writing-block формы.
2. Локальная кнопка Copy конкретного writing block нажимается ровно один раз.
3. Avito активируется только после успешного захвата формы.
4. После фильтр-снимка фокус возвращается в ChatGPT.
5. Не выполняются ввод, поиск, изменение фильтров, открытие карточек или отправка сообщений.
6. Статус и журнал показывают понятную точную причину при отсутствии writing block либо неверной форме.

### Последнее изменение

`v0.2.1`: v0.2.0 перестала ждать несуществующую 12-польную команду и использует только четырёхраздельный writing block с локальным Copy.


---

## 2026-06-24 — v0.2.1: проверка exact package

### Результат

- `node --test` на исходниках: **22/22 PASS**;
- `node --test` на файлах, извлечённых из exact ZIP: **22/22 PASS**;
- `node --check` пяти runtime JS-файлов exact ZIP: **5/5 PASS**;
- `unzip -t`: **PASS**;
- source и exact ZIP: **16/16 файлов совпадают по SHA-256**.

В набор входит отдельный DOM runtime harness, который исполняет реальный `chatgpt_content.js` против ChatGPT-подобной структуры с `section[data-turn]`, assistant writing block и локальными кнопками `Редактировать`/`Копировать`. Он подтвердил выбор формы, Copy только своего блока, защиту baseline и отказ после позднего user-turn.

### Ограничение

Headless Chromium в контейнере не выполнил fixture из-за внутренних crashpad/GPU ошибок процесса окружения. Это не считается ни успехом, ни дефектом пользовательского Chrome. Поэтому `v0.2.1` остаётся кандидатом до одного живого запуска в пользовательском браузере.

### Последнее изменение

Добавлены exact-package тесты и DOM runtime harness для реального `chatgpt_content.js`; живая приёмка всё ещё обязательна.

---

## 2026-06-24 — v0.2.2: контур turn-anchor Business Bridge, ожидание формы и честный отчёт отсутствия команды

### Фактический живой симптом v0.2.1

Пользователь установил `v0.2.1`, получил в popup:

```text
WAITING_FOR_COMMAND
NO_NEW_VALID_WRITING_BLOCK_COMMAND
```

При этом popup продолжал показывать прежний отчёт read-only обследования `af-20260624071156-nz0n`. Avito не переключался на обследование фильтров.

### Что было сделано неверно

`v0.2.1` заявляла использование механизма Bridge, но фактически делала одноразовый захват команды и возвращала общий отказ без доказательств структуры текущего ChatGPT DOM. Она также сохраняла `processed_command_turn_id` между версиями одного и того же storage-контракта и не очищала прежний отчёт перед новым запуском.

Это не позволяло отличить три разные причины: форма уже стала историей после нового user-turn, нет точного `section[data-turn][data-turn-id]`, либо у нового assistant turn отсутствует writing block / локальная Copy.

### Фактическая причина на уровне реализации

В рабочем Bridge кандидат строится не из общего списка assistant-элементов, а по точной последовательности:

```text
section[data-turn][data-turn-id]
→ последний user turn
→ assistant turn после него
→ writing block
→ local Copy
```

В `v0.2.1` этот контур не был сохранён как единственный источник состояния ожидания. Одноразовый вызов возвращал `NO_NEW_VALID_WRITING_BLOCK_COMMAND`, а popup продолжал выводить старый успешный отчёт, что создавало ложную картину нового запуска.

### Что изменено в v0.2.2

- захват команды использует точный turn-contour `section[data-turn][data-turn-id]`, как у работающего Bridge;
- использован тот же структурный адаптер writing block: legacy explicit root или current local Edit+Copy toolbar; `[aria-live]` остаётся в тексте блока;
- кнопка popup теперь запускает ожидание команды до 90 секунд, а не единственный мгновенный scan;
- команда допускается только после последнего user turn и только один раз для своего `turnId`;
- при смене контракта захвата с `v0.2.1` на `v0.2.2` старый `processed_command_turn_id` не используется;
- при старте очищается прошлый отчёт обследования;
- при timeout/cancel/no candidate новый popup-отчёт содержит только структурные признаки: количество exact turn sections, наличие последнего user turn, assistant после него, writing block, local Copy и ошибки формы. Текст пользователя не выводится;
- `Стоп` отменяет ожидание в content script;
- Avito по-прежнему не активируется до успешного захвата формы.

### Что не добавлено

Не добавлены поиск, ввод, изменение фильтров, карточки, контакты с продавцами, автоматическая отправка в ChatGPT, cookies, сетевые API, скрытые запросы или общие части с Business Bridge.

### Почему прежние проверки не предотвратили дефект

`v0.2.1` тестировала happy path с одной готовой формой в fixture. Тестов не было для:

1. одноразового scan против ожидания формы;
2. устаревшего `processed_command_turn_id` после изменения формата/контракта;
3. очистки прошлого успешного отчёта до нового запуска;
4. пользовательского диагностического отчёта, который различает отсутствие assistant после последнего user и отсутствие writing block.

### Проверки v0.2.2

- Node unit и DOM harness: exact `section[data-turn][data-turn-id]`, четыре раздела, legacy/current toolbar, один local Copy, baseline rejection, поздний user-turn, структурный audit;
- static contract: только read-only handlers, отсутствие поиска/ввода/продавцов/cookies/network, exact Bridge turn contour, разрешённая инъекция только упакованных файлов;
- `node --check` runtime JavaScript;
- `unzip -t`, повторный `node --test` на exact ZIP и SHA-256 сравнение исходников с распакованным ZIP.

### Условия приёмки v0.2.2

1. После нажатия popup показывает новый статус ожидания и не показывает старый отчёт как результат нового запуска.
2. Если новая форма уже видна либо появляется в течение 90 секунд, extension фиксирует `WRITING_BLOCK_COMMAND_CAPTURED` с `copy_confirmed=true`.
3. Только после этого вкладка Avito становится активной, затем после read-only снимка обратно активируется ChatGPT.
4. Если захват не удался, новый отчёт называет точную структурную причину без текста user-сообщений.
5. Не выполняются ввод, фильтры, поиск, карточки, продавцы или отправка сообщений.
6. Живая приёмка ещё не пройдена. `v0.2.2` — кандидат, не финальная сборка.

### Последнее изменение

`v0.2.2`: заменён одноразовый захват на stateful ожидание новой Bridge-совместимой writing-block формы, добавлены контрактная миграция состояния и честный диагностический отчёт.

---

## 2026-06-24 — v0.2.3: anchor-first захват copy-only writing block и живой журнал

### Фактическая причина поломки v0.2.2

Живой скриншот `v0.2.2` показал writing-block форму с локальной иконкой Copy и Expand, но без видимой кнопки Edit. При этом `currentWritingBlockBinding(...)` в `chatgpt_content.js` принимала current toolbar только при одновременном наличии **Edit + Copy** в одном ancestor. Поэтому доступная форма не становилась writing block для захвата.

Вторая поломка наблюдаемости: `popup.js` ожидал завершения долгого `AF_START_COMMAND_FILTER_INSPECTION` вызова и не подписывался на `chrome.storage.onChanged`. Логи лежали ниже «Последний отчёт» и во время ожидания не обновлялись в popup. Пользователь не мог увидеть, на каком структурном условии остановилась цепочка.

Третья архитектурная ошибка: команда выбиралась как assistant после **текущего последнего** user-turn. Любое новое пользовательское сообщение во время ожидания делало прежнюю форму невыбираемой без явной диагностики anchor/ручного прерывания.

### Что изменено

- Перед ожиданием Worker запрашивает и сохраняет точный последний user-turn как `command_anchor_turn_id`.
- Content script ищет только assistant-поворот после этого anchor, а не после меняющегося «последнего user».
- При появлении следующего user-turn до завершения командного захвата результат становится явным `MANUAL_USER_TURN_AFTER_ANCHOR`, а не бесконечным молчаливым ожиданием.
- Сохранён Bridge-путь `Edit + Copy`; добавлен ограниченный путь `Copy-only` только для текущего локального блока, если его собственный очищенный текст уже проходит полную проверку четырёх разделов read-only формы.
- Generic turn-wide `copy-turn-action-button` и «Copy response / Копировать ответ» по-прежнему исключены.
- Локальная Copy нажимается не более одного раза для конкретной кнопки.
- В popup блок «Живой журнал» перенесён выше отчёта.
- Popup подписан на `chrome.storage.onChanged`, поэтому статус, audit и журнал обновляются во время ожидания без ручного refresh.
- Content script отправляет в Worker обезличенный структурный audit только при изменении состояния: anchor, assistant id, наличие writing block, источник, local Copy, валидность формы и код ошибки. Текст user-сообщений не передаётся в лог.

### Что не менялось

- Поиск, ввод, изменение фильтров, открытие карточек, работа с продавцами и отправка сообщений отсутствуют.
- Не добавлены cookies, внешние API, скрытые запросы Avito, прокси, обход captcha или код Business Bridge.
- Вкладка Avito не активируется до успешного захвата команды.

### Проверки перед упаковкой

- unit-тесты формы и state;
- DOM harness для `Edit + Copy`, `Copy-only`, generic Copy rejection, anchor и manual interruption;
- static contract: изоляция, минимальные permissions, отсутствие write/search/network/seller handlers, отсутствие dynamic JavaScript execution;
- `node --check` всех JS runtime-файлов;
- `unzip -t`, tests и хэши exact ZIP.

### Статус живой проверки

**Не пройдена.** Это кандидат для одной узкой живой приёмки read-only команды. Он не является готовым поисковым расширением и не должен быть объявлен работающим до фактического результата: захват новой формы → видимая активация Avito → read-only фильтры → возврат в ChatGPT.

### Условия приёмки v0.2.3

1. После нажатия popup сразу показывает `COMMAND_WATCH_STARTED` и текущий audit в видимом «Живом журнале».
2. Новая форма с локальной Copy без Edit захватывается строго после заякоренного user-turn.
3. Нажимается только локальная Copy конкретного writing block; generic assistant-turn Copy не нажимается.
4. При ручном user-turn после anchor popup показывает `MANUAL_USER_TURN_AFTER_ANCHOR` и Avito не активируется.
5. При успехе наблюдается порядок вкладок ChatGPT → Avito → ChatGPT.
6. Поиск, ввод и изменения на Avito отсутствуют.

### Последнее изменение

`v0.2.3`: устранён ложный обязательный Edit-gate для copy-only writing block, введён точный anchor user-turn и сделан видимым живой структурный журнал.

### Упаковка и доказательства v0.2.3

Точный runtime ZIP содержит только девять runtime-файлов: `manifest.json`, `core.js`, `service_worker.js`, `chatgpt_content.js`, `avito_content.js`, `popup.html`, `popup.js`, `popup.css`, `README.md`.

Перед выдачей выполнены:

- `node --check` для пяти runtime JS-файлов;
- 32/32 Node.js тестов на исходниках;
- 32/32 тех же Node.js тестов на runtime, извлечённом из exact ZIP;
- `unzip -t` exact ZIP;
- SHA-256 сравнение девяти исходных runtime-файлов с извлечёнными из exact ZIP: расхождений нет.

Отдельно была начата контролируемая Chromium/Playwright fixture-проверка с локальными HTTPS страницами, отображёнными на разрешённые hostnames ChatGPT и Avito. В данном sandbox Chromium с загруженным extension не открыл доступный DevTools endpoint, поэтому полный browser E2E не получен. Это не трактуется как доказательство или как поломка пользователя: живая проверка в пользовательском Chrome остаётся обязательной.

---

## v0.2.4 — 2026-06-24 — прямой перенос порядка захвата формы из Business Bridge

### Что изменено

В Avito Finder удалён самостоятельный путь `current_local_copy_only_form`, выбор первого assistant-turn и проверка смысла read-only команды во время поиска блока. Вместо этого в отдельный код Avito Finder перенесён порядок рабочего Business Bridge:

1. `turnSections()` берёт точные `section[data-turn][data-turn-id]` без фильтра видимости.
2. `assistantCandidateAfterAnchor()` собирает **все** assistant-turn после точного anchor user-turn и до первого следующего user-turn.
3. Выбирается строго последний assistant-turn: `assistants[assistants.length - 1]`.
4. В выбранном turn ищется только Bridge-совместимый writing block: legacy explicit root либо current local toolbar с Edit + local Copy.
5. Проверяется readiness Copy и структурная подпись блока.
6. Состояние ждёт две секунды неизменности DOM-структуры.
7. Только после этого выполняется локальное подтверждение Copy и извлекается текст.
8. Проверка, подходит ли текст для текущего read-only этапа, перенесена после структурного захвата — в `validateReadOnlyFilterInspectionCommand()` Service Worker.

### Почему это устраняет наблюдавшуюся поломку

В живом журнале v0.2.3 был выбран ранний assistant `request-...-4` с `legacy_explicit_root`; он не содержал четырёх разделов. Поэтому v0.2.3 возвращал `MISSING_LABELS`. Новый порядок не фиксируется на первом assistant-turn: при последовательности `anchor → a-old → a-latest` выбирается `a-latest`.

### Источник переноса

Рабочий порядок перенесён из предоставленного архива Business Bridge, файл `content_script.js`, функции: `turnSections`, `legacyWritingBlockElement`, `currentWritingBlockBinding`, `resolveWritingBlockBinding`, `sectionWritingBlockText`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `assistantCandidateAfterAnchor` и стабильность `PROMPT_STABILITY_MS = 2000`.

### Проверка

- unit-проверка: ранний invalid legacy block + поздний valid block → выбран только поздний;
- unit-проверка: последний assistant и счётчик assistant-turn;
- unit-проверка: current local toolbar нажимает локальную Copy ровно один раз;
- unit-проверка: следующий user-turn останавливает захват до Copy;
- unit-проверка: обязательное окно стабильности DOM 2 секунды;
- Chromium fixture: подготовлена для реального DOM с `a-old` и `a-latest`; запуск в sandbox завис на старте Chromium и не засчитан как проверка;
- exact ZIP: тесты и хэши повторяются после распаковки.

### Статус живой проверки

Не пройдена на реальной вкладке пользователя на момент выпуска. Node DOM harness прошёл, но Chromium fixture в sandbox не завершилась; версия является кандидатом только для одной live-проверки захвата формы. На этом этапе по-прежнему запрещены ввод текста в Avito, изменение фильтров, поиск, открытие объявлений и отправка сообщений.

---

## v0.2.5 — 2026-06-24 — full Bridge start-exact anchor transport

### What changed

`v0.2.5` replaces the failed passive “use the current last user turn as anchor” path with the complete working order used by Business Bridge, while keeping Avito Finder isolated:

1. The user presses **«Запустить цикл и фильтры»**.
2. The extension activates the ChatGPT tab.
3. Through the confirmed persistent lower ChatGPT composer only, it stages and sends one ordinary human start message: `Avito Finder запущен…`.
4. It records the set of user turns before the click, waits for a **new user turn whose text matches that exact start message**, and uses only this turn as `start_exact` anchor.
5. It waits only for assistant turns after that anchor and before another user turn.
6. It selects the latest assistant turn, uses the copied Bridge local writing-block binding/Copy/stability order, then reads the selected block.
7. Only after structural capture and local Copy does it parse the four human sections.
8. It activates Avito, performs only filter-surface inspection, then activates ChatGPT again.

### Cause addressed

Previous versions `v0.2.0`–`v0.2.4` used an already present last user turn as anchor. That allowed an unrelated assistant response or legacy block after that old turn to be treated as the candidate. The live logs showed `legacy_explicit_root` with `MISSING_LABELS`; this was a consequence of using the wrong anchor, not evidence that the expected form was absent.

### Boundaries retained

- Separate extension project, manifest, storage (`avito_finder.*`), worker, popup, logs, docs and release files; no Business Bridge storage, runtime, queue, task IDs or reports are used.
- The only newly automated mutation is the explicitly user-started ordinary ChatGPT start message. The extension refuses to overwrite any different existing composer draft.
- No Avito text entry, filter changes, search, listing opening, seller contact, account changes, cookies, network APIs, captcha handling, proxies or bypasses.
- No retry click after a send whose composer-clear outcome is not confirmed.

### Validation and evidence

- `node --test tests/*.test.js`: 15/15 passed on source.
- Added emulated end-to-end transport test: ordinary start message → exact new user anchor → later response writing block → two-second stability → command capture.
- Added draft-protection test: a non-empty unrelated composer draft produces `START_PRIMARY_COMPOSER_OCCUPIED` and no send click.
- Static checks cover source isolation, no network/seller paths, exact `start_exact` order, form parsing after Copy, and absence of Bridge protocol markers in the outgoing start message.
- Exact ZIP validation is recorded in the release validation report.

### Live verification status

Not yet verified in the user’s real ChatGPT and Avito tabs. This is a candidate for one controlled live command-cycle test. It must not be described as live-proven until the popup reports a captured command and the actual sequence `ChatGPT → Avito → ChatGPT` is visible.

---

## Append — v0.3.0 — reset to the approved ТЗ command contract

**Date:** 2026-06-24  
**Status:** candidate; not a final release.  
**Append-only rule:** this entry is added after all prior text. Previous entries are not rewritten.

### What changed

v0.3.0 removes the non-ТЗ `START_EXACT_ANCHOR` path that tried to insert a start message into ChatGPT. The extension now follows section 5.1 of the approved ТЗ directly:

1. it reads the current ChatGPT conversation only;
2. it finds the last ordinary user turn;
3. it examines assistant writing blocks after that turn;
4. it ignores invalid/old/partial writing blocks instead of terminating on the first one;
5. it selects the latest complete valid Avito Finder command whose `turnId` has not already been processed;
6. it confirms the selected local Copy control once when present, without using the system clipboard;
7. only `INSPECT_FILTERS` continues to a read-only Avito surface inspection.

The command contract is now exactly the approved 12-label form:

`Цель`, `Режим`, `Категория`, `Город`, `Доставка`, `Поисковый запрос`, `Цена`, `Обязательные условия`, `Желательные условия`, `Исключить`, `Количество кандидатов`, `Действие`.

No automatic ChatGPT start message is created. No user composer text is written. No Bridge runtime code, storage keys, worker, queue, logs, or task protocol is used.

### Implementation failure being corrected

Earlier candidates `v0.2.1`–`v0.2.5` deviated from the approved ТЗ by imposing a four-label form, treating the first invalid writing block as terminal, and then adding a non-ТЗ automatic start-message/anchor cycle. In the observed live log this produced `MISSING_LABELS` for an unrelated assistant block and later an indefinite `SENDING_START_COMMAND` state.

### Root cause

The implementation treated an internal capture idea as the product contract. The actual product contract requires the latest valid assistant form after the latest user turn; it does not require the extension to generate a new user turn. It also defines twelve command labels, not four.

### Why earlier checks missed it

The prior test fixtures were aligned to invented intermediate contracts rather than the approved command template and the observed failure sequence "invalid writing block → later valid form". They therefore could pass while violating the ТЗ.

### Corrective tests in v0.3.0

- Node tests verify the complete twelve-label command, reject the obsolete four-label form, reject BBI/result/JSON markers, reject unsupported mode and a candidate limit above 30, verify minimal permissions, and verify that the automatic-start path is absent.
- A real Chromium DOM regression uses the exact packaged content-script files in a Chromium DOM fixture. It starts with an older command, then the current user turn, then an invalid assistant writing block, and finally appends a valid form. The script proves that only the valid latest form is captured, only its local Copy is clicked, and the Avito read-only inspection does not modify inputs or click buttons.

### Known limits and live-verification status

- **Implemented:** command capture and `INSPECT_FILTERS` read-only surface capture.
- **Not implemented:** `SEARCH` filter application/card collection (ТЗ stage 5); report insertion/send confirmation (ТЗ stage 6); end-to-end live validation in the user’s actual Chrome/ChatGPT/Avito DOM.
- The Chromium regression is not a substitute for the mandatory live Chrome acceptance required by the ТЗ. The build is therefore a **candidate**, not a release-ready extension.

---

## Append — v0.3.0 validation finalization — 2026-06-24

**Status:** candidate only; live Chrome acceptance is still not complete.  
**Append-only rule:** this entry adds evidence only; earlier text remains unchanged.

### Final packaged build and checks

The production archive contains only these runtime files: `manifest.json`, `core.js`, `chatgpt_content.js`, `avito_content.js`, `service_worker.js`, `popup.html`, `popup.css`, `popup.js`, and `README.md`.

The command parser additionally rejects non-numeric candidate limits such as `1 объявление`; the allowed range remains exactly `1..30` under the ТЗ.

The following checks were repeated against the **exact extracted ZIP**:

- `unzip -t`: passed;
- `node --check` for every runtime JavaScript file: passed;
- `node --test`: 5/5 passed;
- real Chromium DOM regression using the exact packaged content-script files: passed;
- SHA-256 comparison of all nine runtime files between source and extracted ZIP: all equal;
- forbidden runtime capability scan: no cookies, `webRequest`, proxy, fetch/XHR, seller-contact, start-message, or Business Bridge runtime identifiers.

### What this evidence does and does not prove

It proves the packed read-only stage can parse the approved twelve-label `INSPECT_FILTERS` form in a controlled Chromium DOM, ignore earlier invalid blocks, select the later valid block, click only that block's local Copy once, and inspect an Avito-like DOM without typing or clicking its controls.

It does **not** prove live behavior on the user's actual ChatGPT or Avito DOM. The sandbox blocks real-site and localhost browser navigation, so the required live user-Chrome acceptance remains outstanding. `SEARCH`, listing collection, and report delivery to the ChatGPT composer remain unimplemented stages and are not represented as working.

---

## Append — v0.4.0 — Bridge exact start / anchor / local Copy isolation

**Date:** 2026-06-24  
**Status:** test candidate only; not live accepted or release-ready.  
**Append-only rule:** this entry is appended after all prior history. Earlier text is unchanged.

### Why this entry exists

The user rejected the prior passive command-capture contract. The required interaction is now explicit:

`Начать → ChatGPT receives exactly «Ищи» → exact new user-turn is the anchor → next assistant writing block → structural stability → local Copy → complete text → only then local Avito Finder validation`.

### v0.4.0 behavior

1. The user clicks **Начать** in the isolated Avito Finder popup.
2. The extension activates ChatGPT in the current window.
3. Its separate ChatGPT adapter stages the literal ordinary message `Ищи` only in the persistent lower composer. A non-empty different user draft produces `START_PRIMARY_COMPOSER_OCCUPIED`; no text is replaced.
4. The adapter waits for the new user turn that text-matches `Ищи`. A different new user turn is not accepted as the anchor.
5. After that exact anchor, the adapter follows the copied Bridge capture ordering: assistant turn → local writing block → Copy readiness → two seconds unchanged DOM structure → local Copy click → body text from the same local root.
6. The ChatGPT adapter does not parse or validate Avito command labels. It transfers the full text and metadata to the isolated Avito Finder service worker.
7. Only the service worker parses the 12 labels from the ТЗ. Invalid text becomes `COMMAND_INVALID_AFTER_FULL_COPY`; Avito remains untouched.
8. A valid `INSPECT_FILTERS` command activates Avito only then and performs the existing read-only DOM inspection. `SEARCH`, card collection and report sending remain unimplemented.

### Exact-source boundary

The capture code is adapted from the exact nested Business Bridge `v1.8.34.5` archive. `BACKUP_AND_TRANSFER_GATE_v0.4.0.md` maps each transferred function and identifies only the required substitutions. The Avito Finder build has separate names, separate storage keys, separate worker, separate logs and no Bridge runtime import or Bridge task/queue/server calls.

### Tests and evidence

- syntax checks passed for all runtime JavaScript;
- Node tests passed: command parser, timing/order presence, full-text-before-validation boundary, isolation/permissions scan;
- Chromium DOM regression passed using the exact packaged runtime files: Start → `Ищи` → foreign user turn rejected → matching user anchor → assistant local writing block → two-second stability → one local Copy → full payload event;
- exact packaged ZIP validation and hashes are recorded in the v0.4.0 validation report and evidence archive.

### Live verification status

Not completed. The Chromium regression is a controlled fixture, not evidence from the user's actual ChatGPT or Avito tabs. The build must be called a **test candidate**, not a working release, until the live chain reaches at least `FULL_WRITING_BLOCK_TEXT_CAPTURED` and then `INSPECTION_COMPLETE` in the user's Chrome.

---

## Append — v0.4.1 — complete Bridge v1.8.34.5 capture-body transplant

**Date:** 2026-06-24  
**Status:** test candidate only; not live accepted and not release-ready.  
**Append-only rule:** This text is appended. Earlier entries are unchanged.

### Trigger and rollback boundary

The user rejected `v0.4.0` after a live test showed `WAITING_FOR_BRIDGE_EXACT_ANCHOR`, no `Ищи` user-turn, and an empty popup journal. The defect was not treated as a selector tweak. The v0.4.0 candidate is not patched for use. The rollback baseline remains the last live-confirmed Avito Finder read-only build v0.1.1; uninstalling the v0.4.x candidate and loading v0.1.1 returns to that baseline.

### Exact source used

The source is the nested exact Business Bridge archive `v1.8.34.5` and its `content_script.js` with SHA-256:

`6ea6a8a0b6961ff4c88b6b8e9c3096fbc82fad8bf4075d1b66aa040e19c12f20`

The v0.4.1 destination `chatgpt_content.js` contains all 118 source function names. The following capture functions are byte-identical to the exact source: `turnSections`, `userTurnIds`, `sectionUserText`, `resolveWritingBlockBinding`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `stageAutomationStartMessage`, `waitForNewUserAnchor`, `assistantCandidateAfterAnchor`, `sendMessageAndCaptureAnchor`, and `startPromptObserver`.

`promptTick` is byte-identical through detection, structural stability, local Copy and complete payload transfer. Its post-copy accepted branch stops the capture and hands the already obtained full text to the separate Avito Finder worker rather than starting Business Bridge task polling.

### Deliberate, bounded differences from Bridge

Only these boundary changes are made:

1. Runtime identity/version, overlay IDs, and composer staging attributes are Avito Finder identifiers (`data-avito-finder-*`).
2. `request()` routes the four capture-local events to an Avito Finder worker: local send-profile lookup, diagnostics, activity, and completed full-text payload. It does not call a Bridge server, queue or storage.
3. The external content message adapter exposes only Avito Finder messages. Its start handler preserves Bridge ordering: stage lower composer → exact 2000 ms render wait → resolve Send → one click → composer-clear confirmation → exact new `Ищи` user-turn anchor.
4. After full local Copy, the Avito Finder worker performs the 12-field command parse locally. No field/header/mode validation occurs in the ChatGPT content adapter before complete text transfer.
5. Business Bridge page reconciliation, queue polling, report delivery, attachments, Inspector interfaces, and shared storage are not started because they are outside Avito Finder.

### Popup correction

The popup no longer replaces log entries with `[]` after Start. It refreshes from `chrome.storage.local` on storage changes and once per second while open. A start operation returns only after the content adapter’s exact anchor handler completes or returns a concrete failure.

### Tests and evidence

- JavaScript syntax validation passed for every runtime file.
- Node tests passed: 6/6.
- Source inventory found 118 Bridge source functions and 118 destination functions; no source function is missing.
- The critical capture functions above have equal SHA-256 function bodies.
- Exact packaged ZIP integrity, extracted-JS syntax and source/extracted runtime SHA-256 equality passed.
- Chromium fixture navigation is blocked by this container policy with `net::ERR_BLOCKED_BY_ADMINISTRATOR`, including a local fixture URL. No claim of a live or Chromium DOM acceptance is made from this result.

### Live verification status and next road-map step

The confirmed project state remains **roadmap stage 3 not closed**. The next unclosed step is one live Chrome proof of:

`Начать → нижний composer receives exactly Ищи → exact new user-turn anchor → assistant writing block → 2 s stable local Copy → full text reaches local Avito Finder worker → only then local validation`.

Only after that proof may stage 4 activate Avito and perform the read-only filter inspection. `SEARCH`, candidate collection, and ChatGPT report delivery remain unimplemented.


---

## Append — v0.4.2 — strict active-dialog binding

**Date:** 2026-06-24  
**Status:** test candidate only; live Chrome acceptance is not complete.  
**Append-only rule:** this entry is added after earlier history without rewriting it.

### Trigger

The live v0.4.1 test sent `Ищи` into a different ChatGPT conversation in the same browser window. The source cause was `findInWindow("chatgpt", window.id)`, which selected the first matching ChatGPT tab instead of the active tab where the operator opened the popup.

### Corrected boundary

At Start, Avito Finder now uses the same entry selection rule as Bridge: `chrome.tabs.query({ active: true, lastFocusedWindow: true })`. It rejects a non-ChatGPT active tab and does not search for any other ChatGPT tab. Before `Ищи`, it captures and persists the exact context: `tabId`, `windowId`, `origin`, `chat_path`, and `conversationId`.

Every later ChatGPT operation verifies the stored context before acting: start dispatch, prompt-poll start, full text admission, stop, and return after Avito inspection. A missing tab, changed URL, changed conversation, different tab, or different window becomes `BLOCKED_CONVERSATION_CONTEXT_CHANGED`; there is no fallback search for another conversation.

The content adapter also verifies the expected identity before staging `Ищи`, after staging it, after the exact user-turn anchor, before prompt polling, while prompt polling, and on Stop. Thus the adapter cannot scan or Copy a writing block from a dialog reached by navigation after Start.

### Tests and evidence

- unit tests check exact URL conversation identity and reject a different tab, window or conversation ID;
- source contract test checks `active:true + lastFocusedWindow:true`, absence of a ChatGPT `findInWindow` fallback, strict expected identity in Start and prompt polling, and blocked-context events;
- exact ZIP checks are recorded in the validation report.

### Live status

Not live accepted. Required proof: launch in a dialog A while a different ChatGPT dialog B remains open in the same window; `Ищи` must appear only in A. Then navigate A to another dialog before the assistant form appears; the popup must show `BLOCKED_CONVERSATION_CONTEXT_CHANGED`, with no local Copy and no Avito activation.
---

## Append — v0.4.3 — Avito page-ready gate after live stage-4 evidence

**Date:** 2026-06-24  
**Status:** test candidate only; live stage-4 proof still required.  
**Append-only rule:** this entry is appended without changing earlier history.

### Live evidence that changed the plan

A v0.4.2 live run proved the ChatGPT side of the current path in the pinned conversation: `Ищи` was sent, the exact user anchor was captured, an assistant writing block became copy-ready, local Copy produced the full text, and the worker validated the full text as `INSPECT_FILTERS`.

The next event created an Avito tab with `url=null`. The worker then attempted the Avito content request immediately, which was correctly rejected as `CONTENT_TARGET_URL_REJECTED:avito`. No Avito filter was changed and no search was started.

### v0.4.3 scope

The v0.4.3 worker adds a page-ready gate only for the stage-4 Avito transition:

1. create or locate an Avito tab in the original window;
2. if the returned tab is early (`url=null`, loading, or otherwise not ready), log `AVITO_NAVIGATION_WAIT_STARTED` and wait for the same `tabId` and `windowId`;
3. accept readiness only when `tab.url` is an allowed Avito origin and `tab.status === "complete"`;
4. activate the ready tab, recheck it once more, then and only then inject/message `avito_content.js`;
5. Stop cancels a pending ready wait; a timeout/closed/moved tab becomes `BLOCKED_AVITO_PAGE_READY` with evidence.

`pendingUrl` is log-only. It is not sufficient to contact the page. The change contains no filter entry, no search, no listing collection, no seller action, and no ChatGPT report delivery.

### Tests and live status

A VM worker test simulates Chrome returning `url=null` and `status=loading` from `tabs.create`, then emitting `tabs.onUpdated` with an Avito URL and `status=complete`. The test asserts that `AF_INSPECT_AVITO_DOM` is sent only after the update. Exact ZIP checks are required before any test candidate is provided.

The current confirmed state is: the ChatGPT full-text capture path has one successful live proof; stage 4 remains unclosed until a real Avito tab reaches `AVITO_PAGE_READY`, the read-only snapshot is returned, and no filter/search mutation is observed.

---

## Append — v0.5.0 — bounded DOM diagnostic dialogue and same-chat report return

**Date:** 2026-06-24  
**Status:** test candidate; diagnostic live acceptance still required.  
**Append-only rule:** this entry is added after earlier history without changing it.

### New approved interaction

A separate `DIAGNOSE_DOM` command mode is added for public Avito pages and explicitly named page areas. The command is received only after the existing exact chat sequence:

`Начать → «Ищи» → exact user-turn → assistant writing block → local Copy → full text → local worker validation`.

Only after the full text is received does the worker parse `Действие` for two ordinary text lines:

```text
Страница: https://www.avito.ru/...
Область: PAGE_MAIN_VISIBLE | SEARCH_SURFACE_VISIBLE | DIALOG_VISIBLE | LISTING_CARD_VISIBLE | REVIEWS_VISIBLE
```

The extension activates the requested public Avito page in the same Chrome window, waits for the same tab to have an allowed Avito URL and `status=complete`, then captures only the requested visible scope. It returns the bounded report to the same pinned ChatGPT conversation with the transferred lower-composer / Send / confirmed-user-turn sequence.

### Data boundary

The diagnostic snapshot contains only the selected visible public DOM area: a bounded tree, visible control metadata, and sanitized limited HTML. It excludes the full ChatGPT page, composer draft, cookies, storage, credentials, network traffic, hidden API responses, input values, and unbounded full-page HTML. The report is limited in size.

The diagnostic capture performs no Avito input, filter changes, search, listing opening, seller contact, account change, payment, proxy, captcha handling, or network request.

### Changed behavior on UI drift

A requested area that cannot be uniquely located produces `BLOCKED_SCOPE_UNRESOLVED` and a short evidence report. It does not guess a selector or click a similar element. The next action must be another diagnostic command chosen after the returned snapshot.

### Report delivery and pause

After capture, the report is addressed only to the pinned ChatGPT `tabId + windowId + origin + chat_path + conversationId`. If the lower composer contains a user draft, the extension does not modify it and records `PAUSED_USER_COMPOSER_OCCUPIED`; the popup offers `Продолжить отчёт`. No fallback to another ChatGPT tab exists.

### Tests and current status

Tests cover diagnostic command parsing, the Avito page-ready gate, bounded snapshot request, report delivery only to the pinned chat, and busy-composer pause. Exact ZIP checks are required. Live Chrome proof of `DIAGNOSE_DOM → report in the same chat` remains mandatory before release status.


---

## Append — v0.5.1 — свободный локальный валидатор и возврат ошибки в закреплённый чат

**Изменение.** После local Copy расширение передаёт полный текст writing block только в локальный скриптовый разбор. Отсутствие старых 12 подписей само по себе больше не является ошибкой: режим, публичный адрес Avito и область диагностики определяются из всего полученного текста. Для `DIAGNOSE_DOM` и `INSPECT_FILTERS` число кандидатов не применяется; `0` не блокирует диагностику. Ограничение 1–30 применяется только к `SEARCH`.

**Ошибка прежней реализации.** `core.js` требовал все 12 полей и проверял `Количество кандидатов >= 1` до ветки режима. Поэтому собственная диагностическая команда с `Количество кандидатов: 0` была отклонена после успешного полного local Copy. Кроме того, ошибка оставалась в popup как пауза и не возвращалась в закреплённый ChatGPT-чат.

**Фактическая причина.** Общая форма и общий числовой ограничитель были ошибочно использованы как универсальный контракт. Это противоречило требованию: расширение сначала забирает весь текст, валидирует его локально и при невозможности выполнить действие возвращает ошибку в тот же чат.

**Исправление.** Добавлен свободный режимный разбор полного текста. Ошибка локального валидатора формирует обычный отчёт, доставляемый через тот же закреплённый ChatGPT-контур; если composer занят, применяется существующая безопасная пауза и `Продолжить отчёт`. В отчёт не добавляется полный текст writing block — только fingerprint, определённый режим и коды причин.

**Проверки.** Нужны: exact ZIP, Node tests, live Chrome: свободная диагностическая команда, `Количество кандидатов: 0`, ошибка `MODE_UNRESOLVED` с доставкой в тот же чат. Live-acceptance на момент сборки не выполнена.


---

## Append — v0.5.2 — continuous same-chat dialogue after every delivered report

**Date:** 2026-06-24  
**Status:** test candidate; live continuous-cycle acceptance is required.  
**Append-only rule:** this section is appended; all prior text remains unchanged.

### Defect evidenced by the live run

The live run `af-20260624111020-64c8` completed a diagnostic report delivery into the pinned chat, but then stopped waiting for the next assistant writing block. The user had to issue another `Ищи`, which contradicts the approved Bridge-style interaction. The same log also showed a requested main-page snapshot becoming `LISTING_CARD_VISIBLE`: the local inference treated the safety phrase “не открывай объявления” as a target-scope hint.

### Corrected dialogue contract

`Начать` sends `Ищи` exactly once. Each subsequent cycle is: confirmed user turn carrying the prior result or error → next assistant writing block → local Copy of its full text → local script validation → one bounded local action → result/error returned to the same pinned chat → confirmed result/error user turn becomes the next anchor. The extension never waits for another `Ищи` between iterations. It does not decide the next diagnostic scope; it waits for the next assistant writing block. The cycle stops only on explicit Stop / остановка / стоп / хватит / завершить, or when ChatGPT intentionally emits no next writing block.

### Scope parsing correction

`DIAGNOSE_DOM` still accepts free text, but a diagnostic scope is no longer inferred from a prohibition. Explicit scope tokens/lines are preferred; otherwise a non-positive command defaults safely to `PAGE_MAIN_VISIBLE`. A request for a card, dialog, review area, or search surface must be explicit or positively worded.

### Recovery and safety

After report delivery the worker persists `WAITING_FOR_NEXT_ASSISTANT_FORM` with the report’s confirmed user-turn ID and immediately restarts the same pinned-dialog prompt watcher. If the ChatGPT content script reloads, it asks the worker only whether that durable wait can resume in the same pinned identity; no text is staged, reinserted, or resent. A mismatched tab/window/path/conversation blocks the run.

### Tests and live status

The candidate adds Node/VM tests for the report-to-next-form transition, validation-error continuation, exact continuation anchor, reload recovery contract, and prohibition-safe scope inference. Exact ZIP integrity, runtime hash equality, syntax checks, and Chromium fixture checks are required. The user’s actual Chrome must still prove at least two consecutive cycles without a second `Ищи` before this is considered live accepted.

---

## Append — v0.5.3 — anchor fence, current-Avito reuse and observable read-only timing

**Date:** 2026-06-24  
**Status:** test candidate only; not live accepted and not release-ready.  
**Append-only rule:** This entry is appended. Earlier history is unchanged.

### Live defect that triggered this change

The v0.5.2 user-Chrome run proved that a report could establish a next-form poll, but then exposed two separate failures:

1. a late local-Copy result from the previous assistant form could arrive after the Worker had already anchored the next poll; the older content-script callback could stop or interfere with the newer wait;
2. the next diagnostic text referred to an already-open Avito page without repeating an absolute URL, but the local parser required a URL and returned `DIAGNOSTIC_PAGE_REQUIRED` before any Avito action.

The live evidence also showed that the first Avito activation and DOM capture occurred too quickly to be observable by the operator.

### Scope of v0.5.3

- The normal Bridge-derived capture path remains: same pinned ChatGPT tab → one assistant writing block → local Copy → full text → Worker-side validation.
- The extension adds a **prompt-poll generation fence**. Every polling generation has an ID. A callback from an older generation may not stop, replace, or cancel a newer anchor wait. Late old candidates are reported as `STALE_FORM_CANDIDATE_IGNORED` and are ignored without blocking the pinned conversation.
- A natural-language `DIAGNOSE_DOM` instruction can explicitly say that it targets the already-open/current Avito page. The Worker then reuses only the run-owned `avito_tab_id`, after confirming that it is an allowed Avito URL in the pinned window. It does not guess another tab or page. When no durable Avito target exists, the action stops safely with `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE`.
- Diagnostic and read-only inspection actions now include visible production pauses: **2.5 seconds after Avito activation before capture**, and **2 seconds after capture before return to ChatGPT**. The live journal records `AVITO_VISIBLE_DELAY_STARTED` and `AVITO_VISIBLE_DELAY_COMPLETED`.
- `INSPECT_FILTERS` continues to use the public Avito root URL. The new no-URL reuse behavior applies only to an explicit diagnostic reference to the already-open/current Avito page.

### Safety boundary

No search typing, filter mutation, listing opening, seller contact, cookie/storage reading from website pages, proxy/captcha handling, hidden API/network calls, or Business Bridge runtime import was added. A stale form does not change tabs or Avito. A missing reuse target does not create or navigate a tab.

### Automated evidence

- JavaScript syntax checks passed for all runtime files.
- `node --test tests/*.test.mjs`: **31/31 passed**.
- New covered cases:
  - natural diagnostic text can reuse only the already-open Avito page;
  - a stale anchor candidate is ignored without blocking the newer same-chat poll;
  - two diagnostic forms after one Start reuse the durable Avito tab and produce two reports;
  - visible-delay start/end events are emitted for each Avito capture;
  - the code contains a generation fence that prevents an old accepted response from stopping a newer poll.
- Exact packaged ZIP and extracted source/tests ZIP must still be validated below before delivery.

### Live acceptance status

Not complete. The user must run the exact packaged build in Chrome and prove: second assistant form after a diagnostic report activates the existing Avito tab, emits the visible delay events, captures the requested scope, returns to the same chat, and starts the next wait without another `Ищи`.

### Package-validation addendum — v0.5.3

The exact runtime ZIP was built from an explicit allowlist of 9 runtime files. `unzip -t` passed for the runtime ZIP and source/tests ZIP. Both source and extracted source/tests ZIP ran `node --test tests/*.test.mjs` with **31 passed, 0 failed**. SHA-256 matched for every runtime file between the source tree and extracted runtime ZIP. A local Playwright/Chromium fixture attempt was run, but navigation to the fixture itself was blocked by `net::ERR_BLOCKED_BY_ADMINISTRATOR`; this is retained as a failed environment-evidence attempt and is not treated as live DOM proof.


---

## Append — v0.5.4 — explicit mode boundary, anchor handoff and bounded search surface

**Date:** 2026-06-24  
**Status:** test candidate; no live Chrome acceptance for this version.  
**Append-only rule:** this entry is appended without rewriting prior history.

### Live defect that triggered the change

The user-Chrome v0.5.2 run exposed two independent defects:

1. A copied diagnostic instruction contained the selector `input[data-marker="search-form/suggest/input"]`. The local parser scanned every token in the copied text, classified the form as `SEARCH` rather than `DIAGNOSE_DOM`, and raised `CITY_REQUIRED_FOR_SEARCH` before any second Avito activation.
2. After a local validation-error report became a new ChatGPT user-turn anchor, the next prompt wait could receive an older form callback. The old callback could interfere with the new wait in the older runtime.

The same live evidence also showed that `SEARCH_SURFACE_VISIBLE` previously selected the input itself rather than a bounded parent container with the surrounding search controls.

### v0.5.4 scope

- The mode is now read only from an explicit local command instruction: an exact `Режим:` field, a bare first instruction line, or a first-line prefix such as `DIAGNOSE_DOM.`. The Worker does not infer `SEARCH` by scanning selector strings, URLs, HTML, or arbitrary words inside the copied payload.
- The parser safely removes sentence-ending punctuation from an explicit public Avito URL. A diagnostic that explicitly says to use the already-open Avito page may reuse only the durable run-owned Avito tab.
- Every copied form has a local form key: current anchor + assistant turn + text fingerprint. Repeated delivery of the same form is ignored locally as `DUPLICATE_FORM_CANDIDATE_IGNORED`.
- A validation or unimplemented-action report returns an explicit `continuation_started` handoff. The previous content wait cannot stop a newer prompt-poll generation; the next confirmed report user-turn is the only next anchor.
- `SEARCH_SURFACE_VISIBLE` starts from the exact public search input and climbs visible parents. A root is accepted only if it includes the input, a category control, and the Find button. It never returns the input itself. If no bounded parent meets those facts, the response is `BLOCKED_SCOPE_UNRESOLVED` with up to eight parent candidates. It does not fall back to `body`.
- The public Avito navigation remains read-only. The existing 2.5-second post-activation and 2-second post-capture visible pauses remain in place.

### Reference boundary

The transferred ChatGPT capture functions `turnSections`, `userTurnIds`, `sectionUserText`, `resolveWritingBlockBinding`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `stageAutomationStartMessage`, `waitForNewUserAnchor`, `assistantCandidateAfterAnchor`, and `sendMessageAndCaptureAnchor` are checked byte-for-byte against the supplied Business Bridge v1.8.34.6 reference. The v0.5.4 changes are isolated to Avito Finder local parsing, Worker handoff state, bounded diagnostic scope selection, and version metadata.

### Tests and evidence

- `node --test tests/*.mjs`: 36 passed, 0 failed on source.
- The suite includes a regression where `DIAGNOSE_DOM` and `SEARCH_SURFACE_VISIBLE` coexist with `search-form/suggest/input`; the mode remains `DIAGNOSE_DOM`.
- The suite covers local duplicate-form suppression, explicit continuation handoff, durable same-run Avito reuse, visible delay logs, current-anchor-only admission, and page-ready gating.
- `node --check` is required for all runtime JavaScript files.
- Exact ZIP integrity and source/extracted runtime SHA-256 equality are required before sharing the candidate.
- Local Chromium remains blocked by this environment's administrator policy for file navigation; no live browser acceptance is claimed from container checks.

### Current confirmed state and next roadmap step

- Stage 3 remains live-proven: `Начать → Ищи → exact user anchor → writing block → local Copy → Worker-side validation`.
- Stage 4 transport remains live-proven: Avito tab activation, read-only snapshot, same-chat return, report delivery, and a next-form poll have occurred.
- The nearest unclosed step is a live v0.5.4 sequence in the pinned user Chrome: a diagnostic form containing the exact search-input selector must remain `DIAGNOSE_DOM`, visibly reuse the run-owned Avito tab, return a bounded search-surface snapshot or a bounded parent-candidate report, then continue to the next writing form without another `Ищи`.


---

## Append — v0.5.5 — bounded search-input ancestry evidence

**Date:** 2026-06-24  
**Status:** test candidate; live Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without modifying prior history.

### Live defect that triggered the change

The user-Chrome v0.5.4 diagnostic reached the exact public search input but returned `BLOCKED_SCOPE_UNRESOLVED` without the promised parent-candidate evidence. The requested search-surface action therefore could not progress safely: the extension knew a bounded root was not proven, but did not return enough structure for ChatGPT to choose the next read-only inspection.

### What changed

- The public `SEARCH_SURFACE_VISIBLE` resolver climbs up to 16 visible ancestors from `input[data-marker="search-form/suggest/input"]` and checks both visible controls and bounded visible container text for the category and Find controls. It never falls back to `body`, the input itself, a listing card, or a recommendation card.
- If no bounded common root is proven, the same-chat report now includes up to 16 **parent candidates** with depth, bounded public class/data-marker description, detected input/category/find/location features and visible public controls.
- `SEARCH_INPUT_ANCESTRY_VISIBLE` is a read-only diagnostic scope for returning that parent chain intentionally.
- `SEARCH_INPUT_PARENT_VISIBLE` with a locally validated `Глубина родителя: 1..16` returns one chosen ancestor as a bounded DOM/HTML snapshot. This permits ChatGPT to inspect the real interface iteratively rather than guessing selectors.
- The diagnostic report now renders `Кандидаты области` rather than hiding the scope-candidate data returned by the Avito content script.

### Safety and interaction

No typing, UI click, filter mutation, search execution, listing opening, seller contact, payment, hidden API/network call, cookie/page-storage read, proxy or captcha handling was added. The existing pinned-dialog and visible-tab transition contract remains unchanged.

### Tests and known limits

The candidate adds parser/report regressions and an intercepted-Avito Chromium DOM fixture that loads the packaged public content script on an `https://www.avito.ru/` origin without contacting Avito. Exact ZIP, source/extracted runtime equality and standard Node tests are required. This does not replace a live test in the user's Chrome; the package remains a test candidate until the actual pinned session proves the unresolved-parent report or a bounded search-surface snapshot and the next dialogue iteration.

---

## Append — v0.6.0 — Generic Visible-UI Action Engine

**Date:** 2026-06-24  
**Status:** test candidate; live user-Chrome acceptance is not yet complete.  
**Append-only rule:** this section is appended without modifying prior history.

### Why the architecture changed

The earlier diagnostic sequence added narrow handlers for individual Avito controls and scopes. That design was rejected because every new visible control or changed layout would require another extension build. The project now introduces one local, bounded generic action engine. It does not receive JavaScript, CSS selectors, hidden API instructions or a remote command channel from ChatGPT.

### Generic plan contract

A writing block may use `AVITO_UI` or an ordinary `Шаги:` / `Действия:` section. Local parsing recognizes only six generic visible actions:

1. `CLICK` — click one uniquely resolved visible public control;
2. `TYPE` — write bounded text into one uniquely resolved visible input/textarea/contenteditable control;
3. `WAIT` — bounded visible delay up to five seconds;
4. `WAIT_FOR` — wait up to five seconds for one uniquely resolved visible control;
5. `SNAPSHOT` — capture a bounded read-only DOM/HTML scope;
6. `COLLECT_LISTINGS` — collect up to 30 visible public listing records without opening listings.

Target resolution is local and generic: exact `data-marker`, exact placeholder, then exact visible text/aria-label/title. No selector from the writing block is executed. Missing, disabled, ambiguous or policy-blocked targets stop the current plan before that target is clicked or written.

### Safety and project boundary

The engine uses only the normal visible Avito UI in the run-owned tab. It visibly activates the tab, pauses before and after interactive steps, returns to the same pinned ChatGPT conversation and continues through the existing report-anchor cycle.

It blocks seller messaging, calls, purchase, payment, checkout, order, basket, booking and delivery-finalization targets. It does not use cookies, page storage, hidden API/network calls, proxy/captcha methods or arbitrary JavaScript. It does not import or share Business Bridge source, runtime, storage keys, logs, queue, service worker or archives.

### Business Bridge capture boundary

The copied ChatGPT capture adapter was not functionally edited. Compared to v0.5.6, its only changes are the `0.6.0` version identifiers. The ten Bridge-derived capture functions remain byte-identical to the supplied v1.8.34.6 reference and to v0.5.6: `turnSections`, `userTurnIds`, `sectionUserText`, `resolveWritingBlockBinding`, `detectCopyReadiness`, `confirmLocalWritingBlockCopyAndExtract`, `stageAutomationStartMessage`, `waitForNewUserAnchor`, `assistantCandidateAfterAnchor`, and `sendMessageAndCaptureAnchor`.

### Automated evidence

- `node --test tests/*.test.mjs`: 49 passed, 0 failed.
- Worker regression: generic `AVITO_UI` plan used the same pinned ChatGPT report delivery and next-anchor continuation as diagnostics.
- Chromium fixture: visible city control click → visible city input type → visible city choice click → search input type → Find click → public listing collection completed; duplicate visible label was blocked as `UI_TARGET_AMBIGUOUS` without either duplicate being clicked.
- Existing Chromium diagnostics passed for the public location dialog and bounded search ancestry.
- The historical Bridge exact-capture Chromium fixture could not navigate in this container because Chromium policy returned `ERR_BLOCKED_BY_ADMINISTRATOR`; this is not treated as live proof. The byte-identity and Node capture tests remain the evidence for the unchanged ChatGPT logic.

### Current confirmed state and next roadmap step

Stage 3 and Stage 4 remain live-proven from prior user-Chrome runs. The generic engine is package-tested but not yet live-accepted in the user Chrome profile. The nearest unclosed roadmap step is a live three-step plan in the pinned ChatGPT/Avito session: open the current public city control, type a city into the visible dialog, select one unambiguous city result, return the same-chat report, and continue to the next writing form without another `Ищи`.


---

## Append — v0.6.1 — Bridge HTML capture parity and generic-plan worker handoff

**Date:** 2026-06-25  
**Status:** test candidate; live user-Chrome acceptance is still required.  
**Append-only rule:** this section is appended without modifying prior history.

### Triggering live failure

The first user-Chrome v0.6.0 `AVITO_UI` form completed the exact ChatGPT side of the chain: `Ищи` was sent, the exact user anchor was captured, the assistant writing block was waited for, local Copy became ready, the complete copied payload was received, and local parsing accepted `AVITO_UI`. The next Worker transition stopped at `AVITO_TASK_BLOCKED: DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE`; there was no Avito tab activation after the accepted form.

### First divergence and five preceding transitions

- **First wrong object/action:** `ensureAvitoTarget(state, requestedUrl=null, purpose=avito_ui_action_plan)` reused the no-URL diagnostic policy and threw `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE` instead of applying generic-plan target policy.
- **T-5:** `FULL_WRITING_BLOCK_TEXT_RECEIVED` received the complete local Copy payload for the exact current assistant turn.
- **T-4:** `LOCAL_COMMAND_VALIDATION_COMPLETED` accepted `mode=AVITO_UI` from the first instruction line.
- **T-3:** `queueAvitoTask` derived `uiPlan.page_url = null` because the ordinary command correctly said “на закреплённой вкладке Avito” without forcing a URL.
- **T-2:** no durable `avito_tab_id` existed after the extension update.
- **T-1:** the Worker called the reuse-only diagnostic branch with no fallback target.

The error path also only saved `FAILED_WITH_EVIDENCE`; it did not return a same-chat failure report or create the next anchor, so the completed writing block was stranded behind a stopped prompt poll.

### What changed

- `AVITO_UI` now has a generic target policy independent from `DIAGNOSE_DOM` reuse-only behavior:
  1. use the run-owned Avito tab when it remains valid in the pinned window;
  2. otherwise reuse a visible Avito tab in that exact window;
  3. otherwise create only `https://www.avito.ru/` in that exact window.
- A no-URL diagnostic remains reuse-only and still safely returns `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE` rather than guessing a page.
- Every terminal Worker-side Avito target failure now becomes a normal same-chat `avito_failure` report. Its confirmed user turn becomes the next anchor before another prompt poll starts.
- The ten Bridge-derived collection/copy/anchor functions remain byte-identical to the supplied Bridge v1.8.34.6 reference. Avito Finder still has separate files, storage keys, service worker, logs and packaging; no Bridge runtime is imported or shared.

### HTML parity test against the Bridge reference

A Chromium fixture models the observed current ChatGPT DOM shape: current assistant turn, writing block, disabled Copy that becomes enabled, ordinary lower composer and an exact user-turn created by Send. The actual packaged Avito Finder adapter and the actual supplied Bridge v1.8.34.6 content script run independently on that same fixture. The test proves both adapters produce the same captured anchor, assistant turn, full writing-block payload, payload bytes, ready Copy state and exactly one local Copy click.

### Tests and evidence

- `node --test tests/*.test.mjs`: **51 passed, 0 failed**.
- Source and exact-package runs cover generic `AVITO_UI` after an extension update with no durable Avito tab id: public-root creation/reuse, page-ready gate, same-chat report handoff and next anchor.
- Source and exact-package runs cover a terminal tab-creation failure: no repeated click/type/navigation, same-chat failure report and next-anchor continuation.
- Chromium fixtures cover: exact ChatGPT Copy/anchor capture, direct Bridge-vs-Avito HTML parity, bounded search ancestry, public location dialog, generic click/type/click/type/click/listing collection, and ambiguous-target blocking before any click.
- Every packaged runtime JavaScript file passes `node --check`; exact package contents and source/extracted runtime SHA-256 values are compared.

### Current confirmed state and next roadmap step

- The user-Chrome trace proves current ChatGPT capture through full local Copy and Worker-side `AVITO_UI` validation.
- This candidate repairs the first Worker transition that prevented any Avito action after that capture.
- The nearest unclosed roadmap step is a live user-Chrome v0.6.1 run of the real request: Zлатоуст → “ноутбук” → price 10 000–15 000 ₽ → public listing collection → same-chat report and automatic next-form wait without a new `Ищи`.
---

## Append — 2026-06-25 — восстановление истории, статус базовой сборки и границы нового ТЗ

**Статус:** документация восстановлена по приложенным истории, архивам кандидатов и фактическому коду `AVITO_FINDER_v0.6.1_bridge-html-parity-worker-handoff_TEST_CANDIDATE.zip`.  
**Runtime-изменения:** не выполнялись.  
**Важно:** этот раздел добавлен без переписывания предыдущей истории.

### 1. Что использовано как доказательство

1. Полная линейка архивов кандидатов от `v0.1.0` до `v0.6.1`.
2. Предыдущая append-only история до `v0.6.1`.
3. Исходное ТЗ и roadmap `v0.1`.
4. Фактические runtime-файлы последнего кандидата: `manifest.json`, `core.js`, `service_worker.js`, `chatgpt_content.js`, `avito_content.js`, `popup.*`.
5. Сохранённый живой журнал v0.6.0, где доказано: ChatGPT-цепочка прошла до `FULL_WRITING_BLOCK_TEXT_RECEIVED` и `LOCAL_COMMAND_VALIDATION_COMPLETED mode=AVITO_UI`, а первый сбой возник уже в Worker на получении Avito-вкладки.

### 2. Восстановленная хронология

| Версия | Что пыталась сделать | Подтверждённый результат | Почему не стала рабочей основой |
|---|---|---|---|
| v0.1.0 | Read-only обследование вкладок ChatGPT и Avito. | Найдена реальная ошибка отсутствующего content script на уже открытых вкладках. | Не умела читать формы, работать с поиском или возвращать результат в чат. |
| v0.1.1 | Контролируемая инъекция собственных content scripts и read-only осмотр. | **Единственный ранний live-подтверждённый безопасный этап:** вкладки активировались, DOM обеих страниц был доступен, captcha/login не наблюдались. | Это только read-only база; поисковый сценарий отсутствует. |
| v0.2.0–v0.2.4 | Несколько попыток читать writing block и выбирать anchor. | Выявлены реальные дефекты: неправильный контракт формы, одноразовый scan вместо ожидания, устаревший processed id, выбор первого/старого assistant блока, Copy-only toolbar, слабый журнал. | Контракт формы и порядок захвата менялись до доказательства предыдущего шага. |
| v0.2.5 | Полная стартовая цепочка с искусственным стартовым user-turn. | Убрала захват старых assistant блоков до anchor. | Стартовое сообщение не соответствовало исходному ТЗ и стало ещё одним параллельным контрактом. |
| v0.3.0 | Возврат к ТЗ 12-польной команды. | Установлена ключевая причина: долгий watch на 90 секунд был отправлен через 5-секундный RPC timeout; кроме того, текст разбирался до Copy. | Не была доказана рабочая цепочка full Copy → local validation. |
| v0.4.0–v0.4.3 | Изолированный ChatGPT capture-path, активный диалог и page-ready gate. | В живом Chrome доказаны: `Ищи` → exact user anchor → writing block → local Copy → полный текст → локальная проверка; затем выявлена отправка `Ищи` не в тот диалог и исправлена строгая привязка tab/window/path/conversation. | Этап Avito ещё не был полноценно принят: сначала возник `url=null`, затем только page-ready gate. |
| v0.5.0–v0.5.5 | Диагностика DOM, same-chat возврат, непрерывный цикл, fence против устаревших callback, снимки поисковой поверхности. | Доказаны Avito activation, read-only snapshot, возврат в тот же чат и ожидание следующей form. | `INSPECT_FILTERS` в части сборки возвращал преимущественно счётчики, а не требуемую поверхность реальных фильтров; ряд диагностических переходов оставался кандидатами. |
| v0.6.0 | Универсальный local visible-UI engine вместо обработчика на каждый элемент. | В fixture доказаны generic CLICK/TYPE/WAIT/WAIT_FOR/SNAPSHOT/COLLECT_LISTINGS и блокирование неоднозначных целей. | В живом запуске после принятого `AVITO_UI` плана Worker ошибочно применил reuse-only политику DIAGNOSE_DOM, получил `DIAGNOSTIC_REUSE_TARGET_UNAVAILABLE` и остановился до активации Avito. |
| v0.6.1 | Исправление получения Avito target и same-chat failure handoff; Bridge HTML parity. | Пакетный кандидат: manifest `0.6.1`, Node/fixture/дифференциальные проверки заявлены в приложенных отчётах; фактический код действительно содержит fallback: durable run tab → Avito tab в том же окне → `https://www.avito.ru/`. | **Live-приёмка в пользовательском Chrome не выполнена.** Нельзя называть рабочим выпуском. |

### 3. Подтверждённые причины прошлых сбоев

1. **Нет единого контракта формы.** Между 12 полями ТЗ, четырьмя разделами Bridge и свободным текстом менялась не только проверка, но и сам продуктовый договор. Правильно: capture-путь получает полный текст конкретной form, а разбор режима выполняется только в local worker после Copy.
2. **Долгое ожидание было обрезано транспортным timeout.** В v0.3.0 запрос ожидания формы на 90 секунд шёл через 5-секундный RPC timeout, поэтому Worker считал content script зависшим до завершения watch.
3. **Copy был не каноническим источником текста.** В ранних версиях текст пытались очистить и распарсить из DOM до local Copy. Это ломало соответствие реальному тексту writing block.
4. **Диалог ChatGPT выбирался слишком широко.** Поиск первой вкладки ChatGPT в том же окне отправлял `Ищи` в другой разговор. Исправленная модель обязана хранить и проверять `tabId + windowId + origin + chat_path + conversationId` на каждом переходе.
5. **Этап `INSPECT_FILTERS` имитировал результат.** Счётчики inputs/buttons/links не являются наблюдаемым списком фильтров, поэтому не могут закрывать этап обследования UI.
6. **Цикл заканчивался после отчёта.** После первого same-chat report расширение требовало новый `Ищи`. Это противоречит требованию непрерывного watcher; подтверждённый report user-turn должен становиться anchor следующего poll.
7. **Старые callback вмешивались в новые ожидания.** Для этого нужен generation fence и form key `(anchor_turn_id, assistant_turn_id, text fingerprint)`.
8. **v0.6.0 смешал политику диагностики и обычного плана.** `AVITO_UI` с `page_url=null` ошибочно использовал no-URL diagnostic branch. v0.6.1 разделяет их.

### 4. Фактическое состояние v0.6.1 по коду

Архив содержит manifest `0.6.1` и только runtime-файлы расширения. В нём:

- `core.js` распознаёт `INSPECT_FILTERS`, `SEARCH`, `DIAGNOSE_DOM`, `AVITO_UI`.
- `chatgpt_content.js` содержит функции захвата, включая `confirmLocalWritingBlockCopyAndExtract`, `sendMessageAndCaptureAnchor`, `startPromptObserver`.
- `service_worker.js` содержит `ensureAvitoTarget`, `deliverReportToPinnedChat`, `queueAvitoTask`; для `AVITO_UI` используется policy: текущая run-owned Avito-вкладка → любая Avito-вкладка текущего окна → создание одной публичной root-вкладки.
- `avito_content.js` содержит ограниченный generic engine: `CLICK`, `TYPE`, `WAIT`, `WAIT_FOR`, `SNAPSHOT`, `COLLECT_LISTINGS`; цели разрешаются только локально по видимым public-признакам.
- В `service_worker.js` режим `SEARCH` **явно не реализован**: после успешного разбора он возвращает same-chat сообщение `SEARCH_NOT_IMPLEMENTED`, Avito не меняется.

Следовательно, утверждение «поиск через `SEARCH` уже работает» недостоверно. Пакет v0.6.1 может быть только технической базой для live-проверки `AVITO_UI`, а не готовым продуктовым релизом.

### 5. Решение о базах кода

- **Безопасный live-подтверждённый rollback baseline:** v0.1.1, только read-only обследование.
- **Техническая база для следующей диагностики и исправлений:** v0.6.1, но только как test candidate.
- **Эталон поведения ChatGPT-страницы:** предоставленный Business Bridge v1.8.34.6 capture adapter, используемый лишь как замороженный reference для parity/differential tests.
- **Запрещено:** подключать Bridge runtime, его storage, server API, очередь, журналы или task IDs.

### 6. Отменённые и запрещённые подходы

- не выпускать новый архив из предположений по отдельному элементу UI;
- не считать Node/ZIP/fixture тесты живой приёмкой;
- не объявлять `INSPECT_FILTERS` выполненным по одним счётчикам;
- не применять `SEARCH` до отдельной реализации, live доказательства и принятия;
- не выбирать любую вкладку ChatGPT или Avito по домену без сохранённой привязки;
- не разбирать/валидировать тело writing block до полного local Copy;
- не оставлять accepted form без same-chat failure report и следующего anchor;
- не добавлять новые режимы или ручные селекторы без изменений ТЗ и диагностического снимка.

### 7. Ближайший незакрытый шаг

Перед любым патчем и тем более перед поиском нужен **read-only live preflight в пользовательском Chrome** для фактически установленной версии:

1. зафиксировать extension version в popup/manifest и URL открытого ChatGPT-чата;
2. проверить, что content script и service worker принадлежат одной версии;
3. выполнить один старт `Ищи` в активном закреплённом чате;
4. доказать exact anchor → assistant form → local Copy → full text → Worker validation;
5. для `AVITO_UI` с отсутствующим durable `avito_tab_id` доказать реальную активацию или создание публичной вкладки Avito;
6. зафиксировать same-chat report и автоматический следующий poll.

Только после этого допустим контролируемый план: город Златоуст → запрос «ноутбук» → цена 10 000–15 000 ₽ → ограниченный сбор видимых карточек → отчёт → следующий poll.

---

## Append — v0.6.2 — continuation anchor generation fence after validation-error report

**Date:** 2026-06-25  
**Status:** test candidate; a real user-Chrome run is still required.  
**Append-only rule:** this section is appended without changing earlier history.

### Triggering live trace

The user-Chrome task `af-20260625083716-3x08` proved that report delivery itself still worked after a local validation failure:

1. the old assistant writing block was copied completely;
2. local validation returned `UI_PLAN_TYPE_TARGET_OR_TEXT_REQUIRED` and `UI_PLAN_PAGE_REQUIRED` before any Avito action;
3. the validation-error report was delivered to the pinned ChatGPT chat and confirmed by a new user-turn;
4. the Worker requested and logged the next prompt poll for that new user-turn;
5. an old `PROMPT_WORKER_CONTINUATION_HANDOFF` then appeared after that new poll start.

The extension popup remained in `WAITING_FOR_NEXT_ASSISTANT_FORM`, but the old poll had already stopped the actual observer/timers. Therefore no future assistant writing block could be captured until a manual restart.

### First divergence and five preceding transitions

- **First wrong object/state:** the old poll’s `promptPollTimer` was accepted as proof that a new report anchor was already being watched. The code had only one mutable `currentAnchorTurnId`; report delivery rewrote it before the new poll was formally installed.
- **T-5:** the old form reached `FULL_WRITING_BLOCK_TEXT_RECEIVED` and local validation failed.
- **T-4:** Worker prepared and delivered a normal same-chat validation-error report.
- **T-3:** `sendMessageAndCaptureAnchor()` recorded the new report user-turn in `currentAnchorTurnId` while the old poll generation and timer still existed.
- **T-2:** Worker called `AF_CAPTURE_BEGIN_PROMPT_POLL` for the new report anchor.
- **T-1:** `startPromptPolling()` saw the same `runId + currentAnchorTurnId + timer` and returned idempotently without creating a fresh generation.
- **First divergence:** when the late response of the old form returned with `disposition=continuation_started`, its generation still looked current and `stopPromptPolling()` cleared the only remaining observer/timer.

### v0.6.2 change

The capture lifecycle is repaired without editing the ten Bridge-derived capture functions:

- Added `promptPollBoundAnchorTurnId`: an explicit record of the anchor owned by a live poll generation.
- `startPromptPolling()` now treats a call as idempotent only if the exact anchor is owned by the same live observer/timer generation.
- A delivery-discovered anchor that differs from the old generation’s bound anchor necessarily stops/fences the old poll and creates a fresh generation.
- `promptTick()` now exits without scanning when `currentAnchorTurnId` was updated by report delivery but is not yet owned by that poll generation.
- `stopPromptPolling()` clears the bound-anchor ownership together with timers and observer.
- Added two non-sensitive diagnostics: `PROMPT_POLL_BOUND_TO_NEW_ANCHOR` and `PROMPT_POLL_ALREADY_LIVE_FOR_ANCHOR`. They contain only anchor IDs and generation numbers, not writing-block content.

No Avito target resolution, visible-action policy, permissions, host access, storage keys, Bridge isolation, report text ownership or selector rules were changed.

### Regression evidence

- Node test uses the actual packaged-source `stopPromptPolling()` and `startPromptPolling()` function bodies in a controlled harness.
- It reproduces the exact bad state: `currentAnchorTurnId` already equals a newly delivered report anchor while the live poll remains bound to the old anchor.
- The test proves a new observer/timer generation is created and the old observer is disconnected.
- A second test proves that an exact live same-anchor poll remains idempotent and does not create duplicate timers.
- The ten Bridge-derived capture functions remain byte-identical to v0.6.1, including `sendMessageAndCaptureAnchor`.
- The actual v0.6.2 parser accepts the bounded `AVITO_UI` plan grammar for visible city text entry and a `DIALOG_VISIBLE` snapshot.
- Manifest permissions and host permissions are byte-for-byte unchanged from v0.6.1.

### Validation boundary

A local headless Chromium attempt in this environment failed before it produced a DOM result because the container Chromium environment did not complete startup. This is captured as a blocked local fixture attempt, not presented as test success and not used as evidence of live Chrome behavior.

### Current confirmed state and next roadmap step

- The code-level continuation wedge after a validation-error report is repaired and regression-tested.
- It is not yet proven in the user’s installed Chrome profile.
- The next live acceptance sequence after installing v0.6.2 is deliberately narrow:

```text
invalid AVITO_UI form
→ validation-error report sent to the same pinned chat
→ new report user-turn becomes anchor
→ next valid writing block is copied once
→ local validation result is returned
```

Only after this continuity proof may the city plan continue: open city dialog → type `Златоуст` → inspect visible suggestions → select one unambiguous result.


### Exact package validation completed

- The distributable archive `AVITO_FINDER_v0.6.2_continuation-anchor-generation-fence_TEST_CANDIDATE.zip` was created from the repaired source tree.
- `unzip -t` completed without errors.
- `node --check` passed for every JavaScript runtime file extracted from that exact archive.
- Source files and the files extracted from the exact archive were compared byte-for-byte.
- `node --test` regression suite: 6 passed, 0 failed.
- The package SHA-256 is recorded in the validation evidence archive.
- The package remains a **test candidate** because the user-Chrome continuation chain has not yet been run after installation.


---

## Append — v0.6.3 — bounded snapshot delivery from successful AVITO_UI plans

**Date:** 2026-06-25  
**Status:** test candidate; requires live user-Chrome proof.  
**Append-only rule:** this record is appended without modifying earlier history.

### Triggering live evidence

Task `af-20260625085856-dby4` ran a bounded `AVITO_UI` plan: WAIT → TYPE into the exact visible city input → WAIT → SNAPSHOT. The execution report correctly said all four steps completed, including `SNAPSHOT`, but returned only the plan summary. It did not include the captured bounded DOM payload. Consequently, ChatGPT could not inspect city suggestions, despite the browser having performed the allowed visible action.

### First wrong object and five preceding transitions

- **First wrong object/value:** `Core.formatUiActionPlanReport(actionPlan)` omitted `actionPlan.avito.snapshot`. The snapshot existed in the executed plan result and in locally stored inspection state, but was discarded at report rendering.
- **T-5:** ChatGPT capture accepted the form in the pinned conversation.
- **T-4:** Worker activated the run-owned Avito tab.
- **T-3:** `TYPE` entered the bounded city text into the exact visible `popup-location/region/search-input`.
- **T-2:** `SNAPSHOT` called `diagnose({ scope: 'DIALOG_VISIBLE' })` and set `result.snapshot`.
- **T-1:** Worker wrapped the result as `{ avito: result }` and called `Core.formatUiActionPlanReport`.
- **First divergence:** the formatter output steps and listings but no `plan.snapshot` section.

### v0.6.3 change

- The `AVITO_UI` report renderer now includes a bounded snapshot section only when an executed `SNAPSHOT` step produced `plan.snapshot`.
- It returns scope, status, root description, fingerprint, truncation status, bounded tree, visible controls and bounded HTML.
- A plan without `SNAPSHOT` still reports `Диагностический снимок UI-плана: не запрашивался`; no DOM data is invented.
- No target resolver, click/type behavior, action allowlist, delays, permissions, host permissions, storage keys, chat capture functions, same-chat delivery path or Business Bridge boundary changed.

### Regression evidence

- Existing v0.6.2 continuation-anchor fence tests remain in the suite.
- Added regression: a real `formatUiActionPlanReport()` call with `DIALOG_VISIBLE` snapshot must include the bounded DOM payload.
- Added negative regression: no snapshot payload must not be fabricated when no snapshot exists.
- The ten Bridge-derived capture functions remain byte-identical to v0.6.1.

### Required live acceptance

1. Install v0.6.3 in the same Chrome profile and start in the pinned ChatGPT conversation.
2. Run the bounded city plan: open/reuse city dialog → type `Златоуст` → wait → `SNAPSHOT DIALOG_VISIBLE`.
3. Verify the same-chat report includes the actual bounded snapshot, including visible city suggestions.
4. Confirm the extension remains in `WAITING_FOR_NEXT_ASSISTANT_FORM` with a live watcher after report delivery.
5. Only then choose an unambiguous city suggestion and proceed to search implementation; `SEARCH` remains unimplemented.


---

## Append — v0.6.4 — generic reactive TYPE sequence for visible controls

**Date:** 2026-06-25  
**Status:** test candidate; live user-Chrome acceptance is required.  
**Append-only rule:** this section is appended without changing earlier history.

### Triggering live evidence

The installed v0.6.3 successfully completed bounded plans and returned the `DIALOG_VISIBLE` snapshot. The snapshot then proved the failure was not the requested city value: after `TYPE` into `input[data-marker="popup-location/region/search-input"]`, Avito displayed `data-marker="popup-location/error"` with “Неизвестный город или регион” for both `Златоуст` and the control value `Москва`. The visible save button stayed disabled and no suggestions appeared, even after an additional wait.

### First wrong object and five preceding transitions

- **First wrong function:** `setVisibleControlValue(element, value)` in `avito_content.js`.
- **T-5:** the generic local resolver uniquely found the visible city input by the observed public `data-marker`.
- **T-4:** the old function set the input’s native `value` property directly.
- **T-3:** it emitted exactly one synthetic `input` event containing the whole string.
- **T-2:** it emitted `change`, but never focused the control and emitted no `beforeinput`, `keydown`, or `keyup` sequence.
- **T-1:** the plan reported `TYPE: completed` because the property changed locally.
- **First divergence:** Avito’s reactive city control did not produce suggestions for even `Москва`; its visible error state remained instead. The previous test model had verified only property mutation and a single `input` event, not a focus-required reactive input lifecycle.

### v0.6.4 change

`TYPE` remains one generic, local, bounded visible action. It does not contain a city-specific branch or hard-coded Avito selector.

For one uniquely resolved visible editable target it now performs:

```text
focus
→ select existing text when supported
→ cancellable beforeinput/delete + native clear when a prior value exists
→ for each grapheme: keydown → cancellable beforeinput → native value update → input → keyup
→ change
```

The action returns `UI_TARGET_FOCUS_FAILED` if the target cannot become the active element. The report adds only the generic strategy label `focus_native_beforeinput_input_change`; it does not reveal typed text beyond the existing “введено” summary.

No debugger protocol, CDP, arbitrary JavaScript command, clipboard access, cookies, hidden API, network request, remote selector, trusted-event claim, proxy, captcha method, seller interaction, purchase or payment behavior was added. `CLICK`, `WAIT`, `WAIT_FOR`, `SNAPSHOT`, `COLLECT_LISTINGS`, target resolution, permissions, host permissions, storage namespaces and tab policy are unchanged.

### Version-consistency repair

The manifest, core marker, service-worker `CAPTURE_VERSION`, and ChatGPT content-script `CONTENT_SCRIPT_VERSION` / runtime-id marker now all state `0.6.4`. The ten protected Bridge-reference capture functions remain byte-identical to the frozen v0.6.1 reference.

### Regression evidence

1. The exact v0.6.3 `avito_content.js` reproduces the defect in a real Chromium DOM fixture: the value becomes `Москва`, but the fixture receives neither focus lifecycle nor `beforeinput`; it exposes the same visible error state and no option.
2. The exact v0.6.4 `avito_content.js` runs in the same real Chromium DOM fixture, focuses the input, emits per-grapheme `beforeinput` / `input` events and returns a visible `Москва` option with an enabled save button.
3. The fixture must use an `about:blank` document created through DevTools because this container’s organization policy blocks navigations to network, localhost, data and file URLs. Only the core URL-host gate is substituted in memory for this fixture origin; the tested `avito_content.js` bytes are exact packaged runtime bytes.
4. `node --test` covers the old failure, v0.6.4 reactive success, continuation generation fence, report snapshot delivery, manifest permissions, runtime version-marker agreement and byte-identical protected capture functions.

### Validation boundary

The Chromium fixture proves generic browser-DOM behavior, not Avito acceptance in the user profile. Avito may still reject untrusted synthetic UI events or vary its DOM. The candidate is therefore **not** a completed search release.

### Required live acceptance and nearest roadmap step

Current confirmed roadmap position: R4 (city) is still open. R3 snapshots are live-proven; v0.6.3 live-proved same-chat snapshot delivery; the next unclosed action is one safe R4 input proof in the user Chrome after installing v0.6.4:

```text
open/reuse city dialog
→ type «Москва»
→ wait
→ bounded DIALOG_VISIBLE snapshot
```

Acceptance for this narrow proof: a visible unambiguous option appears, no city is selected, the save/search button is not clicked, the report returns to this same chat, and the next watcher remains active. Only then may the equivalent `Златоуст` plan be tried and exactly one visible result selected.


---

## Append — v0.6.5 — explicit Chrome debugger authorization, Input-only trusted visible TYPE

**Date:** 2026-06-25  
**Status:** test candidate; the package is not a completed release until it is accepted in the user’s live Avito tab.  
**Authorization:** the user explicitly authorized adding the Chrome `debugger` permission for Avito after the live failure of synthetic text input.  
**Append-only rule:** this entry is appended without changing earlier history.

### Triggering live evidence

The installed v0.6.4 plan completed `WAIT → TYPE → WAIT → SNAPSHOT`, and v0.6.3 correctly returned the bounded dialog snapshot. Yet Avito rendered `data-marker="popup-location/error"` with “Неизвестный город или регион” and left `popup-location/save-button` disabled for both the requested city `Златоуст` and the control city `Москва`. The field’s visible value changed, but no suggestion appeared.

This proves that the old local DOM mutation was not accepted by the Avito control. It does **not** prove that the city names are unavailable.

### First wrong function and five preceding transitions

- **First wrong function:** `setVisibleControlValue(element, value)` in v0.6.4 `avito_content.js`.
- **T-5:** the local resolver uniquely found the visible input `data-marker="popup-location/region/search-input"`.
- **T-4:** the code changed the native `value` property and dispatched JavaScript-created DOM events.
- **T-3:** the report correctly marked `TYPE` completed because the element property had changed.
- **T-2:** the visible dialog still exposed `popup-location/error`.
- **T-1:** the visible save button remained disabled and no option control appeared.
- **First divergence:** Avito rejected the synthetic lifecycle for both values, including `Москва`.

Waiting longer, changing the city text, or adding more JavaScript-created events is not a solution. The next input must be delivered through Chrome’s browser input pipeline while retaining the project’s visible-UI and same-chat boundaries.

### v0.6.5 change

The generic `TYPE` step has one new, deliberately narrow path. It is available only after an existing local resolver has already found one unambiguous, visible, editable target in the currently active Avito tab.

1. `avito_content.js` creates a one-use local token, records the exact resolved element and sends only its bounded viewport rectangle, stable public descriptor, text length/value and current page URL to the service worker.
2. The service worker accepts the request only when all of the following are true: an `AVITO_UI` task is active; sender tab equals the run-owned Avito tab and current window; the tab is active, complete and Avito-hosted; the request URL has the same Avito origin; the token, editable target tag, text length and visible geometry pass hard bounds.
3. The service worker briefly attaches to that one tab through `chrome.debugger`, clicks only inside the previously measured visible rectangle, asks the content script to confirm the same element owns focus, clears the previous visible text only when one existed, inserts the new text one grapheme at a time, asks the content script to confirm the expected final visible value, and detaches in a `finally` path.
4. The action is blocked with a same-chat failure result when attach, focus confirmation, trusted input, final value confirmation or detach fails. There is no fallback to direct property assignment or synthetic DOM input events.

The only CDP method names permitted by code are exactly:

```text
Input.dispatchMouseEvent
Input.dispatchKeyEvent
Input.insertText
```

The code contains no `Runtime.*`, `Network.*`, `Page.*`, `Fetch.*`, `DOM.*`, `Storage.*` or `Target.*` CDP command. It does not call `chrome.debugger.getTargets`, does not subscribe to debugger protocol events, does not execute page JavaScript through CDP, does not read cookies, does not access hidden Avito APIs, does not use proxy/CAPTCHA methods, and does not change seller, purchase or payment boundaries.

### Permission and user-visible behavior

The manifest adds exactly one permission: `"debugger"`. Existing host permissions are unchanged. Chrome may visibly indicate that the extension is debugging the active Avito tab during a `TYPE` action; the implementation detaches immediately after the one bounded action. Opening DevTools or another debugger on that tab can interrupt the operation; the extension then reports a blocked `UI_DEBUGGER_TYPE_FAILED` result rather than using a weaker fallback.

### Validation evidence

- Backup/rollback baseline: exact v0.6.4 source-and-tests ZIP preserved with SHA-256 before mutation.
- Exact v0.6.5 source passed `node --check` for all runtime and Node test files and Python syntax compilation for fixtures.
- `node --test tests/*.test.js`: **16 passed, 0 failed**.
- The frozen ten Bridge-reference ChatGPT capture functions remain byte-identical to the v0.6.1 reference.
- Manifest test proves the only new permission is `debugger`; host permissions remain byte-identical to v0.6.1.
- Service-worker policy test proves only the three listed `Input.*` methods can reach `chrome.debugger.sendCommand`; `Runtime.evaluate` is rejected before any call.
- A real local Chromium DOM fixture loaded the exact packaged `avito_content.js`, used the same three CDP `Input.*` primitives, and observed trusted focus, trusted `beforeinput`/`input`, an enabled visible save control and a visible `Москва` suggestion.

This local fixture proves Chromium Input behavior and the extension content-side handoff. It is **not** evidence that Avito in the user’s Chrome profile accepts the action.

### Current confirmed stage and nearest roadmap step

Current confirmed roadmap position remains **R4 — city**. R3 bounded dialog snapshots and same-chat return are live-proven; R4 is still open because the real Avito city control has not yet accepted a trusted-browser input from v0.6.5.

The only next live acceptance plan is narrow:

```text
open/reuse city dialog
→ type «Москва» through the already resolved visible field
→ wait
→ bounded DIALOG_VISIBLE snapshot
→ verify a visible option, no error marker, enabled save button
→ do not select/save/search in this proof
→ verify same-chat report and next watcher remain active
```

Only after that proof may the equivalent `Златоуст` plan be run and exactly one visible city option selected. Product search, price filters and collection remain outside this change.


## Append — v0.6.6 — trusted key lifecycle, bounded dropdown option selection, and empty-writing-block guard

### Triggering live evidence

The live video shows the actual Avito city flow: after ordinary user typing of `Златоуст`, a visible suggestion `Златоуст, Челябинская область` appears; clicking that suggestion commits the city and reveals the selected-city/radius interface. The extension’s v0.6.5 `TYPE` plan instead showed a changed visible value but left `popup-location/error` and an inactive save control. A later `CLICK` on the outer `popup-location/region` combobox did not expose a selectable option. Separately, the chat adapter accepted a rendered empty writing-block shell (`0` bytes) and incorrectly sent it to validation, generating `MODE_UNRESOLVED`.

### First divergent boundaries

1. v0.6.5 used `Input.insertText` after focus. It confirmed the final visible value but did not create the trusted key lifecycle that the live Avito city control receives from real keyboard input.
2. The generic `CLICK` resolver considered only conventional controls and could not safely choose a text option represented by a non-button element inside the dropdown.
3. The chat capture path sent a `0`-byte local Copy result to the worker instead of treating it as an unfinished renderer shell.

### v0.6.6 change

1. The debugger allowlist is narrowed from three CDP methods to two: `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`. `Input.insertText` is removed. The active, run-owned Avito tab receives mouse focus, then `keyDown` with text and `keyUp` for each grapheme; Chrome produces the trusted keypress/beforeinput/input lifecycle. No `Runtime`, `Network`, `Page`, `Fetch`, `DOM`, `Storage`, or `Target` CDP command exists in the runtime.
2. A new parsed plan action `SELECT_OPTION` is produced only by an explicit instruction to choose exact quoted text from a dropdown/list/suggestion. It resolves only one exact-text visible target inside exactly one open `[role=dialog]`; it rejects missing, ambiguous, disabled, forbidden, or non-dialog targets. It never scans page listings, navigation, seller UI, messages, payments, or hidden APIs.
3. A zero-byte or unavailable local writing-block payload is ignored locally. It logs `PROMPT_EMPTY_WRITING_BLOCK_IGNORED`, preserves the anchor and rechecks after the DOM settles. It no longer creates a validation report or a new ChatGPT user turn.

### Scope and non-changes

The popup files are byte-identical to v0.6.5. Host permissions are unchanged. The existing `debugger` permission remains, but its runtime CDP method allowlist is narrower. No Business Bridge code, runtime, queue, storage, identifiers or logs are used. No seller contact, payment, purchase, saved-search, CAPTCHA/proxy, cookie, hidden API, network scraping, or arbitrary JavaScript capability is added.

### Validation evidence

- `node --check` passed for every runtime and test JavaScript file.
- `node --test` passed 4/4 tests.
- The exact v0.6.6 runtime source was injected into a real local Chromium DOM fixture. CDP `Input.dispatchKeyEvent` produced trusted `keydown`, `beforeinput`, and `input` events for `Москва`; the fixture showed its keydown-gated suggestion. The exact `dialogScopedOptionCandidates` resolver selected `Златоуст, Челябинская область` inside the dialog.
- Exact ZIP validation passed: `unzip -t`, JavaScript syntax checks from the extracted ZIP, manifest assertions, and byte-for-byte hashes of all runtime files against the extracted ZIP.
- The v0.6.5 candidate ZIP is included in the evidence archive as the rollback baseline.

### Live acceptance remains required

This is a test candidate, not an accepted release. The current confirmed roadmap position remains R4 — city. The next live proof must run one bounded chain in the user Chrome: type `Златоуст`, wait for the visible suggestion, choose exactly `Златоуст, Челябинская область` from the visible dropdown, then return a `DIALOG_VISIBLE` snapshot proving the error is gone and the selected-city/radius interface is visible. Search and listing collection remain out of scope for this acceptance step.


## Append — v0.6.7 — ChatGPT capture watchdog, Core binding, and server-side empty-payload fence

### Triggering live evidence

The v0.6.6 live run anchored the dedicated ChatGPT conversation and reached a complete assistant writing block. The local trace recorded a ready Copy control and a non-empty visible payload (`1438` bytes), then stopped making capture progress: later records were only activity observations. No `FULL_WRITING_BLOCK_TEXT_RECEIVED` event followed before the user saw another `0`-byte `MODE_UNRESOLVED` validation report.

A Chromium reproduction against the exact v0.6.6 `chatgpt_content.js` exposed the first runtime exception after the local Copy click:

```text
ReferenceError: Core is not defined
```

The affected code called `Core.normalizeText(...)` even though the adapter had no `const Core = AvitoFinderCore` binding. The exception was inside `promptTick`’s `try/finally`, so it cleared the in-flight flag without producing a bounded capture report. Separately, `reportPromptActivity()` awaited a service-worker callback although activity telemetry is non-authoritative; a missing callback could indefinitely hold a capture tick before Copy.

### First wrong code boundary and five preceding transitions

- **First wrong executable reference:** `Core.normalizeText(candidate.prompt_text || "")` in `chatgpt_content.js`, with no local `Core` binding.
- **T-5:** Start sent `Ищи` to the pinned conversation and captured the new user anchor.
- **T-4:** Prompt polling bound that anchor and waited for the assistant writing block.
- **T-3:** The writing block became copy-ready; the trace recorded a non-empty local body.
- **T-2:** The two-second DOM-stability gate was started.
- **T-1:** Local Copy was clicked.
- **Divergence:** the undefined `Core` reference threw before full-text handoff; a subsequent zero-byte candidate could still reach worker validation from an interrupted/stale adapter path.

Waiting longer, changing the city, clicking the outer combobox again, or adding another Avito action is not a solution. The failure occurs before any Avito plan is accepted.

### v0.6.7 change

1. `chatgpt_content.js` now explicitly binds `const Core = AvitoFinderCore` before any capture-path reference.
2. Runtime messages have a bounded timeout. `AUTOMATION_PROMPT_ACTIVITY` is now fire-and-forget telemetry with a short timeout; it cannot own or block the prompt state machine.
3. The two-second writing-block stability deadline uses a dedicated `promptStabilityTimer`. Normal mutation-driven fast rescans use a separate timer and cannot cancel the already scheduled stability deadline unless the local writing-block structural signature itself changes.
4. `service_worker.js` now rejects any candidate whose payload is absent, zero-byte or non-normalized **before** deduplication, validation, state mutation and same-chat report delivery. It logs `EMPTY_WRITING_BLOCK_CANDIDATE_IGNORED` and keeps the existing wait alive instead of producing `MODE_UNRESOLVED`.
5. A test-only identity hook exists only behind `globalThis.__AF_TEST_EXPORTS` so the exact adapter can be executed in a local Chromium fixture; production initialization never sets it.

### Scope and non-changes

- Popup files are byte-identical to v0.6.6.
- `avito_content.js` and `core.js` are byte-identical to v0.6.6.
- Manifest host permissions are unchanged. `debugger` remains the sole additional permission already introduced in v0.6.5.
- The CDP allowlist remains only `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`.
- No seller contact, purchase, payment, saved search, CAPTCHA/proxy, cookies, hidden APIs, network scraping or arbitrary JavaScript capability was added.
- Avito Finder remains isolated from Business Bridge code, storage, queues, service workers and logs.

### Validation evidence

- `node --check` passed for all packaged runtime JavaScript files and test JavaScript files.
- `python3 -m py_compile` passed for both Chromium fixtures.
- `node --test tests/*.test.js`: **5 passed, 0 failed**.
- The existing exact Chromium Avito fixture still proves the bounded trusted keyboard lifecycle and dialog-scoped exact option resolver.
- A new exact Chromium ChatGPT fixture loaded `core.js` and `chatgpt_content.js`, intentionally never answered the activity telemetry callback, generated unrelated DOM mutations every 40 ms, and still observed exactly one local Copy click plus exactly one non-empty `AF_CAPTURE_FULL_TEXT` handoff with no tick left in flight.
- Exact candidate ZIP validation includes unpacking, runtime syntax checks, source-to-ZIP SHA-256 equality and both Chromium fixtures against the extracted ZIP runtime.

### Live acceptance remains required

This is a test candidate, not an accepted release. Current confirmed roadmap position remains **R4 — city**. The nearest unclosed step is now the same bounded live chain, but first it must prove that v0.6.7 captures the writing block exactly once and returns an Avito plan instead of freezing or emitting `MODE_UNRESOLVED`. Only then may the existing city-selection plan type `Златоуст`, select exactly `Златоуст, Челябинская область` from the visible dropdown, and return the selected-city/radius snapshot. Search and listing collection remain outside this acceptance step.



## Append — v0.6.8 — portal-bound exact option discovery and trusted visible option click

**Date:** 2026-06-25  
**Status:** test candidate; a live Chrome proof is still mandatory.  
**Append-only rule:** this section is appended without altering earlier history.

### Triggering live evidence

The live Avito screenshot proves that after the extension typed `Златоуст`, the public interface visibly displayed the exact first suggestion `Златоуст, Челябинская область`. Yet the same task returned `UI_OPTION_NOT_VISIBLE`. A bounded `DIALOG_VISIBLE` snapshot showed the typed field and no suggestion nodes despite the rendered dropdown being visible to the user.

### First wrong boundary and five preceding transitions

- **First wrong resolver scope:** `dialogScopedOptionCandidates()` searched only `dialog.querySelectorAll(...)`.
- **T-5:** the unique city input inside the one visible dialog was resolved.
- **T-4:** the bounded trusted keyboard sequence entered `Златоуст`.
- **T-3:** Avito rendered a visible suggestion list below the field.
- **T-2:** the visible list was not a descendant of the selected dialog root in the DOM snapshot.
- **T-1:** `SELECT_OPTION` searched only the dialog subtree and found no exact option.
- **First divergence:** the plan returned `UI_OPTION_NOT_VISIBLE`, although the public UI showed the exact city option.

The city is available. Retrying the same subtree-only selection, changing the requested city, clicking the outer combobox, or starting a search is not a solution.

### v0.6.8 change

1. Exact option discovery remains restricted to one visible `[role=dialog]`, one visible editable input context, one exact option text and the existing seller/purchase forbidden-target fence.
2. The resolver can now see a framework portal option only when its actual painted rectangle is horizontally aligned with the current dialog and vertically bound to the active input/modal. Exact text elsewhere on the page is excluded.
3. A topmost `elementsFromPoint` reachability check rejects visually covered nodes behind the modal.
4. `SELECT_OPTION` uses the existing narrow Chrome debugger permission for one trusted `Input.dispatchMouseEvent` click on the exact painted option target, then immediately detaches. It does not use synthetic `.click()` for this option action.
5. The CDP allowlist remains exactly `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`; no permission, host access, Runtime, Network, Page, Fetch, DOM, Storage, Target, cookies, hidden API or arbitrary JavaScript capability was added.

### Scope and non-changes

- The popup remains unchanged.
- ChatGPT capture behavior, storage isolation, Business Bridge separation and all seller/purchase/payment/CAPTCHA boundaries remain unchanged.
- The action cannot select a page card, navigation item, seller control or background text: the target must be exact visible text, paint-reachable, geometry-bound to the open modal and unambiguous.

### Validation evidence

- A real local Chromium fixture loads the exact packaged content script with a dialog input and a suggestion rendered as a body-level portal sibling. It proves that the resolver finds only the portal option aligned to the active dialog, rejects an identical background page copy, and selects the intended exact text.
- The test also checks that the worker's trusted option-click path accepts only `intent: SELECT_OPTION`, a bounded option text, a one-use click token, an active run-owned Avito tab and the existing two-method CDP allowlist.
- Exact package checks, Node tests, JavaScript syntax checks and source-to-ZIP hashes are recorded in the validation report.

### Current confirmed stage and nearest roadmap step

Current confirmed position remains **R4 — city**. The next live acceptance chain is now exactly:

```text
type «Златоуст»
→ wait for the visibly rendered exact suggestion
→ choose only «Златоуст, Челябинская область»
→ return DIALOG_VISIBLE snapshot proving selected-city/radius state
```

The city save button, search, filters, listing collection and all seller interactions remain outside this v0.6.8 acceptance step.


## Append — v0.6.9 — bounded native-select option selection and blocked-candidate evidence

### Triggering live evidence

The user’s Chrome screenshot showed the public Avito city list visibly open after the trusted input of `Златоуст`, with the first row `Златоуст, Челябинская область`. Two v0.6.8 attempts nevertheless stopped at `UI_OPTION_NOT_VISIBLE`. The bounded `DIALOG_VISIBLE` report contained the associated `select[data-marker="popup-location/region/select"]`, but its option rows were not represented as ordinary painted DOM descendants in that snapshot.

This means the previous resolver’s portal support was still incomplete: it could resolve a painted DOM option row, but not a browser-native select popup or equivalent user-agent-rendered option surface bound to the active field.

### First divergent boundary

`dialogScopedOptionCandidates()` treated an option as selectable only when it was a visible layout element discovered by ordinary DOM/portal walking. An associated public `<select>` can expose option text through `label`, `text`, or `value` while the browser paints its open menu outside the page DOM tree. In that case, the exact visible option exists for the user but no ordinary `visible(option)` candidate survives.

Retrying the same DOM-only selection, changing the requested city, or starting search is not a solution.

### v0.6.9 change

1. `SELECT_OPTION` keeps the existing exact-text DOM and portal path. It now also has a generic, modal-bound native-select fallback. It is eligible only when there is one open visible dialog, one active editable input context, one associated visible `<select>`, and exactly one non-disabled option whose public `label`, `text`, `value`, or text content exactly equals the requested option text.
2. Native selection is performed as visible browser input only: one bounded mouse focus on the associated `<select>`, then `Home`, the exact number of `ArrowDown` steps for the uniquely matched option index, and `Enter`. The worker still allows only `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`, attaches only to the active run-owned Avito tab, confirms focus and exact option identity before action, confirms the committed selected index afterward, and detaches immediately.
3. The implementation never writes `select.value`, never calls synthetic `.click()` for the native path, never evaluates arbitrary JavaScript through CDP, and never uses Runtime, Network, Page, Fetch, DOM, Storage, Target, cookies, hidden APIs, seller controls, payments, or search execution.
4. The UI-plan report now includes bounded candidate evidence for a blocked action. A future `UI_OPTION_NOT_VISIBLE` or ambiguity report therefore exposes the candidate descriptions, scope and selection kind needed for the next narrow diagnostic rather than dropping that evidence.
5. `label` is preserved in the sanitized local DOM snapshot only for public option/control labels. Popup files, ChatGPT capture logic, host permissions, storage isolation, Business Bridge separation and the two-command debugger allowlist are unchanged.

### Validation evidence

- `node --check` passed for every runtime JavaScript file and the Node test file; Python fixture files compiled successfully.
- `node --test tests/*.test.js`: **8 passed, 0 failed**.
- A real local Chromium fixture loaded the exact packaged resolver with a visible dialog, an active city input and an associated public native select containing `label="Златоуст, Челябинская область"`. The resolver classified the target as `native_select`, obtained exact option index `1`, and the bounded visible `mouse → Home → ArrowDown → Enter` Input sequence committed that exact option.
- Existing local Chromium fixtures for trusted typing, dialog option selection, body-level portal selection and ChatGPT capture stability remain part of the same exact test suite.
- Exact candidate ZIP integrity, extracted runtime syntax and source-to-ZIP hashes are recorded in the validation report.

### Current confirmed stage and nearest roadmap step

Current confirmed position remains **R4 — city**. The next live acceptance is one narrow chain in the user Chrome:

```text
type «Златоуст»
→ select exactly «Златоуст, Челябинская область» from the already visible city UI
→ return DIALOG_VISIBLE snapshot proving selected city and radius interface
```

The save button, product query, price filters, listing collection and all seller interaction remain out of scope for this candidate.

---

## Append — v0.7.0 — adaptive visible-menu model

**Date:** 2026-06-25  
**Status:** test candidate; package and local Chromium fixtures passed, but live user-Chrome acceptance is still required.  
**Append-only rule:** this entry is appended without rewriting any earlier history.

### Triggering defect

The user’s live screenshot showed a real Avito city menu with a selectable row rendered through ordinary page DOM. Previous candidates treated the current markup as a selector problem: first a dialog-only tree, then a body portal, then an associated native `select`. That was the wrong abstraction. A visible suggestion surface can change its tag, class names, data markers, nesting, and portal placement; the extension must model the **interaction behaviour of the menu**, not freeze one observed DOM shape.

### What changed

- Added a generic `COLLECT_MENU` UI action. It does not accept CSS selectors or JavaScript from ChatGPT. It collects only a bounded, visible menu associated with the last typed field.
- `TYPE` now starts a short local mutation capture **before** trusted input. The collector records only recently changed public DOM nodes and then combines four local signals:
  1. the menu is geometrically near the active input;
  2. the row is visible and pointer-reachable;
  3. the row exposes interactive/selection semantics, a pointer cursor, or belongs to a repeated visible row surface;
  4. the row was created or changed after typing, when that evidence exists.
- Each discovered option is represented by a public `MenuModel`: a bounded label, tag/role summary, source category, bounds, menu id and structural contract fingerprint. Raw DOM elements are kept only in the in-page short-lived model and never sent through the extension message boundary.
- Labels are compared with a punctuation-insensitive normalized key. Thus an ordinary command such as `Выбери «Златоуст, Челябинская область» из видимого выпадающего списка` may match a row whose nested text is rendered as `Златоуст` plus `Челябинская область`.
- Before a selection, the menu is collected again and the exact option is revalidated. If the option/menu changed, is not visible, is ambiguous, or cannot be observed, the action stops and returns a bounded menu report instead of guessing a click target.
- A narrowly associated visible native `select` remains a secondary generic adapter only. It is no longer the primary interpretation of an arbitrary visible menu.
- No runtime city, region, class, `data-marker` option selector, or menu-library name is hardcoded in extension runtime.

### Safety and boundaries

- The collector is limited to at most 12 visible menu rows and a five-second local capture window.
- It never reads cookies, storage, hidden APIs, network traffic, page JavaScript state, or closed shadow DOM.
- It does not execute selectors or JavaScript supplied by ChatGPT.
- Selection still requires one exact label match and uses the existing tightly allowlisted visible Input path only after local revalidation.
- Seller contact, calls, purchase, payment, checkout, delivery and search execution remain blocked/out of scope.

### Evidence

- `node --test tests/v069.test.js tests/v070.test.js`: 12 passed, 0 failed.
- Chromium fixture: trusted input lifecycle plus an in-dialog selectable row.
- Chromium fixture: a body portal row geometrically tied to the input while a same-text background control is ignored.
- Chromium fixture: associated native `select` exact option path remains bounded.
- Chromium fixture: two dynamic menu shapes with different tags/nesting are captured, normalized and selected without a city/region/class/marker hardcode; private DOM references are removed before report serialization.
- `node --check` passed for all packaged runtime JavaScript files.
- Exact package extraction and runtime SHA-256 equality are required before sharing this candidate.

### Known limit and safe fallback

No extension can guarantee observation of every future widget: browser-owned native popups, closed shadow roots, or a UI rendered outside accessible page DOM may be unobservable. In that condition v0.7.0 must return `UI_MENU_NOT_OBSERVED` or a bounded collected-menu report; it must not invent a selector or click a guessed location.

### Current confirmed stage and next roadmap step

The current confirmed stage remains **R4 — choose city**. The nearest unclosed step is live proof in the user’s Chrome that one ordinary writing block can: type a city → return the adaptive menu model (or select one exact visible row) → show the selected-city/radius state in the same chat. Search remains excluded from this candidate.

---

## Append — v0.7.2 — temporal menu core cleanup, Avito-only

**Date:** 2026-06-25  
**Status:** test candidate; local validation passed, live user-Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without changing prior history.

### Triggering live evidence

The live v0.7.0 `COLLECT_MENU` report was false: after city typing, it returned static header/navigation labels such as “Для бизнеса” as a menu, while the bounded dialog snapshot showed `Неизвестный город или регион`. The first wrong mechanism was `rawMenuOptionCandidates`: it scanned broad page nodes and allowed geometry/repetition to qualify a persistent page surface.

### What was removed

1. The browser-native `<select>` fallback and its dedicated debugger request/confirmation path were removed. It was an inferred adaptation rather than evidence from the current accessible menu.
2. The broad collector over arbitrary `div`, `span`, `strong` and `em` nodes was removed.
3. Page-wide repeated-surface logic and the associated portal/native-selection branches were removed.

### Replacement: one temporal visible-menu model

1. The collector starts before trusted typing and records only added or changed public DOM nodes during that attempt.
2. A candidate must be a visible interactive/selection row, row-sized, below and close to the active field, pointer-reachable, and temporally linked to the current capture.
3. It collects at most 12 public rows. The report retains only normalized public text, tag/role summary, bounds, bounded container identity and a fingerprint; live DOM references never leave the page context.
4. Selection is allowed only for one exact normalized label from the freshly observed menu. It is revalidated locally before the existing bounded debugger mouse click.
5. No current city, region, class, `data-marker` menu-row selector, menu-library name or per-page selector is embedded in the runtime.

### Retained Avito-side improvements

- Trusted `TYPE` now uses `keyDown → char → keyUp` per grapheme through the pre-existing limited Input debugger allowlist.
- `SEARCH_SURFACE_VISIBLE` now accepts a visible search input plus a visible Find control even when the category control is rendered outside the same form subtree.
- The post-type pause is minimized only when the immediate next plan step gathers or selects the menu, preventing a transient menu from being discarded before inspection.

### Explicit non-changes

- `chatgpt_content.js`, `core.js`, `popup.js`, `popup.html` and `popup.css` are byte-identical to v0.7.0.
- No Business Bridge code, storage, queue, server API or ChatGPT-page behavior was changed.
- No permissions or host permissions were added. The debugger allowlist remains only `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`.

### Validation evidence

- Exact candidate extraction, runtime syntax checks and source-to-package SHA-256 checks are recorded in the validation report.
- `node --test tests/v072.test.js`: 7 passed, 0 failed.
- Local Chromium fixture proved that static header links near the page cannot enter the model, while a newly inserted visible menu with nested city/region text is collected and exactly resolved.
- Local Chromium fixture proved that a visible field-error state returns `UI_MENU_INPUT_REJECTED` rather than a false menu.
- Local Chromium fixture proved the retained `keyDown → char → keyUp` lifecycle writes real input text.

### Current confirmed stage and nearest roadmap step

The current confirmed position remains **R4 — choose city**. The next live acceptance is deliberately narrow:

```text
type a city
→ collect a temporal public menu model, or return a field rejection
→ never return static header/navigation entries
→ only after a real exact option is observed, select it and prove the selected city
```

Search, price, category, listing collection and seller interaction remain out of scope for this candidate.

---

## Append — v0.7.3 — query-correlated temporal menu gate, Avito-only

**Date:** 2026-06-25  
**Status:** test candidate; local validation passed, live user-Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without changing prior history.

### Triggering live evidence

v0.7.2 finally observed four real interactive rows near the city field after input, but they were stale default suggestions for the prior region (for example, Советская Гавань and Хабаровск) while the field showed `Златоуст` and Avito showed a field error. The collector did not misclassify page header anymore, but it still stopped at the first temporal rows without proving that they represented the current typed query.

### Root cause

The first incorrect decision was in `waitForVisibleMenu`: any temporally observed row ended the wait. A focus/clear operation may legally create a temporary default list before the requested query finishes its own UI update. The model therefore treated “temporal” as sufficient evidence, although it lacked query correlation.

### What changed

- Added one generic query-correlation gate to the Avito-only temporal menu model.
- The model retains up to 12 observed visible rows as diagnostic evidence, but a row becomes selection-eligible only when its normalized public label contains the normalized text entered in the active field.
- `COLLECT_MENU` now waits until it sees a related row, a visible field rejection, or the existing bounded timeout. It no longer completes immediately because default suggestions appeared after focus or clearing.
- When only unrelated rows remain visible, the action returns `UI_MENU_QUERY_UNMATCHED`; when the field exposes an error, it returns `UI_MENU_INPUT_REJECTED`. In both cases the observed rows are reported with `query_related=false` and cannot be clicked.
- Exact option selection uses only the freshly query-related internal targets. The generic assistant command remains text based; no current city, region, class, marker, or menu-library selector is embedded.
- Removed the duplicate local implementations of `targetForbidden` and `pointerReachable` left in the v0.7.2 Avito content script.

### Explicit non-changes

- `core.js`, `chatgpt_content.js`, `popup.js`, `popup.html` and `popup.css` remain byte-identical to v0.7.2.
- No Business Bridge code, ChatGPT page behavior, storage, queue or server path changed.
- No permissions or host permissions changed. The debugger allowlist remains `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent` only.

### Validation evidence

- Exact package extraction, runtime syntax checks and source-to-package SHA-256 checks are recorded in the validation report.
- `node --test tests/v073.test.js`: all tests passed.
- Chromium fixture proves that stale default rows are kept as diagnostics but cannot end a query-bound collection; a later matching row is selected as the only eligible result.
- Chromium fixture proves that stale default rows plus a visible field error result in `UI_MENU_INPUT_REJECTED`, not a false selectable menu.

### Current confirmed stage and nearest roadmap step

The current confirmed position remains **R4 — choose city**. The next live proof must show: clear old text → type city → either a query-related visible row is returned or a truthful field rejection is reported. Only a query-related exact row may be selected. Search remains outside this candidate.

---

## Append — v0.7.4 — settled query-correlated menu wait, Avito-only

**Date:** 2026-06-25  
**Status:** test candidate; local validation passed, live user-Chrome acceptance is still required.  
**Append-only rule:** this entry is appended without changing earlier history.

### Triggering live evidence

v0.7.3 proved that a clean typing pass can collect the real `Златоуст, Челябинская область` row. But a one-chain `TYPE → SELECT_OPTION` pass could encounter temporary default suggestions plus a transient visible field error before the query-specific rows had rendered. `waitForVisibleMenu` treated the first error as terminal and returned `UI_MENU_INPUT_REJECTED` too early.

### Root cause

The first incorrect decision was the `!model.input_state` condition in the wait loop. It made a transient error after focus/clear stronger than later query-correlated menu mutations, even inside the same bounded typing capture.

### What changed

- Kept the single temporal, query-correlated menu model from v0.7.3.
- Added only one generic settled-error rule: after typing, a field message becomes terminal only after a bounded 1.8-second response grace window and a short 240ms quiet period with no relevant public DOM mutation.
- A query-related visible row always wins immediately over a stale error/default state.
- `COLLECT_MENU` and `SELECT_OPTION` both use the same bounded 3.4-second menu wait. No separate city or dropdown branch was introduced.
- Existing output remains bounded: no raw DOM, no selectors supplied by ChatGPT, no hidden APIs, storage, network or arbitrary JavaScript.

### Explicit non-changes

- `core.js`, `chatgpt_content.js`, `popup.js`, `popup.html` and `popup.css` remain byte-identical to v0.7.3.
- No Business Bridge code, ChatGPT-page behavior, storage, queue or server path changed.
- No permissions or host permissions changed. The debugger allowlist remains `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent` only.

### Validation evidence

- Exact package extraction, runtime syntax checks and source-to-package SHA-256 checks are recorded in the validation report.
- Node tests verify the unchanged ChatGPT/popup surface and the absence of forbidden CDP domains.
- Local Chromium fixture covers: stale default rows + transient field message → later matching row succeeds; and stale rows + persistent quiet field message → `UI_MENU_INPUT_REJECTED` without a click.

### Current confirmed stage and nearest roadmap step

The current confirmed stage remains **R4 — choose city**. The next live proof is one chain:

```text
clear old city text
→ type city
→ wait only for the current query response within the bounded window
→ select one exact visible matching row
→ prove selected city/radius state
```

Search, price, category, listing collection and seller interaction remain outside this candidate.


---

## Append — v0.7.5 — click-stage evidence, Avito-only

**Date:** 2026-06-25  
**Status:** test candidate; local validation passed, live user-Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without changing prior history.

### Triggering live evidence

The live v0.7.4 run typed the requested city and found the exact `button[role=checkbox]` candidate, but the restricted debugger click returned only `UI_DEBUGGER_OPTION_CLICK_FAILED`. The popup’s visible journal was then dominated by ChatGPT capture events and did not retain the worker-side click stage. This made the failure non-diagnostic.

### Root cause

The first incorrect observability boundary was that an Avito UI-plan failure stored `failure_detail` internally but did not pass its safe value into the ordinary terminal report. The report therefore collapsed all click failures into one code.

### What changed

- Kept the single temporal query-correlated menu collector and every selection gate unchanged.
- Kept the existing CDP allowlist unchanged: `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent` only.
- Added one bounded click-stage label inside the existing option-click path: `attach`, `target_confirmation`, `mouse_pressed`, `mouse_released`.
- Split confirmation failures into no response, target detached, and target not pointer-reachable.
- Propagated only the sanitized stage/error code into the already-existing terminal step text as `diagnostic=...`; no raw DOM, stack trace, cookies, page source or hidden data is returned.

### Explicit non-changes

- `core.js`, `chatgpt_content.js`, `popup.js`, `popup.html` and `popup.css` remain byte-identical to v0.7.4.
- No Business Bridge code, ChatGPT-page behavior, storage, queue or server path changed.
- No permissions or host permissions changed.
- No city, region, current selector, CSS class or hard-coded option label was added.

### Validation evidence

- Exact package extraction, runtime syntax checks and source-to-package SHA-256 checks are recorded in the validation report.
- Node tests verify unchanged ChatGPT/popup surface, the restricted CDP allowlist, click-stage labels, and terminal failure-detail propagation.

### Current confirmed stage and nearest roadmap step

The current confirmed stage remains **R4 — choose city**. The nearest unclosed step is a single live run that reports the exact safe failure stage or proves the click and selected-city state. Search remains out of scope.


---

## Append — v0.7.6 — persistent visible-click handoff after page unload

**Date:** 2026-06-25  
**Status:** test candidate; exact-package and local Chromium evidence completed. Live user-Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without changing prior history.

### Triggering live evidence

A live `AVITO_UI` form on the run-owned Avito tab completed trusted text entry into `search-form/suggest/input`, then the Worker received `A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received`. The prior architecture had no durable record between a direct visible `CLICK` and the asynchronous response from the old content script. It could neither prove whether the click was dispatched nor safely decide whether a retry was allowed.

### First incorrect boundary

The first incorrect boundary was treating the long-lived response from `AF_EXECUTE_AVITO_UI_PLAN` as the sole proof of a direct visible click. A page unload can legitimately destroy that response channel after the DOM click has been dispatched. The code then terminalized the whole task as a failure, without a state object representing the already-dispatched click.

### What changed

1. Before every ordinary parsed `CLICK`, `avito_content.js` sends a restricted `AF_UI_CLICK_DISPATCHED` message to the Worker and waits for its acknowledgment. No DOM click occurs if that bounded record cannot be saved.
2. The Worker validates the sender tab, active run, exact local plan fingerprint, exact parsed `CLICK` step index, Avito origin and a short target description. It persists one `pending_ui_click` object and logs `AVITO_UI_CLICK_DISPATCH_RECORDED` before allowing the content script to invoke the visible DOM click.
3. When the old response channel closes after that persisted record, the Worker no longer reports a generic failure or repeats the click. It enters `WAITING_FOR_UI_CLICK_RECONCILIATION`.
4. The Worker waits only for the same run-owned Avito tab in the same window. Once it is an allowed complete Avito page, it captures exactly one bounded `PAGE_MAIN_VISIBLE` snapshot and returns a normal UI-plan report with `CLICK: dispatched_reconciled` and the recorded dispatch id.
5. If the tab disappears, moves window, or does not settle before the bounded deadline, the report says `CLICK: dispatched_unconfirmed`; it still never retries the click.

### Explicit non-changes

- No hard-coded city, search word, CSS class, button title or listing selector was added.
- The parser remains generic: the rule applies to every normal parsed `CLICK`, not only Save or Find.
- The restricted debugger allowlist remains exactly `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`.
- No `Runtime`, `Network`, `Fetch`, `Page`, `DOM`, `Storage`, cookies, hidden API, seller interaction, purchase, payment, captcha bypass or arbitrary JavaScript was added.
- ChatGPT capture behavior, popup UI and Avito Finder isolation from Business Bridge remain unchanged.

### Validation evidence

- Node tests verify the persisted-dispatch gate, async response-channel classification, reconciliation state contract, unchanged ChatGPT/popup hashes and debugger allowlist.
- A local headless Chromium DOM fixture loads the exact packaged `core.js` and `avito_content.js`, records the Worker acknowledgment before a real visible button click, and verifies that the visible click observes that record first.
- Exact runtime ZIP and source/tests ZIP are unpacked and checked; every runtime JavaScript file passes `node --check`; source/extracted runtime SHA-256 values are compared.

### Acceptance conditions and live status

The candidate must be tested in the pinned user Chrome with both kinds of page-changing visible click already observed in this project:

1. save the selected city; and
2. submit the free-text search.

For each, the result must be either a normal completed UI-plan response or `dispatched_reconciled` with one bounded post-transition snapshot. A generic asynchronous response-channel failure must never cause a second click, a repeated type, a changed city, or an unqualified `INSPECTING_FILTERS` terminal report.

The current confirmed project stage is **R5 — submit search after city application**. The nearest unclosed step is live acceptance of the generic click-handoff behavior, then bounded capture of the resulting search page and its visible price filters.

---

## Append — v0.7.7 — bound read-only target guard, Avito-only

**Date:** 2026-06-25  
**Status:** test candidate; exact-package validation is required before sharing, and one live user-Chrome verification is still required.  
**Append-only rule:** this entry is appended without changing or deleting earlier text.

### Triggering live evidence

The run successfully reached the public results page `Златоуст → ноутбуки`. The later read-only `INSPECT_FILTERS` command returned only a generic DOM summary. The next read-only diagnostic reported `https://www.avito.ru/` and `Советская Гавань`, despite the immediately preceding verified results page being `Златоуст → ноутбуки`.

### First proven divergence and five preceding transitions

The first proven source-level divergence was inside `queueAvitoTask`: the `INSPECT_FILTERS` branch supplied the public root `https://www.avito.ru/` as `requestedUrl`. `ensureAvitoTarget` treats a non-empty requested URL as a navigation request for the existing Avito tab.

1. A run-owned Avito tab had reached the visible `Златоуст → ноутбуки` results page.
2. The next writing block was parsed as `INSPECT_FILTERS`.
3. `queueAvitoTask` built the target request for that read-only mode.
4. The old code forced `requestedUrl` to the public root instead of preserving the run-owned target URL.
5. `ensureAvitoTarget` was then permitted to navigate the existing Avito tab to that root.

The later report of the root page and `Советская Гавань` is consistent with that source path. The extension did not prove a user action changed the city.

### What changed

- `DIAGNOSE_DOM` and `INSPECT_FILTERS` are now read-only target-bound modes.
- They reuse only the valid `avito_tab_id` stored in the current run state and the same Chrome window.
- They never create a tab, navigate a tab, or select another Avito tab as a fallback.
- A URL written in a diagnostic form is recorded as ignored evidence when it differs from the bound tab; it can no longer redirect the target.
- If the run-bound tab is absent or invalid, the extension stops with `READONLY_BOUND_TARGET_UNAVAILABLE`; it does not guess another Avito page.
- `AVITO_UI` keeps its existing explicit visible-action target rules and its v0.7.6 one-click reconciliation behavior.

### Explicit non-changes

- No Avito selector, city label, filter name, price field, listing collector, seller workflow or hard-coded locality was added.
- No new permission or host permission was added.
- The CDP allowlist remains only `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`.
- No Runtime, Network, Fetch, Storage, Page, DOM, cookie, hidden API, proxy, CAPTCHA, message, purchase or payment capability was added.
- `chatgpt_content.js`, `popup.js`, `popup.html` and `popup.css` remain byte-identical to the v0.7.2 protected baseline.

### Validation and evidence

- Baseline v0.7.6 source tests: 13 passed, 0 failed before mutation.
- v0.7.7 source tests: 16 passed, 0 failed. The three added tests prove that a read-only request (a) ignores a supplied root URL and keeps the run-bound result tab, (b) blocks instead of selecting another Avito tab when the bound tab is missing, and (c) does not build a public-root fallback for either `DIAGNOSE_DOM` or `INSPECT_FILTERS`.
- Existing Chromium DOM regression for the exact visible click-dispatch ordering still passes. Candidate runtime hashes are compared against the tested source before distribution.
- Live user-Chrome verification remains pending: from a bound `Златоуст → ноутбуки` results page, run `INSPECT_FILTERS` and then an allowed diagnostic; both must remain on the same tab, with no URL change and no city reset.

### Current confirmed stage and nearest roadmap step

The city and search path are proven in live user Chrome: `Златоуст → ноутбуки`. The nearest unclosed step is a live v0.7.7 proof that read-only filter inspection stays on that same result tab, followed by an allowed price-control diagnostic. No price value is applied until the real visible price controls are proven.


---

## Append — v0.7.8 — controlled initial read-only target bootstrap, Avito-only

**Date:** 2026-06-26  
**Status:** test candidate; local and exact-package validation passed, live user-Chrome acceptance remains required.  
**Append-only rule:** this entry is appended without changing or deleting earlier text.

### Triggering live evidence

After v0.7.7 was installed, the next first read-only writing-block task stopped at `COMMAND_CAPTURED` with `READONLY_BOUND_TARGET_UNAVAILABLE`. No Avito interaction took place. This was a safe block, but it exposed a new operational dead-end: a newly started or post-update run can legitimately have no persisted `avito_tab_id`, so the strict v0.7.7 guard had no approved way to establish its first run-owned target.

### Root cause

v0.7.7 correctly prevented a read-only command from redirecting a previously bound result tab. However, it applied the same “must already be bound” condition before the run had ever acquired its first Avito target. The failed state was observable as:

1. user-started ChatGPT capture was active;
2. a valid read-only form was captured;
3. Worker state became `COMMAND_CAPTURED`;
4. `avito_tab_id` was absent;
5. v0.7.7 rejected the request rather than safely creating or binding the first target.

This is distinct from the earlier v0.7.6 defect: no existing Avito tab was redirected in this incident.

### What changed

1. A read-only request still first reuses only the valid run-bound tab in the same window. It never calls `tabs.update` and never uses a page URL written in a writing block as navigation.
2. A one-time initial bootstrap is permitted only when all of these conditions are true:
   - the user has explicitly started the run;
   - the accepted form has reached `COMMAND_CAPTURED`;
   - the run has no stored Avito tab id; and
   - the bootstrap marker has not already been used.
3. During that narrow first-use condition, the Worker first binds an already-open Avito tab in the same Chrome window without navigation. It does not inspect other windows.
4. Only when that same window has no Avito tab, it creates exactly one inactive new tab at `https://www.avito.ru/`. No existing tab is redirected; the tab is later activated only through the normal page-ready path.
5. `queueAvitoTask` persists `avito_target_bootstrap_used` and the binding source before the page-ready flow continues. Once the one-time bootstrap has been used, a missing bound tab returns `READONLY_BOUND_TARGET_UNAVAILABLE` as before; no second fallback, second tab creation, navigation, typing or click is permitted.

### Explicit non-changes

- No existing Avito tab is navigated by `DIAGNOSE_DOM` or `INSPECT_FILTERS`.
- A diagnostic URL remains evidence only; it cannot redirect a current page.
- No selector, city name, search text, price control, listing collector, seller workflow, payment, call, message, subscription, CAPTCHA bypass, proxy, cookie, hidden API or arbitrary JavaScript feature was added.
- The debugger allowlist remains exactly `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`.
- `chatgpt_content.js`, `popup.js`, `popup.html` and `popup.css` remain byte-identical to the protected v0.7.2 baseline.
- Avito Finder remains isolated from Business Bridge storage, runtime, queue, logs and code.

### Validation and evidence

- Source tests: **18 passed, 0 failed**.
- The three target-binding tests now cover: existing bound-tab reuse with conflicting URL ignored; block after the one-time bootstrap has already been used; same-window initial binding without navigation; and one inactive public-root creation when no same-window Avito tab exists.
- Runtime JavaScript syntax checks pass for `service_worker.js`, `core.js`, `avito_content.js` and `chatgpt_content.js`.
- Existing exact Chromium DOM regression still proves Worker dispatch acknowledgment occurs before a visible generic click.
- The exact runtime ZIP and the exact source/tests ZIP were unpacked, tested, syntax-checked and compared file-by-file by SHA-256 before this candidate was shared.

### Required live acceptance and nearest roadmap step

Install v0.7.8 over v0.7.7. The next read-only form must no longer end with `READONLY_BOUND_TARGET_UNAVAILABLE` merely because the new run has no previous `avito_tab_id`:

- when a same-window Avito tab is open, it must be reused without a URL change; or
- when none is open, exactly one new inactive public-root tab may be created, then normal page-ready activation may continue.

After that first target is established, all later read-only forms must remain bound to it and must block, rather than redirect or recreate, if that tab disappears. The nearest product step remains a bounded inspection of the real visible price controls on the `Златоуст → ноутбуки` results page; no price is applied until that read-only inspection is proven in user Chrome.

---

## Append — v0.8.0 — clean run-owned Avito target lifecycle rebuild

**Date:** 2026-06-26  
**Status:** test candidate; local validation completed, live user-Chrome acceptance required.  
**Append-only rule:** this entry is appended without deleting or altering prior entries.

### Triggering evidence

The v0.7.7 guard safely blocked the first read-only task of a new `Ищи` run with `READONLY_BOUND_TARGET_UNAVAILABLE`. That behavior regressed the original stage-1 route, which had always reused an Avito tab in the current window or created one active public-root tab after a user start. v0.7.8 attempted a one-time bootstrap flag, but it added a second target lifecycle instead of restoring the original one cleanly.

### Root cause

Target selection had been split into incompatible branches by command mode:

1. v0.7.6 allowed a form URL to navigate an existing Avito tab, which could reset a working result page.
2. v0.7.7 forbade all fallback for read-only modes, including the first Avito task after a new user start.
3. v0.7.8 added a bootstrap exception with separate state and a background tab path.

The faulty boundary was treating the URL or mode of an assistant writing block as the source of target selection. A run needs one lifecycle, independent of whether its next action is read-only or visible UI.

### What changed

- The v0.7.7/v0.7.8 target bootstrap code was removed rather than extended.
- The worker is rebuilt from the v0.7.6 source baseline with one target resolver for every Avito mode.
- Before the first Avito task of a user-started run, the resolver reuses one visible Avito tab in the pinned ChatGPT window, or creates exactly one active `https://www.avito.ru/` tab in that window. This is the original stage-1 behavior.
- The chosen tab is persisted with `avito_target_bound_once: true` before diagnostics, filter inspection, typing, clicks, or page snapshots begin.
- After that binding, every mode reuses only the same valid tab in the same window.
- Any Avito URL in a writing block is logged as `AVITO_COMMAND_URL_IGNORED`. It is never passed to `chrome.tabs.update`; existing Avito tabs are not navigated by form metadata.
- If an already-established bound tab disappears or no longer belongs to the pinned window, the run stops with `RUN_BOUND_AVITO_TARGET_UNAVAILABLE` and does not select a replacement tab or create another one.

### Explicit non-changes

- The v0.7.6 click-dispatch record and one-time post-unload reconciliation remain unchanged.
- The restricted debugger method allowlist remains exactly `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent`.
- No `Runtime`, `Network`, `Fetch`, `Page`, `DOM`, `Storage`, cookie, hidden API, arbitrary JavaScript, seller message, phone, purchase, payment, delivery, CAPTCHA, proxy, or Business Bridge behavior was added.
- ChatGPT capture, popup, storage namespace, permissions, and host permissions remain isolated and unchanged.

### Local validation

- Existing v0.7.4–v0.7.6 regressions are retained.
- New target-lifecycle tests cover: initial same-window reuse, initial active public-root creation, URL-ignore behavior for read-only and UI forms, and refusal after a previously established binding is lost.
- Runtime syntax, exact archive extraction, and source-to-package SHA-256 comparison are required before distribution.

### Live acceptance still required

From a fresh `Ищи` start with no stored Avito tab, a first read-only command must visibly reuse/create the normal Avito target and return its snapshot. Then the same target must survive a URL-bearing diagnostic form without moving to the root, losing the city, or changing the query. A closed previously bound tab must yield a safe block with no replacement tab.

---

## 2026-06-26 — v0.8.1 visible filter-surface repair

**Observed live evidence.** The v0.8.0 run-owned lifecycle succeeded in one public Chrome flow: first read-only page capture, location dialog, `Златоуст` selection, explicit enabling of `Сначала в выбранном городе`, apply-click handoff, and `ноутбуки` search. The resulting page was `https://www.avito.ru/zlatoust/noutbuki?...` with `Златоуст` visible in the header. The follow-up `INSPECT_FILTERS` report, however, returned only generic input/button/listing counters. It did not return observable price controls, so ChatGPT could not safely identify a price field or filter trigger.

**Root cause.** `avito_content.js::inspect()` counted visible inputs, buttons and listing links only. It never resolved or serialized a bounded filter surface. The report formatter therefore had no concrete data-marker, placeholder, role, label, title or visible text for the price controls.

**Change.** v0.8.1 changes only the read-only observation path:

- `FILTERS_VISIBLE` is an explicit allowed diagnostic scope.
- `INSPECT_FILTERS` now captures that scope instead of returning counters alone.
- The capture returns bounded visible non-listing filter candidates with `data-marker`, role, type, placeholder, aria-label, title, visible text and discovery source.
- Candidate discovery first uses explicit public filter/price/delivery/sort text or attributes, then a bounded visible results-band fallback. Listing-card controls are excluded.
- Diagnostic and inspection reports now render the observable filter elements.

**Security / product limits preserved.** The repair does not click, type, scroll, navigate, create tabs, call hidden APIs, access cookies/storage secrets, use arbitrary JavaScript on Avito, or interact with sellers. A price control that is not visibly discoverable is reported as unavailable rather than guessed.

**Validation.** The full Node suite passed 24/24. A local Chromium fixture loaded the exact `core.js` and `avito_content.js`, exposed visible price controls, confirmed they were returned in `FILTERS_VISIBLE`, confirmed listing-card controls were excluded, and confirmed zero click events. Runtime syntax, package extraction and runtime-source SHA-256 equality were also checked. Live Chrome acceptance of the new filter report remains pending.

## v0.8.2 — card-bound listing collection

Live collection on the real `Златоуст → ноутбуки` results page exposed a separate evidence defect in `COLLECT_LISTINGS`: it iterated arbitrary visible links, so photo links, seller-profile links and message links could appear as independent “cards”. A nearby price could then be reported next to a non-listing link. This output is not sufficient for comparing offers and must not be used for an autonomous choice.

The replacement keeps collection read-only and does not add any click, typing, scrolling, URL change, debugger method, network access, storage access or seller interaction. The collector now enumerates only visible `a[data-marker='item-title']` anchors. For every result it finds the nearest visible ancestor containing exactly that one visible title anchor; price, seller and location are read only from that same ancestor. A photo link, seller profile, message button or phone control cannot create an independent record. The report marks every returned record as `{card-bound}`. When a card-local price is not visible, the price remains empty rather than borrowing text from a neighbour.

New local regression coverage constructs two realistic visible cards plus distractor photo, seller-profile and message links. The exact content script returns exactly the two title-anchored records, their own card-local prices and sellers, and performs zero clicks. This remains a test candidate until the repaired collection is proven in the user’s live Chrome/Avito session.

## Current extension state — v0.8.2 test candidate

Avito Finder is an isolated Chrome extension bound to one pinned ChatGPT conversation. It performs only bounded actions on visible public Avito UI in one run-owned tab in the same Chrome window. It has no shared queue, runtime, storage, logs, task IDs or server API with Business Bridge.

The first action of an explicit user run reuses one existing Avito tab in that window or creates one active public-root tab when none exists, then persists that binding. Subsequent diagnostic and UI forms always use this same bound tab. A URL written in a form is report evidence only: it must never navigate or reset the tab. A disappeared bound tab stops the run safely rather than selecting a replacement.

Read-only operations may capture a limited visible DOM region, current filter surface, or card-bound public listing data. Visible UI operations are limited to validated user-visible controls; regular clicks are persisted to the extension worker before dispatch and are reconciled after a navigation without retrying the click. The permitted debugger use is limited to Chrome `Input.dispatchMouseEvent` and `Input.dispatchKeyEvent` for an already validated visible interaction. Runtime evaluation, Network, Fetch, Page, DOM, Storage, cookies, hidden APIs, arbitrary JavaScript execution, CAPTCHA bypass, seller messages, calls, purchasing, payment, checkout, booking and delivery finalization are excluded.

For city selection, the run chooses the requested city through the visible dialog and must confirm the user-required checkbox “Сначала в выбранном городе” as enabled before applying the city. Listing collection in this candidate begins only from visible `item-title` anchors; title, price, seller and location are read only from the same bounded card, and every returned result is marked `{card-bound}`. There is no live acceptance proof for v0.8.2 yet; local package and browser-fixture checks are not a substitute for a live Chrome/Avito run.

Distribution now carries this single canonical append-only Markdown file with every candidate and source archive. Earlier standalone version notes are not included in the v0.8.2 runtime or source archives.

## 2026-06-26 — v0.8.3 public listing passport (test candidate)

### Что изменено
- Добавлено read-only действие `COLLECT_LISTING_DETAILS` / «Собери публичный паспорт текущего объявления».
- Оно читает только видимые публичные узлы уже открытой карточки: заголовок, цену, местоположение, продавца, публично видимый рейтинг/бейджи, доставку, число видимых миниатюр, разделы «О ноутбуке» и «Характеристики», а также ограниченный текст описания.
- В отчёт добавляется список отсутствующих сведений, чтобы ChatGPT явно отделял факты от рисков.

### Почему
Пользователь потребовал учитывать описание продавца, состояние и характеристики внутри карточки и оценивать лот по этим публичным данным.

### Границы безопасности
- Коллектор не нажимает «Написать», «Показать телефон», «Купить» и не открывает отзывы или профиль.
- Нет скрытых API, Runtime, Network, cookies или чтения скрытого preloaded-state.
- Контактные номера в видимом тексте маскируются как `[контакт скрыт]`.
- Оценку в том же чате выполняет ChatGPT; расширение возвращает только публичные факты.


## 2026-06-26 — v0.8.4 debugger click navigation and listing-surface fence (test candidate)

### Наблюдаемое live-доказательство

В объединённом прогоне `af-20260626033237-nat9` расширение отчиталось о `CLICK` по `a data-marker=item-title` «Идеальные ноутбуки с гарантией Игровые/Офисные», но фактический URL остался выдачей `.../zlatoust/noutbuki?q=...`. Последующий `COLLECT_LISTING_DETAILS` ошибочно принял заголовок страницы выдачи «Ноутбуки»: объявления для Златоуста за заголовок карточки, а `LISTING_CARD_VISIBLE` выбрал фото-ссылку. Этот результат не является паспортом лота и не используется для оценки.

### Причина

1. Общий шаг `CLICK` записывал dispatch, но выполнял синтетический `element.click()`. Для перехода по карточке он не создал доказанный пользовательский mouse input и не дал надёжной навигации.
2. При возможной выгрузке content script после навигации worker умел вернуть только reconciliation-снимок, но не продолжал оставшиеся read-only шаги того же плана.
3. Passport collector допускал любой видимый `h1` как fallback, даже без подтверждённой поверхности карточки.

### Что изменено

- Общий `CLICK` теперь проходит только через Chrome Debugger `Input.dispatchMouseEvent` после проверки ровно того же видимого и pointer-reachable узла content script. Разрешённый CDP-набор не изменён: только `Input.dispatchMouseEvent` и `Input.dispatchKeyEvent`.
- Dispatch сохраняется до mouse input. Если реальный переход выгружает content script, worker ждёт именно смену URL готовой Avito-вкладки, не считает старую выдачу подтверждением и не повторяет клик.
- После подтверждённого перехода worker автоматически выполняет только не-кликающий остаток того же плана (например `WAIT → COLLECT_LISTING_DETAILS → SNAPSHOT`) с сохранением исходных индексов шагов. Второй click после unload намеренно блокируется отдельным статусом, а не повторяется или угадывается.
- `COLLECT_LISTING_DETAILS` теперь требует подтверждённую поверхность карточки: marker заголовка карточки, связанный `item-view`-сигнал вместе с данными карточки, либо связку видимых цены и описания. Заголовок выдачи без этой поверхности возвращает `LISTING_PUBLIC_SURFACE_UNAVAILABLE` с пустыми полями, а не ложный паспорт.

### Безопасность и намеренные ограничения

- Нет Runtime, Network, Fetch, Page, DOM, Storage, cookie, скрытого API, произвольного JavaScript, контакта с продавцом, телефона, покупки, оплаты, оформления доставки или прокрутки.
- Клик не повторяется автоматически. При отсутствии смены URL до таймаута возвращается `UI_CLICK_NAVIGATION_UNCONFIRMED`.
- Изменение является test candidate; оно требует отдельного live-прогона в пользовательском Chrome. Локальные тесты не являются заменой такому подтверждению.


## 2026-06-26 — v0.8.5 proactive anchor-navigation handoff (test candidate)

### Наблюдаемое live-доказательство

В прогоне `af-20260626034419-c078` `CLICK` по `a[data-marker=item-title]` был подтверждён, но тот же content script сразу попытался выполнить `COLLECT_LISTING_DETAILS` на старой выдаче. Защитный fence вернул `LISTING_PUBLIC_SURFACE_UNAVAILABLE`, поэтому ложный паспорт не был создан, но переход не был передан Worker как отдельная обязательная фаза.

### Причина

v0.8.4 начинал reconciliation только когда message channel уже закрывался при выгрузке страницы. При обычном асинхронном ответе content script продолжал тот же план до того, как Worker получил подтверждение смены URL. Кроме того, CDP mouse press/release packets не передавали явные `buttons` и `pointerType`, что оставляло риск неполного pointer lifecycle на сайтах с более строгой проверкой.

### Что изменено

- После ровно одного успешного `CLICK` по видимой Avito-ссылке с другим публичным Avito path content script немедленно завершает старый документ результатом `VISIBLE_ANCHOR_NAVIGATION`. Он не ждёт и не выполняет `WAIT`, `COLLECT_LISTING_DETAILS` или snapshot на старой выдаче.
- Worker получает сохранённый dispatch и сразу переводит задачу в `WAITING_FOR_UI_CLICK_RECONCILIATION`. Он ожидает готовую вкладку с изменённым URL, затем исполняет только остаток после клика с исходными индексами шагов. Повторный клик по-прежнему отсутствует.
- CDP click lifecycle теперь явный: `mouseMoved` → `mousePressed` с `buttons: 1` → `mouseReleased` с `buttons: 0`, для всех пакетов `pointerType: mouse`. Разрешённый набор CDP-методов не меняется: только `Input.dispatchMouseEvent` и `Input.dispatchKeyEvent`.
- Если URL не меняется, итог остаётся честным `UI_CLICK_NAVIGATION_UNCONFIRMED`, без сбора данных выдачи и без второго клика.

### Границы

Нет Runtime, Network, Fetch, Page, DOM, Storage, cookies, скрытых API, произвольного JavaScript, прокрутки, сообщений, телефона, покупки, оплаты, оформления доставки или контакта с продавцом. Это test candidate до отдельной live-проверки в пользовательском Chrome.

### Локальная проверка v0.8.5

- Полный Node-набор прошёл: **36/36**, без пропусков и сбоев. В него входят прежние Chromium fixtures для контролов, card-bound выдачи и публичного паспорта, а также три новые проверки proactive handoff и pointer lifecycle.
- `node --check` успешно выполнен для `core.js`, `chatgpt_content.js`, `avito_content.js` и `service_worker.js`.
- Это не заменяет live-приёмку в пользовательском Chrome: она должна подтвердить ровно один visible click, смену URL, автоматическое выполнение read-only остатка и отсутствие повторного клика.

---

## 2026-06-26 — v0.9.1 working-baseline-current-context test candidate

### Почему v0.9.0 отозван как база

В v0.9.0 был внесён регресс первого шага: после «Ищи» первый корректный `AVITO_UI`-план намеренно перехватывался веткой `INITIAL_CONTEXT_REPORTED` и заменялся отдельным read-only отчётом. В результате расширение не выполняло первый рабочий план. Это противоречило рабочей цепочке v0.8.5: `Ищи` → захват следующего writing block → локальная валидация → исполнение допустимого `AVITO_UI`.

Причина ошибки — неверная интерпретация требования о текущей точке после ручной смены/закрытия Avito-вкладки: внутреннюю проверку контекста ошибочно сделали обязательным внешним шагом. Правильно: снимать текущий контекст внутри исполнения; первый корректный план не блокировать. При реальном ручном изменении контекста после уже подтверждённого шага вернуть в этот же чат компактный отчёт с текущей точкой и журналом маршрута, чтобы следующий план стартовал от фактической страницы.

### База и минимальные изменения

- Основа: исходники последнего предоставленного рабочего кандидата `v0.8.5`, а не сокращённая перепись v0.9.0.
- Первый допустимый `AVITO_UI` после «Ищи» теперь исполняется. Внутренний read-only снимок маршрута производится до плана, но не создаёт отдельный отчёт на первом наблюдении.
- Привязка Avito-вкладки действует только в рамках текущего run. Новый «Ищи» очищает `avito_tab_id`, маршрут и предыдущий контекст.
- Удалено автоматическое создание public-root Avito-вкладки. Когда Avito-вкладок нет, расширение не создаёт страницу и возвращает безопасную причину `AVITO_VISIBLE_TAB_REQUIRED_OPEN_ONE_PUBLIC_AVITO_TAB`.
- При наличии одной вкладки Avito в том же окне выбирается она; при активной Avito-вкладке выбирается активная; несколько неактивных вкладок без однозначности блокируются вместо произвольного выбора.
- При ручной смене страницы, подтверждённой после предыдущего шага, расширение делает только visible-DOM route snapshot и возвращает текущий URL, тип поверхности, город/запрос если доступны, диалог города, обязательный чекбокс и login-popup. Оно не кликает, не вводит текст, не возвращает старую страницу и не создаёт вкладку.
- При закрытии привязанной в текущем run вкладки возвращается тот же маршрутный отчёт с причиной `AVITO_TAB_CLOSED_BY_USER`; сохранённый tabId не используется снова.
- Сохранены строгие ограничения v0.8.5: только `Input.dispatchMouseEvent` и `Input.dispatchKeyEvent`; без `Runtime`, `Network`, `Fetch`, `Page.navigate`, `Input.insertText`, cookies, скрытых API, сообщений продавцам, телефона, покупки и оплаты.

### Что требует живой проверки

Нужны Chrome-проверки: первый `AVITO_UI` после «Ищи»; выбор города через фактический `custom-option`; обязательный чекбокс «Сначала в выбранном городе»; ручная смена страницы после отчёта; закрытие вкладки; неопределённая доставка отчёта без повторного Send; переход в карточку и сбор публичного паспорта.

### Уточнение: сверка неопределённой доставки отчёта

В базу включена read-only сверка старого `REPORT_DELIVERY_BLOCKED`: новый «Ищи» при таком состоянии не создаёт новый run. Она проверяет только два видимых факта в закреплённом ChatGPT-чате: существует ли точный отчёт как новый user-turn после предыдущего якоря или тот же текст всё ещё находится в нижнем composer. Никакого повторного Send-клика, ввода, изменения текста, создания Avito-вкладки или выполнения плана на этом шаге нет. Только после подтверждения user-turn возобновляется тот же continuation poll. Это сохраняет защиту от двойной отправки и устраняет регресс «blocked delivery → новый run».

---

## Append — v0.9.4 — minimal login-dialog classifier correction

**Date:** 2026-06-28  
**Status:** test candidate; not installed and not live accepted.  
**Append-only rule:** this entry is appended without deleting or rewriting any earlier entry.

### Triggering live evidence

Task `af-20260628024610-b3mm` reported `BLOCKED_LOGIN_OR_CAPTCHA` before its first `CLICK`. The user-visible surface was an ordinary optional Avito login dialog with a close cross, telephone/email and password fields; it was not a CAPTCHA. The required operation was only the existing generic visible click on the cross. No credential, code, registration or social-login action was requested or used.

### First wrong object

`detectBlock()` in `avito_content.js` classified the full page as `BLOCKED_LOGIN_OR_CAPTCHA` merely because it contained words equivalent to “Войти” together with Avito text. It ran before generic target resolution. This prevented the already implemented generic `CLICK` from resolving the visible close button.

### Minimal correction

1. Removed only the login-word branch from `detectBlock()`.
2. No `DISMISS_LOGIN` action, new parser phrase, new permission, route-specific selector, target allowlist, navigation behavior or special authentication workflow was added.
3. The existing generic `CLICK` pipeline is unchanged. After reload, it must be able to resolve and click the normal visible close button supplied by the writing block.
4. A visible actual CAPTCHA remains a manual boundary: the extension does not solve it, bypass it, or continue manipulating the page through it. After the user completes it in the visible UI, the next run starts from the actual current page state.

### Route ledger update

| ID | Initial state | Exact next allowed action | Result / remaining proof |
|---|---|---|---|
| LR-005-R1 | Main Avito page with optional visible login dialog; no CAPTCHA | Existing generic `CLICK` targeting the one visible close control inside the dialog | Requires one live proof: recorded click dispatch, dialog disappears, no credential interaction, then resume the already-known city/search route. |

### Validation

- Added a regression test that fails if login text is again used in `detectBlock()`.
- Added a static test that the CAPTCHA text branch remains and no prohibited protocol primitive was introduced.
- Runtime JS syntax, Node tests, exact ZIP integrity, and source/extracted hash equality must pass before the candidate is shared.

### Required live acceptance

With the same visible login dialog, run the existing generic close plan. Expected result: the close `CLICK` is dispatched and reconciled; `BLOCKED_LOGIN_OR_CAPTCHA` must not appear from login text alone. Then continue from the unchanged tab; do not recreate it, navigate from a writing-block URL, or introduce a special auth action.



---

## Append — v0.9.5 — restoration of fresh-run public-root bootstrap and corrected `LIVE_ROUTE_LEDGER`

**Date:** 2026-06-28  
**Status:** test candidate; not installed and not live accepted.  
**Append-only rule:** this section corrects prior route rules without deleting or rewriting them.

### Triggering live evidence

Task `af-20260628025720-ttb9` stopped at `COMMAND_CAPTURED` with `AVITO_VISIBLE_TAB_REQUIRED_OPEN_ONE_PUBLIC_AVITO_TAB`. It did not reach Avito and did not perform a click, typing action or navigation. The cause was local extension routing: v0.9.1 had removed the public-root bootstrap, and v0.9.4 inherited that removal while changing only the ordinary login classifier.

### Correction of the erroneous prior rule

The v0.9.1 rule that said “when no Avito tab exists, do not create a page and return `AVITO_VISIBLE_TAB_REQUIRED_OPEN_ONE_PUBLIC_AVITO_TAB`” is superseded for a **fresh explicit user start**. It remains historical evidence of the defect and is not deleted from this append-only file.

### Exact fresh-run route contract

| Field | Required route |
|---|---|
| Route ID | `LR-006` |
| Prior state | A newly created explicit `Ищи` run in the same Chrome window; `user_started=true`; no run-owned `avito_tab_id`; no existing visible Avito tab in that window; `avito_target_bound_once=false`. |
| Exact target/action | Worker calls `chrome.tabs.create({url: "https://www.avito.ru/", active: true, windowId: current_window_id})` through `tabsCreate`. |
| Expected confirmed transition | Log `AVITO_INITIAL_PUBLIC_ROOT_CREATED`; bind the returned tab to this run; wait for the normal Avito page-ready path; execute the captured plan against that tab. |
| Reuse rule | If a run-owned tab already exists, reuse it. Otherwise prefer one active Avito tab, then exactly one Avito tab in the same window. |
| Single-create boundary | After any target is bound, `avito_target_bound_once=true`; no replacement or second bootstrap is created inside that same run. |
| Safe recovery | If creating the one root tab fails or returns a tab from another window, report `AVITO_PUBLIC_ROOT_CREATE_FAILED`. If multiple inactive Avito tabs are ambiguous, return `AVITO_VISIBLE_TAB_AMBIGUOUS_SELECT_ONE_TAB`; do not choose arbitrarily. |
| Prohibited alternatives | Do not restore an old tab ID, restore a prior URL, call `Page.navigate`, pass a writing-block URL to `tabs.update`, create a second root tab, or create replacement tabs after a bound tab was manually closed. |

### Preserved live UI routes

The required ledger is cumulative. The following previously observed routes stay authoritative and must not be rediscovered as generic text targets in a later patch:

| Route ID | Prior state | Exact visible target/action | Expected transition | Safe recovery / boundary |
|---|---|---|---|---|
| `LR-002` | Main Avito page, city control present | `DIAGNOSE_DOM` then `OPEN_LOCATION_DIALOG`; use city dialog controls, not raw `Москва` text | Visible city dialog is opened | If dialog controls differ, capture only `DIALOG_VISIBLE`; do not guess a header link. |
| `LR-003` | Open city dialog | Type city into `data-marker=popup-location/region/search-input`, collect menu and select exact `Златоуст , Челябинская область` within the same plan | City option is selected | Menu is temporal; do not split typing and selection across separate plans. |
| `LR-004` | City option selected | Click local-first checkbox, then `data-marker=popup-location/save-button` | Header city becomes `Златоуст` | Checkbox final state remains unproven until a delivered live report says so. |
| `LR-005-R1` | Ordinary visible optional login dialog, not CAPTCHA | Existing generic visible `CLICK` on the close control; no credential target | Dialog disappears, then current page work resumes | Do not click sign-in, registration, social login, or type any credentials. Login words alone must not create `BLOCKED_LOGIN_OR_CAPTCHA`. |

### Code changes

1. Restored `tabsCreate` and `createInitialPublicAvitoTab()` from the prior public-root bootstrap lifecycle.
2. Restored the controlled fallback in `ensureAvitoTarget()`: only after no Avito tab is found, only for `user_started=true`, and only before a target was bound in the run.
3. Retained the v0.9.4 correction: ordinary login text does not trigger the CAPTCHA stop before generic visible-target resolution.
4. Did not add URL navigation, hidden APIs, Runtime, Network, Fetch, cookies, credential input, CAPTCHA solving/bypass, seller interaction, purchase or payment behavior.

### Validation

- Static tests require the exact one-tab bootstrap call, fresh-run gate, no URL navigation, and the non-repeat boundary after target binding.
- Existing login-classifier regression tests remain: normal login text is not CAPTCHA, while the visible CAPTCHA boundary remains manual.
- Runtime syntax is checked for all four runtime JavaScript files.
- Exact archive integrity and source/extracted-file equality must pass before sharing.

### Required live acceptance

1. Start a fresh `Ищи` with no Avito tab in the current window.
2. Confirm exactly one active `https://www.avito.ru/` tab is created and the captured plan begins after page readiness.
3. Confirm a second root tab is not created inside that same run.
4. Confirm an ordinary login dialog can be closed by the existing generic click path, without credentials.
5. Append the actual report outcome to this same canonical file before any subsequent package is built.
